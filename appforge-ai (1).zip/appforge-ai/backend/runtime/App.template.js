// Application générée avec Kubo
import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import AppRuntime from './src/AppRuntime';
import spec from './src/spec.json';

export default function App() {
  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1, backgroundColor: spec.theme.background }} edges={['top', 'bottom']}>
        <StatusBar style="light" />
        <AppRuntime spec={spec} />
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
