// =====================================================================
//  Kubo — Moteur d'exécution des applications générées
//  Ce fichier est partagé : il sert à l'aperçu en direct dans Kubo
//  et il est embarqué tel quel dans chaque projet exporté (APK).
//  Dépendances : react-native + @expo/vector-icons uniquement.
// =====================================================================
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, Animated, Image, ImageBackground, Linking, Modal, Pressable, ScrollView, Share,
  StyleSheet, Text, TextInput, View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const ThemeCtx = React.createContext(null);
const useT = () => React.useContext(ThemeCtx);
// Contexte de l'application : spec complète, adresse du serveur (chatbot) et navigation
const AppCtx = React.createContext({ spec: null, apiUrl: '', projectId: '', go: () => {} });

const norm = (x) => String(x || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
const STOP = new Set(['les', 'des', 'une', 'est', 'que', 'qui', 'quoi', 'pour', 'dans', 'avec', 'sur', 'pas', 'vous', 'nous', 'mon', 'ton', 'son', 'mes', 'tes', 'ses', 'the', 'and', 'comment', 'quel', 'quelle']);
const words = (x) => norm(x).split(/[^a-z0-9]+/).filter((w) => w.length > 2 && !STOP.has(w));

function withAlpha(hex, alpha) {
  const a = Math.round(alpha * 255).toString(16).padStart(2, '0');
  return `${hex}${a}`;
}

function safeIcon(name, fallback = 'ellipse') {
  return Ionicons.glyphMap && Ionicons.glyphMap[name] ? name : fallback;
}

// ---------------------------------------------------------------- Composants
function HeaderC({ p }) {
  const t = useT();
  return (
    <View style={{ marginBottom: 6 }}>
      <Text style={[s.h1, { color: t.text }]}>{p.title}</Text>
      {!!p.subtitle && <Text style={[s.sub, { color: withAlpha(t.text, 0.65) }]}>{p.subtitle}</Text>}
    </View>
  );
}

function TextC({ p }) {
  const t = useT();
  const size = { sm: 13, md: 15, lg: 18, xl: 24 }[p.size] || 15;
  return (
    <Text style={{ color: p.muted ? withAlpha(t.text, 0.6) : t.text, fontSize: size, textAlign: p.align || 'left', lineHeight: size * 1.45 }}>
      {p.text}
    </Text>
  );
}

function ImageC({ p }) {
  const t = useT();
  if (!p.uri) {
    return (
      <View style={[s.imgPh, { height: p.height || 180, backgroundColor: t.surface, borderColor: withAlpha(t.text, 0.1) }]}>
        <Ionicons name="image-outline" size={32} color={withAlpha(t.text, 0.4)} />
      </View>
    );
  }
  return (
    <View>
      <Image source={{ uri: p.uri }} style={{ width: '100%', height: p.height || 180, borderRadius: 16, backgroundColor: t.surface }} resizeMode="cover" />
      {!!p.caption && <Text style={[s.caption, { color: withAlpha(t.text, 0.55) }]}>{p.caption}</Text>}
    </View>
  );
}

function ButtonC({ p, go }) {
  const t = useT();
  const onPress = () => {
    if (p.action === 'navigate' && p.target) go(p.target);
    else if (p.action === 'link' && p.target) Linking.openURL(p.target).catch(() => {});
    else Alert.alert(p.label, p.message || 'Action effectuée ✅');
  };
  const outline = p.variant === 'outline';
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        s.btn,
        outline ? { borderWidth: 1.5, borderColor: t.primary } : { backgroundColor: t.primary },
        { opacity: pressed ? 0.8 : 1, transform: [{ scale: pressed ? 0.98 : 1 }] },
      ]}
    >
      <Text style={[s.btnText, { color: outline ? t.primary : '#FFFFFF' }]}>{p.label}</Text>
    </Pressable>
  );
}

function CardC({ p }) {
  const t = useT();
  return (
    <View style={[s.card, { backgroundColor: t.surface, borderColor: withAlpha(t.primary, 0.25) }]}>
      <View style={[s.iconBubble, { backgroundColor: withAlpha(t.primary, 0.18) }]}>
        <Ionicons name={safeIcon(p.icon, 'sparkles')} size={20} color={t.secondary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[s.cardTitle, { color: t.text }]}>{p.title}</Text>
        {!!p.text && <Text style={{ color: withAlpha(t.text, 0.7), marginTop: 4, lineHeight: 20 }}>{p.text}</Text>}
      </View>
    </View>
  );
}

function ListC({ p }) {
  const t = useT();
  return (
    <View>
      {!!p.title && <Text style={[s.section, { color: t.text }]}>{p.title}</Text>}
      <View style={[s.listBox, { backgroundColor: t.surface }]}>
        {(p.items || []).map((it, i) => (
          <View key={i} style={[s.listRow, i > 0 && { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: withAlpha(t.text, 0.12) }]}>
            <Ionicons name={safeIcon(it.icon)} size={22} color={t.secondary} />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={{ color: t.text, fontWeight: '600', fontSize: 15 }}>{it.title}</Text>
              {!!it.subtitle && <Text style={{ color: withAlpha(t.text, 0.6), marginTop: 2 }}>{it.subtitle}</Text>}
            </View>
            <Ionicons name="chevron-forward" size={18} color={withAlpha(t.text, 0.35)} />
          </View>
        ))}
      </View>
    </View>
  );
}

function InputC({ p }) {
  const t = useT();
  const [v, setV] = useState('');
  return (
    <View>
      <Text style={[s.label, { color: withAlpha(t.text, 0.8) }]}>{p.label}</Text>
      <TextInput
        value={v}
        onChangeText={setV}
        placeholder={p.placeholder}
        placeholderTextColor={withAlpha(t.text, 0.35)}
        keyboardType={p.keyboard || 'default'}
        multiline={!!p.multiline}
        style={[s.input, { color: t.text, backgroundColor: t.surface, borderColor: withAlpha(t.text, 0.12) }, p.multiline && { minHeight: 90, textAlignVertical: 'top' }]}
      />
    </View>
  );
}

function StatsC({ p }) {
  const t = useT();
  return (
    <View style={{ flexDirection: 'row', gap: 10 }}>
      {(p.items || []).map((it, i) => (
        <View key={i} style={[s.stat, { backgroundColor: t.surface, borderColor: withAlpha(t.secondary, 0.25) }]}>
          <Text style={{ color: t.secondary, fontSize: 20, fontWeight: '800' }}>{it.value}</Text>
          <Text style={{ color: withAlpha(t.text, 0.6), fontSize: 12, marginTop: 2 }}>{it.label}</Text>
        </View>
      ))}
    </View>
  );
}

function DividerC() {
  const t = useT();
  return <View style={{ height: 1, backgroundColor: withAlpha(t.text, 0.12), marginVertical: 4 }} />;
}

function TodoC({ p }) {
  const t = useT();
  const [items, setItems] = useState(() => (p.items || []).map((text, i) => ({ id: String(i), text, done: false })));
  const [draft, setDraft] = useState('');
  const add = () => {
    const text = draft.trim();
    if (!text) return;
    setItems((x) => [...x, { id: String(Date.now()), text, done: false }]);
    setDraft('');
  };
  const remaining = items.filter((i) => !i.done).length;
  return (
    <View style={[s.card, { backgroundColor: t.surface, borderColor: withAlpha(t.primary, 0.25), flexDirection: 'column', alignItems: 'stretch' }]}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={[s.cardTitle, { color: t.text }]}>{p.title}</Text>
        <Text style={{ color: t.secondary, fontWeight: '700' }}>{remaining} restante{remaining > 1 ? 's' : ''}</Text>
      </View>
      <View style={{ flexDirection: 'row', marginTop: 12, gap: 8 }}>
        <TextInput
          value={draft}
          onChangeText={setDraft}
          onSubmitEditing={add}
          placeholder={p.placeholder}
          placeholderTextColor={withAlpha(t.text, 0.35)}
          style={[s.input, { flex: 1, color: t.text, backgroundColor: t.background, borderColor: withAlpha(t.text, 0.12) }]}
        />
        <Pressable onPress={add} style={[s.squareBtn, { backgroundColor: t.primary }]}>
          <Ionicons name="add" size={24} color="#fff" />
        </Pressable>
      </View>
      {items.map((it) => (
        <View key={it.id} style={s.todoRow}>
          <Pressable onPress={() => setItems((x) => x.map((i) => (i.id === it.id ? { ...i, done: !i.done } : i)))} hitSlop={8}>
            <Ionicons name={it.done ? 'checkmark-circle' : 'ellipse-outline'} size={24} color={it.done ? t.secondary : withAlpha(t.text, 0.4)} />
          </Pressable>
          <Text style={{ flex: 1, marginLeft: 10, color: it.done ? withAlpha(t.text, 0.4) : t.text, textDecorationLine: it.done ? 'line-through' : 'none' }}>{it.text}</Text>
          <Pressable onPress={() => setItems((x) => x.filter((i) => i.id !== it.id))} hitSlop={8}>
            <Ionicons name="trash-outline" size={18} color={withAlpha(t.text, 0.4)} />
          </Pressable>
        </View>
      ))}
    </View>
  );
}

function QuizC({ p }) {
  const t = useT();
  const qs = p.questions || [];
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState(null);
  const [score, setScore] = useState(0);
  if (!qs.length) return <TextC p={{ text: 'Aucune question.', muted: true }} />;
  if (idx >= qs.length) {
    return (
      <View style={[s.card, { backgroundColor: t.surface, borderColor: withAlpha(t.secondary, 0.4), flexDirection: 'column', alignItems: 'center' }]}>
        <Ionicons name="trophy" size={42} color={t.secondary} />
        <Text style={[s.h1, { color: t.text, marginTop: 8 }]}>{score} / {qs.length}</Text>
        <Text style={{ color: withAlpha(t.text, 0.7), marginBottom: 12 }}>{score === qs.length ? 'Parfait, bravo ! 🎉' : 'Bien joué, continue !'}</Text>
        <Pressable onPress={() => { setIdx(0); setScore(0); setPicked(null); }} style={[s.btn, { backgroundColor: t.primary, alignSelf: 'stretch' }]}>
          <Text style={[s.btnText, { color: '#fff' }]}>Recommencer</Text>
        </Pressable>
      </View>
    );
  }
  const q = qs[idx];
  const choose = (i) => {
    if (picked !== null) return;
    setPicked(i);
    if (i === q.answer) setScore((x) => x + 1);
  };
  return (
    <View style={[s.card, { backgroundColor: t.surface, borderColor: withAlpha(t.primary, 0.25), flexDirection: 'column', alignItems: 'stretch' }]}>
      <Text style={{ color: t.secondary, fontWeight: '700', fontSize: 12 }}>{p.title} · Question {idx + 1}/{qs.length}</Text>
      <Text style={[s.cardTitle, { color: t.text, marginVertical: 10, fontSize: 18 }]}>{q.question}</Text>
      {q.options.map((o, i) => {
        const isRight = picked !== null && i === q.answer;
        const isWrong = picked === i && i !== q.answer;
        return (
          <Pressable
            key={i}
            onPress={() => choose(i)}
            style={[s.option, { borderColor: isRight ? '#22C55E' : isWrong ? '#EF4444' : withAlpha(t.text, 0.15), backgroundColor: isRight ? '#22C55E22' : isWrong ? '#EF444422' : t.background }]}
          >
            <Text style={{ color: t.text, flex: 1 }}>{o}</Text>
            {isRight && <Ionicons name="checkmark-circle" size={20} color="#22C55E" />}
            {isWrong && <Ionicons name="close-circle" size={20} color="#EF4444" />}
          </Pressable>
        );
      })}
      {picked !== null && (
        <Pressable onPress={() => { setIdx(idx + 1); setPicked(null); }} style={[s.btn, { backgroundColor: t.primary, marginTop: 8 }]}>
          <Text style={[s.btnText, { color: '#fff' }]}>{idx + 1 < qs.length ? 'Question suivante' : 'Voir le résultat'}</Text>
        </Pressable>
      )}
    </View>
  );
}

function CounterC({ p }) {
  const t = useT();
  const [n, setN] = useState(p.start || 0);
  const step = p.step || 1;
  return (
    <View style={[s.card, { backgroundColor: t.surface, borderColor: withAlpha(t.primary, 0.25), justifyContent: 'space-between' }]}>
      <Text style={[s.cardTitle, { color: t.text }]}>{p.label}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
        <Pressable onPress={() => setN(n - step)} style={[s.squareBtn, { backgroundColor: withAlpha(t.primary, 0.25) }]}>
          <Ionicons name="remove" size={22} color={t.text} />
        </Pressable>
        <Text style={{ color: t.text, fontSize: 22, fontWeight: '800', minWidth: 40, textAlign: 'center' }}>{n}</Text>
        <Pressable onPress={() => setN(n + step)} style={[s.squareBtn, { backgroundColor: t.primary }]}>
          <Ionicons name="add" size={22} color="#fff" />
        </Pressable>
      </View>
    </View>
  );
}

function TapGameC({ p }) {
  const t = useT();
  const duration = p.duration || 10;
  const [state, setState] = useState('idle'); // idle | playing | over
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(0);
  const [left, setLeft] = useState(duration);
  const [pos, setPos] = useState({ x: 40, y: 40 });
  const scale = useRef(new Animated.Value(1)).current;
  const area = useRef({ w: 300, h: 260 });

  useEffect(() => {
    if (state !== 'playing') return undefined;
    const id = setInterval(() => {
      setLeft((l) => {
        if (l <= 1) { clearInterval(id); setState('over'); return 0; }
        return l - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [state]);

  useEffect(() => { if (state === 'over') setBest((b) => Math.max(b, score)); }, [state, score]);

  const move = () => setPos({ x: Math.random() * Math.max(10, area.current.w - 70), y: Math.random() * Math.max(10, area.current.h - 70) });
  const start = () => { setScore(0); setLeft(duration); setState('playing'); move(); };
  const hit = () => {
    if (state !== 'playing') return;
    setScore((x) => x + 1);
    Animated.sequence([
      Animated.timing(scale, { toValue: 0.7, duration: 60, useNativeDriver: true }),
      Animated.timing(scale, { toValue: 1, duration: 90, useNativeDriver: true }),
    ]).start();
    move();
  };

  return (
    <View style={[s.card, { backgroundColor: t.surface, borderColor: withAlpha(t.primary, 0.3), flexDirection: 'column', alignItems: 'stretch' }]}>
      <Text style={[s.cardTitle, { color: t.text }]}>{p.title}</Text>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginVertical: 10 }}>
        <Text style={{ color: t.secondary, fontWeight: '800' }}>Score : {score}</Text>
        <Text style={{ color: t.text, fontWeight: '700' }}>⏱ {left}s</Text>
        <Text style={{ color: withAlpha(t.text, 0.7) }}>Record : {best}</Text>
      </View>
      <View
        onLayout={(e) => { area.current = { w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height }; }}
        style={{ height: 260, borderRadius: 16, backgroundColor: t.background, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }}
      >
        {state === 'playing' ? (
          <Animated.View style={{ position: 'absolute', left: pos.x, top: pos.y, transform: [{ scale }] }}>
            <Pressable onPress={hit} style={[s.target, { backgroundColor: t.primary, shadowColor: t.primary }]}>
              <Ionicons name="flash" size={28} color="#fff" />
            </Pressable>
          </Animated.View>
        ) : (
          <View style={{ alignItems: 'center' }}>
            {state === 'over' && <Text style={[s.h1, { color: t.text }]}>Terminé : {score} points</Text>}
            <Pressable onPress={start} style={[s.btn, { backgroundColor: t.primary, paddingHorizontal: 32, marginTop: 10 }]}>
              <Text style={[s.btnText, { color: '#fff' }]}>{state === 'over' ? 'Rejouer' : 'Démarrer'}</Text>
            </Pressable>
          </View>
        )}
      </View>
    </View>
  );
}

function FeedC({ p }) {
  const t = useT();
  const { apiUrl, projectId } = React.useContext(AppCtx);
  const shared = !!(apiUrl && projectId); // publications partagées entre tous les utilisateurs de l'app
  const examples = () => (p.posts || []).map((po, i) => ({ ...po, id: `ex${i}`, liked: false, example: true }));
  const [posts, setPosts] = useState(examples);
  const [draft, setDraft] = useState('');
  const [author, setAuthor] = useState('');
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);

  const load = async () => {
    if (!shared) return;
    setLoading(true);
    try {
      const r = await fetch(`${apiUrl}/api/public/apps/${projectId}/feed`);
      const data = await r.json();
      if (r.ok && data.posts.length) {
        setPosts((cur) => data.posts.map((po) => ({ ...po, liked: !!(cur.find((c) => c.id === po.id) || {}).liked })));
      }
    } catch { /* hors ligne : on garde l'affichage actuel */ } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [apiUrl, projectId]); // eslint-disable-line react-hooks/exhaustive-deps

  const publish = async () => {
    const text = draft.trim();
    if (!text || sending) return;
    const name = author.trim() || 'Moi';
    if (!shared) {
      setPosts((x) => [{ id: String(Date.now()), author: name, text, likes: 0, liked: false }, ...x]);
      setDraft('');
      return;
    }
    setSending(true);
    try {
      const r = await fetch(`${apiUrl}/api/public/apps/${projectId}/feed`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ author: name, text }),
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.message || 'Publication impossible');
      setPosts((x) => [{ ...data.post, liked: false }, ...x.filter((po) => !po.example)]);
      setDraft('');
    } catch (e) {
      Alert.alert('Publication', e.message === 'Network request failed' ? 'Pas de connexion Internet.' : e.message);
    } finally { setSending(false); }
  };

  const like = (po) => {
    const delta = po.liked ? -1 : 1;
    setPosts((x) => x.map((i) => (i.id === po.id ? { ...i, liked: !i.liked, likes: Math.max(0, i.likes + delta) } : i)));
    if (shared && !po.example) {
      fetch(`${apiUrl}/api/public/apps/${projectId}/feed/${po.id}/like`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ delta }),
      }).catch(() => {});
    }
  };

  return (
    <View style={{ gap: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        {!!p.title && <Text style={[s.section, { color: t.text, marginBottom: 0 }]}>{p.title}</Text>}
        {shared && (
          <Pressable onPress={load} hitSlop={10} style={{ flexDirection: 'row', alignItems: 'center' }}>
            {loading ? <ActivityIndicator size="small" color={t.secondary} /> : <Ionicons name="refresh" size={20} color={t.secondary} />}
          </Pressable>
        )}
      </View>
      {p.allowPosting !== false && (
        <View style={[s.card, { backgroundColor: t.surface, borderColor: withAlpha(t.primary, 0.25), flexDirection: 'column', alignItems: 'stretch' }]}>
          <TextInput
            value={author}
            onChangeText={setAuthor}
            placeholder="Ton pseudo"
            placeholderTextColor={withAlpha(t.text, 0.35)}
            maxLength={40}
            style={{ color: t.text, fontWeight: '700', paddingVertical: 4, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: withAlpha(t.text, 0.15), marginBottom: 8 }}
          />
          <TextInput
            value={draft}
            onChangeText={setDraft}
            placeholder="Exprime-toi…"
            placeholderTextColor={withAlpha(t.text, 0.35)}
            multiline
            maxLength={500}
            style={{ color: t.text, minHeight: 50, textAlignVertical: 'top' }}
          />
          <Pressable onPress={publish} style={[s.btn, { backgroundColor: t.primary, alignSelf: 'flex-end', paddingHorizontal: 20, paddingVertical: 10, flexDirection: 'row' }]}>
            {sending && <ActivityIndicator size="small" color="#fff" style={{ marginRight: 8 }} />}
            <Text style={[s.btnText, { color: '#fff' }]}>Publier</Text>
          </Pressable>
        </View>
      )}
      {posts.map((po) => (
        <View key={po.id} style={[s.card, { backgroundColor: t.surface, borderColor: withAlpha(t.text, 0.08), flexDirection: 'column', alignItems: 'stretch' }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
            <View style={[s.avatar, { backgroundColor: withAlpha(t.secondary, 0.25) }]}>
              <Text style={{ color: t.secondary, fontWeight: '800' }}>{po.author.slice(0, 1).toUpperCase()}</Text>
            </View>
            <Text style={{ color: t.text, fontWeight: '700', marginLeft: 10, flex: 1 }}>{po.author}</Text>
            {!!po.createdAt && <Text style={{ color: withAlpha(t.text, 0.45), fontSize: 12 }}>{timeAgo(po.createdAt)}</Text>}
          </View>
          <Text style={{ color: t.text, lineHeight: 21 }}>{po.text}</Text>
          <Pressable onPress={() => like(po)} style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10 }}>
            <Ionicons name={po.liked ? 'heart' : 'heart-outline'} size={20} color={po.liked ? '#F43F5E' : withAlpha(t.text, 0.5)} />
            <Text style={{ color: withAlpha(t.text, 0.7), marginLeft: 6 }}>{po.likes}</Text>
          </Pressable>
        </View>
      ))}
    </View>
  );
}

function timeAgo(ts) {
  const m = Math.round((Date.now() - ts) / 60000);
  if (m < 1) return "à l'instant";
  if (m < 60) return `${m} min`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h`;
  return `${Math.round(h / 24)} j`;
}

function TimerC({ p }) {
  const t = useT();
  const total = (p.minutes || 25) * 60;
  const [left, setLeft] = useState(total);
  const [running, setRunning] = useState(false);
  useEffect(() => { setLeft(total); setRunning(false); }, [total]);
  useEffect(() => {
    if (!running) return undefined;
    const id = setInterval(() => setLeft((l) => {
      if (l <= 1) { setRunning(false); Alert.alert('⏰', 'Temps écoulé !'); return 0; }
      return l - 1;
    }), 1000);
    return () => clearInterval(id);
  }, [running]);
  const mm = String(Math.floor(left / 60)).padStart(2, '0');
  const ss = String(left % 60).padStart(2, '0');
  return (
    <View style={[s.card, { backgroundColor: t.surface, borderColor: withAlpha(t.primary, 0.3), flexDirection: 'column', alignItems: 'center' }]}>
      <Text style={{ color: withAlpha(t.text, 0.7), fontWeight: '600' }}>{p.label}</Text>
      <Text style={{ color: t.text, fontSize: 56, fontWeight: '800', marginVertical: 8, fontVariant: ['tabular-nums'] }}>{mm}:{ss}</Text>
      <View style={{ flexDirection: 'row', gap: 12 }}>
        <Pressable onPress={() => setRunning(!running)} style={[s.btn, { backgroundColor: t.primary, paddingHorizontal: 28 }]}>
          <Text style={[s.btnText, { color: '#fff' }]}>{running ? 'Pause' : 'Démarrer'}</Text>
        </Pressable>
        <Pressable onPress={() => { setRunning(false); setLeft(total); }} style={[s.btn, { borderWidth: 1.5, borderColor: t.primary, paddingHorizontal: 20 }]}>
          <Text style={[s.btnText, { color: t.primary }]}>Réinitialiser</Text>
        </Pressable>
      </View>
    </View>
  );
}

// ---------------------------------------------------------------- IA & médias
function HeroC({ p, go }) {
  const t = useT();
  const content = (
    <View style={{ padding: 22, minHeight: 170, justifyContent: 'flex-end' }}>
      <Text style={{ color: '#fff', fontSize: 27, fontWeight: '900', letterSpacing: -0.5 }}>{p.title}</Text>
      {!!p.subtitle && <Text style={{ color: 'rgba(255,255,255,0.88)', fontSize: 15, marginTop: 6, lineHeight: 21 }}>{p.subtitle}</Text>}
      {!!p.buttonLabel && (
        <Pressable onPress={() => p.target && go(p.target)} style={({ pressed }) => [s.heroBtn, { opacity: pressed ? 0.85 : 1 }]}>
          <Text style={{ color: t.primary, fontWeight: '800' }}>{p.buttonLabel}</Text>
          <Ionicons name="arrow-forward" size={16} color={t.primary} style={{ marginLeft: 6 }} />
        </Pressable>
      )}
    </View>
  );
  if (p.image) {
    return (
      <ImageBackground source={{ uri: p.image }} style={s.hero} imageStyle={{ borderRadius: 24 }}>
        <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(0,0,0,0.45)', borderRadius: 24 }]} />
        {content}
      </ImageBackground>
    );
  }
  return (
    <View style={[s.hero, { backgroundColor: t.primary }]}>
      <View style={[s.blob, { backgroundColor: withAlpha(t.secondary, 0.55), top: -60, right: -40 }]} />
      <View style={[s.blob, { backgroundColor: withAlpha('#FFFFFF', 0.12), bottom: -90, left: -50, width: 200, height: 200 }]} />
      {content}
    </View>
  );
}

function GalleryC({ p }) {
  const t = useT();
  const [open, setOpen] = useState(null);
  const imgs = p.images || [];
  return (
    <View>
      {!!p.title && <Text style={[s.section, { color: t.text }]}>{p.title}</Text>}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', rowGap: 10 }}>
        {imgs.map((uri, i) => (
          <Pressable key={i} onPress={() => setOpen(uri)} style={{ width: '48.5%', aspectRatio: 1 }}>
            <Image source={{ uri }} style={{ width: '100%', height: '100%', borderRadius: 14, backgroundColor: t.surface }} />
          </Pressable>
        ))}
      </View>
      {!imgs.length && <Text style={{ color: withAlpha(t.text, 0.5) }}>Ajoute des images dans l'éditeur.</Text>}
      <Modal visible={!!open} transparent animationType="fade" onRequestClose={() => setOpen(null)}>
        <Pressable onPress={() => setOpen(null)} style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.92)', justifyContent: 'center', padding: 12 }}>
          {!!open && <Image source={{ uri: open }} style={{ width: '100%', aspectRatio: 1, borderRadius: 12 }} resizeMode="contain" />}
          <Text style={{ color: '#fff', textAlign: 'center', marginTop: 16, opacity: 0.7 }}>Touchez pour fermer</Text>
        </Pressable>
      </Modal>
    </View>
  );
}

function youtubeId(url) {
  const m = String(url || '').match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/|youtube\.com\/embed\/)([\w-]{6,})/);
  return m ? m[1] : null;
}

function VideoC({ p }) {
  const t = useT();
  const id = youtubeId(p.url);
  const open = () => { if (p.url) Linking.openURL(p.url).catch(() => {}); };
  return (
    <View>
      {!!p.title && <Text style={[s.section, { color: t.text }]}>{p.title}</Text>}
      <Pressable onPress={open} style={{ borderRadius: 18, overflow: 'hidden', backgroundColor: t.surface, aspectRatio: 16 / 9, alignItems: 'center', justifyContent: 'center' }}>
        {id && <Image source={{ uri: `https://img.youtube.com/vi/${id}/hqdefault.jpg` }} style={StyleSheet.absoluteFill} />}
        <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(0,0,0,0.25)' }]} />
        <View style={{ width: 68, height: 68, borderRadius: 34, backgroundColor: t.primary, alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="play" size={32} color="#fff" style={{ marginLeft: 4 }} />
        </View>
        {!p.url && <Text style={{ color: '#fff', marginTop: 10 }}>Ajoute un lien vidéo dans l'éditeur</Text>}
      </Pressable>
      {!!p.caption && <Text style={[s.caption, { color: withAlpha(t.text, 0.6) }]}>{p.caption}</Text>}
    </View>
  );
}

function FaqC({ p }) {
  const t = useT();
  const [open, setOpen] = useState(-1);
  return (
    <View>
      {!!p.title && <Text style={[s.section, { color: t.text }]}>{p.title}</Text>}
      <View style={[s.listBox, { backgroundColor: t.surface }]}>
        {(p.items || []).map((it, i) => (
          <Pressable key={i} onPress={() => setOpen(open === i ? -1 : i)}
            style={[{ padding: 16 }, i > 0 && { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: withAlpha(t.text, 0.12) }]}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={{ color: t.text, fontWeight: '700', flex: 1, fontSize: 15 }}>{it.question}</Text>
              <Ionicons name={open === i ? 'chevron-up' : 'chevron-down'} size={18} color={t.secondary} />
            </View>
            {open === i && <Text style={{ color: withAlpha(t.text, 0.75), marginTop: 8, lineHeight: 21 }}>{it.answer}</Text>}
          </Pressable>
        ))}
      </View>
    </View>
  );
}

const IMAGE_STYLES = [
  ['auto', 'Libre', ''],
  ['realiste', 'Réaliste', ', photo réaliste, très détaillée, haute définition'],
  ['dessin', 'Dessin', ', illustration dessinée, couleurs vives'],
  ['aquarelle', 'Aquarelle', ', peinture à l’aquarelle, douce et artistique'],
  ['3d', '3D', ', rendu 3D, éclairage cinématographique'],
  ['anime', 'Anime', ', style anime japonais'],
];

function ImageGenC({ p }) {
  const t = useT();
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState(p.style || 'auto');
  const [uri, setUri] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const last = useRef(0);

  const generate = () => {
    const text = prompt.trim();
    if (!text) { setError('Décris d’abord l’image que tu veux.'); return; }
    const wait = Math.ceil((15000 - (Date.now() - last.current)) / 1000);
    if (wait > 0) { setError(`Patiente encore ${wait} s avant la prochaine image (service gratuit).`); return; }
    last.current = Date.now();
    const suffix = (IMAGE_STYLES.find((x) => x[0] === style) || IMAGE_STYLES[0])[2];
    const seed = Math.floor(Math.random() * 1e9);
    setError('');
    setLoading(true);
    setUri(`https://image.pollinations.ai/prompt/${encodeURIComponent(text + suffix)}?width=768&height=768&nologo=true&seed=${seed}`);
  };

  return (
    <View style={[s.card, { backgroundColor: t.surface, borderColor: withAlpha(t.primary, 0.3), flexDirection: 'column', alignItems: 'stretch' }]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
        <Ionicons name="color-palette" size={20} color={t.secondary} />
        <Text style={[s.cardTitle, { color: t.text, marginLeft: 8 }]}>{p.title}</Text>
      </View>
      <TextInput
        value={prompt}
        onChangeText={setPrompt}
        placeholder={p.placeholder}
        placeholderTextColor={withAlpha(t.text, 0.35)}
        multiline
        style={[s.input, { color: t.text, backgroundColor: t.background, borderColor: withAlpha(t.text, 0.12), minHeight: 70, textAlignVertical: 'top' }]}
      />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6, paddingVertical: 10 }}>
        {IMAGE_STYLES.map(([k, label]) => (
          <Pressable key={k} onPress={() => setStyle(k)}
            style={{ paddingHorizontal: 12, paddingVertical: 7, borderRadius: 99, borderWidth: 1, borderColor: style === k ? t.primary : withAlpha(t.text, 0.15), backgroundColor: style === k ? withAlpha(t.primary, 0.25) : 'transparent' }}>
            <Text style={{ color: t.text, fontWeight: '600', fontSize: 13 }}>{label}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <Pressable onPress={generate} style={({ pressed }) => [s.btn, { backgroundColor: t.primary, opacity: pressed || loading ? 0.8 : 1, flexDirection: 'row' }]}>
        {loading ? <ActivityIndicator color="#fff" /> : <Ionicons name="sparkles" size={18} color="#fff" />}
        <Text style={[s.btnText, { color: '#fff', marginLeft: 8 }]}>{loading ? 'Création en cours…' : 'Générer l’image'}</Text>
      </Pressable>
      {!!error && <Text style={{ color: '#F87171', marginTop: 10 }}>{error}</Text>}
      {!!uri && (
        <View style={{ marginTop: 14 }}>
          <View style={{ width: '100%', aspectRatio: 1, borderRadius: 16, overflow: 'hidden', backgroundColor: t.background, alignItems: 'center', justifyContent: 'center' }}>
            <Image
              source={{ uri }}
              style={StyleSheet.absoluteFill}
              onLoadEnd={() => setLoading(false)}
              onError={() => { setLoading(false); setError('La création a échoué. Réessaie dans quelques secondes.'); }}
            />
            {loading && <Text style={{ color: withAlpha(t.text, 0.6) }}>L’IA dessine ton image… (10 à 30 s)</Text>}
          </View>
          {!loading && !error && (
            <Pressable onPress={() => Share.share({ message: uri }).catch(() => {})} style={[s.btn, { borderWidth: 1.5, borderColor: t.primary, marginTop: 10, flexDirection: 'row' }]}>
              <Ionicons name="share-social" size={18} color={t.primary} />
              <Text style={[s.btnText, { color: t.primary, marginLeft: 8 }]}>Partager</Text>
            </Pressable>
          )}
        </View>
      )}
    </View>
  );
}

function faqAnswer(faq, question) {
  const q = new Set(words(question));
  let best = null;
  let bestScore = 0;
  for (const it of faq || []) {
    const w = words(it.question);
    if (!w.length) {
      // Question très courte (« Qui es-tu ? ») : comparaison du texte entier
      const core = norm(it.question).replace(/[^a-z0-9]+/g, ' ').trim();
      if (core && norm(question).replace(/[^a-z0-9]+/g, ' ').includes(core)) return it.answer;
      continue;
    }
    const score = w.filter((x) => q.has(x)).length / w.length;
    if (score > bestScore) { best = it; bestScore = score; }
  }
  return bestScore >= 0.5 ? best.answer : null;
}

function ChatbotC({ p }) {
  const t = useT();
  const { apiUrl } = React.useContext(AppCtx);
  const [msgs, setMsgs] = useState([{ role: 'assistant', content: p.welcome }]);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const scroll = useRef(null);

  const send = async () => {
    const text = draft.trim();
    if (!text || busy) return;
    const history = [...msgs, { role: 'user', content: text }];
    setMsgs(history);
    setDraft('');
    const local = faqAnswer(p.faq, text);
    if (local) { setMsgs([...history, { role: 'assistant', content: local }]); return; }
    let reply = 'Je n’ai pas encore la réponse à cette question. 🙏';
    if (apiUrl) {
      setBusy(true);
      try {
        const r = await fetch(`${apiUrl}/api/public/chat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ botName: p.name, instructions: p.instructions, messages: history.slice(-12) }),
        });
        const data = await r.json().catch(() => ({}));
        if (r.ok && data.reply) reply = data.reply;
        else if (r.status === 429) reply = 'Tu envoies beaucoup de messages ! Réessaie dans un instant.';
      } catch {
        reply = 'Je n’arrive pas à me connecter. Vérifie ta connexion Internet.';
      } finally { setBusy(false); }
    }
    setMsgs([...history, { role: 'assistant', content: reply }]);
  };

  return (
    <View style={[s.card, { backgroundColor: t.surface, borderColor: withAlpha(t.primary, 0.3), flexDirection: 'column', alignItems: 'stretch', padding: 0, overflow: 'hidden' }]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', padding: 14, backgroundColor: withAlpha(t.primary, 0.18) }}>
        <View style={[s.avatar, { backgroundColor: t.primary, width: 38, height: 38, borderRadius: 19 }]}>
          <Ionicons name="sparkles" size={18} color="#fff" />
        </View>
        <View style={{ marginLeft: 10 }}>
          <Text style={{ color: t.text, fontWeight: '800', fontSize: 16 }}>{p.name}</Text>
          <Text style={{ color: '#22C55E', fontSize: 12 }}>● En ligne</Text>
        </View>
      </View>
      <ScrollView ref={scroll} nestedScrollEnabled style={{ height: 340 }} contentContainerStyle={{ padding: 12, gap: 8 }}
        onContentSizeChange={() => scroll.current && scroll.current.scrollToEnd({ animated: true })}>
        {msgs.map((m, i) => {
          const mine = m.role === 'user';
          return (
            <View key={i} style={{ alignSelf: mine ? 'flex-end' : 'flex-start', maxWidth: '85%', backgroundColor: mine ? t.primary : t.background, borderRadius: 16, borderBottomRightRadius: mine ? 4 : 16, borderBottomLeftRadius: mine ? 16 : 4, padding: 11 }}>
              <Text style={{ color: mine ? '#fff' : t.text, lineHeight: 20 }}>{m.content}</Text>
            </View>
          );
        })}
        {busy && <View style={{ alignSelf: 'flex-start', backgroundColor: t.background, borderRadius: 16, padding: 12 }}><ActivityIndicator color={t.secondary} /></View>}
      </ScrollView>
      <View style={{ flexDirection: 'row', padding: 10, gap: 8, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: withAlpha(t.text, 0.15) }}>
        <TextInput
          value={draft}
          onChangeText={setDraft}
          onSubmitEditing={send}
          placeholder="Écris ton message…"
          placeholderTextColor={withAlpha(t.text, 0.35)}
          style={[s.input, { flex: 1, color: t.text, backgroundColor: t.background, borderColor: withAlpha(t.text, 0.12) }]}
        />
        <Pressable onPress={send} style={[s.squareBtn, { backgroundColor: t.primary }]}>
          <Ionicons name="send" size={20} color="#fff" />
        </Pressable>
      </View>
    </View>
  );
}

function appIndex(spec) {
  const out = [];
  for (const sc of (spec && spec.screens) || []) {
    const add = (title, snippet) => { if (title || snippet) out.push({ title: title || sc.title, snippet: snippet || '', screenId: sc.id, screen: sc.title }); };
    for (const c of sc.components) {
      const q = c.props || {};
      if (['header', 'hero', 'card'].includes(c.type)) add(q.title, q.subtitle || q.text);
      if (c.type === 'text') add('', q.text);
      if (c.type === 'list') (q.items || []).forEach((it) => add(it.title, it.subtitle));
      if (c.type === 'faq') (q.items || []).forEach((it) => add(it.question, it.answer));
      if (c.type === 'feed') (q.posts || []).forEach((it) => add(it.author, it.text));
      if (c.type === 'video') add(q.title, q.caption);
    }
  }
  return out;
}

const stripHtml = (h) => String(h || '').replace(/<[^>]+>/g, '').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&');

function SearchC({ p }) {
  const t = useT();
  const { spec, go } = React.useContext(AppCtx);
  const [q, setQ] = useState('');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const wiki = p.source === 'wikipedia';

  const run = async () => {
    const query = q.trim();
    if (!query) return;
    if (!wiki) {
      const ws = words(query).length ? words(query) : [norm(query)];
      setResults(appIndex(spec).filter((r) => { const hay = norm(`${r.title} ${r.snippet}`); return ws.every((w) => hay.includes(w)); }).slice(0, 30));
      return;
    }
    setLoading(true);
    try {
      const url = `https://fr.wikipedia.org/w/api.php?action=query&list=search&format=json&utf8=1&srlimit=10&origin=*&srsearch=${encodeURIComponent(query)}`;
      const data = await (await fetch(url)).json();
      setResults(((data.query && data.query.search) || []).map((r) => ({ title: r.title, snippet: stripHtml(r.snippet) + '…' })));
    } catch {
      setResults([]);
      Alert.alert('Recherche', 'Impossible de joindre Wikipédia. Vérifie ta connexion.');
    } finally { setLoading(false); }
  };

  const openResult = (r) => {
    if (wiki) Linking.openURL(`https://fr.wikipedia.org/wiki/${encodeURIComponent(r.title.replace(/ /g, '_'))}`).catch(() => {});
    else go(r.screenId);
  };

  return (
    <View>
      {!!p.title && <Text style={[s.section, { color: t.text }]}>{p.title}</Text>}
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <View style={[s.input, { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: t.surface, borderColor: withAlpha(t.primary, 0.35), paddingVertical: 0 }]}>
          <Ionicons name="search" size={18} color={withAlpha(t.text, 0.5)} />
          <TextInput
            value={q}
            onChangeText={setQ}
            onSubmitEditing={run}
            returnKeyType="search"
            placeholder={p.placeholder}
            placeholderTextColor={withAlpha(t.text, 0.35)}
            style={{ flex: 1, color: t.text, fontSize: 15, paddingVertical: 12, marginLeft: 8 }}
          />
        </View>
        <Pressable onPress={run} style={[s.squareBtn, { backgroundColor: t.primary, height: 48, width: 48 }]}>
          {loading ? <ActivityIndicator color="#fff" /> : <Ionicons name="arrow-forward" size={22} color="#fff" />}
        </Pressable>
      </View>
      {wiki && <Text style={{ color: withAlpha(t.text, 0.45), fontSize: 12, marginTop: 6 }}>Résultats fournis par Wikipédia</Text>}
      {results && (
        <View style={{ marginTop: 12, gap: 8 }}>
          {results.length === 0 && <Text style={{ color: withAlpha(t.text, 0.6) }}>Aucun résultat.</Text>}
          {results.map((r, i) => (
            <Pressable key={i} onPress={() => openResult(r)} style={({ pressed }) => [s.card, { backgroundColor: t.surface, borderColor: withAlpha(t.text, 0.08), opacity: pressed ? 0.8 : 1, flexDirection: 'column', alignItems: 'stretch', padding: 14 }]}>
              <Text style={{ color: t.text, fontWeight: '700', fontSize: 15 }}>{r.title}</Text>
              {!!r.snippet && <Text numberOfLines={3} style={{ color: withAlpha(t.text, 0.65), marginTop: 4, lineHeight: 19 }}>{r.snippet}</Text>}
              {!wiki && <Text style={{ color: t.secondary, fontSize: 12, marginTop: 6 }}>Écran : {r.screen}</Text>}
            </Pressable>
          ))}
        </View>
      )}
    </View>
  );
}

const REGISTRY = {
  header: HeaderC, text: TextC, image: ImageC, button: ButtonC, card: CardC, list: ListC, input: InputC,
  stats: StatsC, divider: DividerC, todo: TodoC, quiz: QuizC, counter: CounterC, tapgame: TapGameC, feed: FeedC, timer: TimerC,
  hero: HeroC, gallery: GalleryC, video: VideoC, faq: FaqC, imagegen: ImageGenC, chatbot: ChatbotC, search: SearchC,
};

export function RenderComponent({ component, go }) {
  const C = REGISTRY[component.type];
  if (!C) return null;
  return <C p={component.props || {}} go={go} />;
}

// ---------------------------------------------------------------- Application
/**
 * @param {object} props
 * @param {object} props.spec            AppSpec à exécuter
 * @param {string} [props.screenId]      écran contrôlé (optionnel)
 * @param {(id:string)=>void} [props.onScreenChange]
 * @param {string} [props.selectedId]    composant surligné (mode éditeur)
 * @param {(id:string)=>void} [props.onSelect]  mode éditeur : un appui sélectionne le composant
 * @param {number} [props.bottomInset]   marge de sécurité en bas
 * @param {string} [props.apiUrl]        adresse du serveur Kubo (chatbot, fil partagé) ; sinon spec.apiUrl
 * @param {string} [props.projectId]     identifiant du projet (fil partagé) ; sinon spec.projectId
 */
export default function AppRuntime({ spec, screenId, onScreenChange, selectedId, onSelect, bottomInset = 0, apiUrl, projectId }) {
  const theme = spec.theme;
  const screens = spec.screens || [];
  const [internal, setInternal] = useState(screens[0] && screens[0].id);
  const current = screenId || internal;
  const screen = useMemo(() => screens.find((x) => x.id === current) || screens[0], [screens, current]);
  const go = (id) => {
    if (!screens.some((x) => x.id === id)) return;
    setInternal(id);
    if (onScreenChange) onScreenChange(id);
  };

  const appValue = { spec, apiUrl: (apiUrl || spec.apiUrl || '').replace(/\/$/, ''), projectId: projectId || spec.projectId || '', go };

  if (!screen) return null;
  return (
    <AppCtx.Provider value={appValue}>
    <ThemeCtx.Provider value={theme}>
      <View style={{ flex: 1, backgroundColor: theme.background }}>
        <ScrollView contentContainerStyle={{ padding: 18, gap: 14, paddingBottom: 30 }} keyboardShouldPersistTaps="handled">
          {screen.components.map((c) => {
            // la clé dépend des props : un composant interactif se réinitialise quand on le modifie dans l'éditeur
            const node = <RenderComponent key={JSON.stringify(c.props)} component={c} go={go} />;
            if (!onSelect) return <View key={c.id}>{node}</View>;
            const sel = selectedId === c.id;
            return (
              <Pressable
                key={c.id}
                onPress={() => onSelect(c.id)}
                style={{ borderRadius: 18, borderWidth: 2, borderColor: sel ? theme.secondary : 'transparent', padding: 2, margin: -4 }}
              >
                <View pointerEvents="none">{node}</View>
              </Pressable>
            );
          })}
          {screen.components.length === 0 && (
            <Text style={{ color: withAlpha(theme.text, 0.5), textAlign: 'center', marginTop: 40 }}>Écran vide</Text>
          )}
        </ScrollView>
        {screens.length > 1 && (
          <View style={[s.tabbar, { backgroundColor: theme.surface, borderTopColor: withAlpha(theme.text, 0.08), paddingBottom: 8 + bottomInset }]}>
            {screens.map((sc) => {
              const active = sc.id === screen.id;
              return (
                <Pressable key={sc.id} onPress={() => go(sc.id)} style={s.tab}>
                  <Ionicons name={safeIcon(sc.icon, 'apps')} size={22} color={active ? theme.primary : withAlpha(theme.text, 0.45)} />
                  <Text numberOfLines={1} style={{ fontSize: 11, marginTop: 2, color: active ? theme.primary : withAlpha(theme.text, 0.45), fontWeight: active ? '700' : '500' }}>{sc.title}</Text>
                </Pressable>
              );
            })}
          </View>
        )}
      </View>
    </ThemeCtx.Provider>
    </AppCtx.Provider>
  );
}

const s = StyleSheet.create({
  h1: { fontSize: 26, fontWeight: '800', letterSpacing: -0.5 },
  sub: { fontSize: 15, marginTop: 4 },
  section: { fontSize: 17, fontWeight: '700', marginBottom: 8 },
  caption: { fontSize: 12, marginTop: 6, textAlign: 'center' },
  imgPh: { borderRadius: 16, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderStyle: 'dashed' },
  btn: { borderRadius: 14, paddingVertical: 14, alignItems: 'center', justifyContent: 'center' },
  btnText: { fontSize: 16, fontWeight: '700' },
  card: { borderRadius: 18, padding: 16, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 12 },
  cardTitle: { fontSize: 16, fontWeight: '700' },
  iconBubble: { width: 42, height: 42, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  listBox: { borderRadius: 18, overflow: 'hidden' },
  listRow: { flexDirection: 'row', alignItems: 'center', padding: 14 },
  label: { fontSize: 13, fontWeight: '600', marginBottom: 6 },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15 },
  stat: { flex: 1, borderRadius: 16, padding: 14, borderWidth: 1, alignItems: 'center' },
  squareBtn: { width: 46, height: 46, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  todoRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10 },
  option: { borderWidth: 1.5, borderRadius: 12, padding: 14, marginBottom: 8, flexDirection: 'row', alignItems: 'center' },
  target: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center', elevation: 8, shadowOpacity: 0.6, shadowRadius: 12 },
  avatar: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  tabbar: { flexDirection: 'row', borderTopWidth: 1, paddingTop: 8 },
  hero: { borderRadius: 24, overflow: 'hidden' },
  heroBtn: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', paddingHorizontal: 18, paddingVertical: 11, borderRadius: 99, marginTop: 14 },
  blob: { position: 'absolute', width: 180, height: 180, borderRadius: 90 },
  tab: { flex: 1, alignItems: 'center' },
});
