'use strict';
const fs = require('node:fs');
const path = require('node:path');

// Chargement minimal d'un fichier .env (sans dépendance externe)
function loadEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const i = line.indexOf('=');
    if (i === -1) continue;
    const key = line.slice(0, i).trim();
    let val = line.slice(i + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1);
    if (process.env[key] === undefined) process.env[key] = val;
  }
}
loadEnv(path.join(__dirname, '..', '.env'));

const env = process.env;
const isProd = env.NODE_ENV === 'production';

const config = {
  port: Number(env.PORT || 4000),
  isProd,
  // Activation gratuite de Premium pour tester (toujours active hors production ;
  // en production seulement si PREMIUM_TEST_MODE=1). Ignorée dès que Stripe est configuré.
  premiumTestMode: !isProd || env.PREMIUM_TEST_MODE === '1',
  publicUrl: (env.PUBLIC_URL || `http://localhost:${env.PORT || 4000}`).replace(/\/$/, ''),
  corsOrigins: (env.CORS_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
  jwtSecret: env.JWT_SECRET || '',
  jwtTtl: Number(env.JWT_TTL_SECONDS || 7 * 24 * 3600),
  dbPath: path.resolve(__dirname, '..', env.DB_PATH || './data/appforge.db'),
  turso: {
    url: env.TURSO_DATABASE_URL || '',
    token: env.TURSO_AUTH_TOKEN || '',
  },
  exportDir: path.resolve(__dirname, '..', env.EXPORT_DIR || './data/exports'),
  ai: {
    provider: (env.AI_PROVIDER || 'anthropic').toLowerCase(),
    anthropicKey: env.ANTHROPIC_API_KEY || '',
    anthropicModel: env.ANTHROPIC_MODEL || 'claude-sonnet-4-5',
    openaiKey: env.OPENAI_API_KEY || '',
    openaiModel: env.OPENAI_MODEL || 'gpt-4o-mini',
    // Pollinations : clé gratuite sur enter.pollinations.ai (API compatible OpenAI)
    pollinationsKey: env.POLLINATIONS_API_KEY || '',
    pollinationsModel: env.POLLINATIONS_MODEL || 'openai',
  },
  expoToken: env.EXPO_TOKEN || '',
  stripe: {
    secretKey: env.STRIPE_SECRET_KEY || '',
    webhookSecret: env.STRIPE_WEBHOOK_SECRET || '',
    priceMonthly: env.STRIPE_PRICE_MONTHLY || '',
    priceYearly: env.STRIPE_PRICE_YEARLY || '',
  },
  // Premium désactivé par défaut : tout est gratuit, avec une limite anti-abus.
  // PREMIUM_ENABLED=1 réactive la formule gratuite limitée + abonnement.
  premiumEnabled: env.PREMIUM_ENABLED === '1',
  limits: {
    freeProjects: 3,
    freeGenerationsPerDay: 10,
    fairUseGenerationsPerDay: Number(env.FAIR_USE_GENERATIONS_PER_DAY || 50),
  },
};

if (!config.jwtSecret || config.jwtSecret.length < 32) {
  if (isProd) {
    throw new Error('JWT_SECRET doit être défini (32 caractères minimum) en production.');
  }
  // En développement uniquement : secret généré une fois et conservé dans data/ (non versionné)
  const secretFile = path.join(path.dirname(config.dbPath), '.dev-jwt-secret');
  fs.mkdirSync(path.dirname(secretFile), { recursive: true });
  if (!fs.existsSync(secretFile)) fs.writeFileSync(secretFile, require('node:crypto').randomBytes(48).toString('hex'), { mode: 0o600 });
  config.jwtSecret = fs.readFileSync(secretFile, 'utf8').trim();
  console.warn('[config] JWT_SECRET absent : secret de développement utilisé (data/.dev-jwt-secret).');
}

module.exports = config;
