'use strict';
// Génération d'applications à partir d'une description en langage naturel.
// 1) Si une clé API est configurée (Anthropic ou OpenAI), le LLM produit un AppSpec JSON.
// 2) Sinon (ou en cas d'échec), un générateur intégré à base de règles prend le relais.
const config = require('../config');
const { sanitizeSpec, COMPONENT_TYPES } = require('../spec');
const { TEMPLATES } = require('../templates');

const SYSTEM_PROMPT = `Tu es le moteur de génération de Kubo, un créateur d'applications mobiles sans code.
Tu réponds UNIQUEMENT avec un objet JSON valide (aucun texte autour, pas de Markdown) au format :
{
  "reply": "courte phrase en français expliquant ce que tu as créé ou modifié",
  "spec": {
    "name": "nom de l'app (max 40 car.)",
    "description": "description courte",
    "icon": "nom d'icône Ionicons (ex: school, briefcase, game-controller, people, checkbox, cart, heart, fitness)",
    "category": "education | business | games | social | productivity | custom",
    "theme": { "primary": "#RRGGBB", "secondary": "#RRGGBB", "background": "#RRGGBB", "surface": "#RRGGBB", "text": "#RRGGBB" },
    "screens": [ { "id": "identifiant_court", "title": "Titre", "icon": "icône Ionicons", "components": [ { "type": "...", "props": { } } ] } ]
  }
}
Types de composants autorisés et leurs props :
- header {title, subtitle}
- text {text, size: sm|md|lg|xl, align: left|center|right, muted: bool}
- image {uri (https uniquement, ex: https://images.unsplash.com/...), height, caption}
- button {label, action: navigate|alert|link, target (id d'écran pour navigate, URL https pour link), message (pour alert), variant: primary|outline}
- card {title, text, icon}
- list {title, items: [{title, subtitle, icon}]}
- input {label, placeholder, keyboard: default|email-address|numeric|phone-pad, multiline}
- stats {items: [{label, value}]}
- divider {}
- todo {title, placeholder, items: [string]}
- quiz {title, questions: [{question, options: [string], answer: index}]}
- counter {label, step, start}
- tapgame {title, duration}
- feed {title, allowPosting, posts: [{author, text, likes}]}
- timer {label, minutes}
- hero {title, subtitle, buttonLabel, target (id d'écran), image (https)} : grande bannière d'accueil
- gallery {title, images: [URL https]} : galerie photo
- video {title, url (lien YouTube ou vidéo https), caption}
- faq {title, items: [{question, answer}]} : questions fréquentes dépliables
- imagegen {title, placeholder, style: auto|realiste|dessin|aquarelle|3d|anime} : générateur d'images par IA
- chatbot {name, welcome, instructions, faq: [{question, answer}]} : assistant conversationnel
- search {title, placeholder, source: app|wikipedia} : moteur de recherche (dans l'app ou sur Wikipédia)
Règles : 1 à 6 écrans, contenu réaliste et en français, thème sombre élégant par défaut,
utilise les composants interactifs (todo, quiz, tapgame, feed, timer, counter, imagegen, chatbot, search) quand c'est pertinent,
et commence souvent l'écran d'accueil par un composant hero.
Si une application existante est fournie, modifie-la selon la demande en conservant le reste.`;

// ---------------- Appel LLM ----------------
/** Fournisseurs disponibles, le préféré (AI_PROVIDER) en premier. */
function providers() {
  const { anthropicKey, openaiKey, pollinationsKey } = config.ai;
  const all = [
    anthropicKey && 'anthropic',
    openaiKey && 'openai',
    pollinationsKey && 'pollinations',
  ].filter(Boolean);
  return all.sort((a, b) => (b === config.ai.provider) - (a === config.ai.provider));
}

const hasLLM = () => providers().length > 0;

async function callProvider(name, { system, messages, maxTokens, json }) {
  const signal = AbortSignal.timeout(60_000);
  const c = config.ai;
  if (name === 'anthropic') {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      signal,
      headers: { 'x-api-key': c.anthropicKey, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: c.anthropicModel, max_tokens: maxTokens, system, messages }),
    });
    if (!r.ok) throw new Error(`Anthropic ${r.status}`);
    const data = await r.json();
    return { text: (data.content || []).map((x) => x.text || '').join(''), engine: `anthropic:${c.anthropicModel}` };
  }
  // OpenAI et Pollinations partagent le même format (chat/completions)
  const isOpenAI = name === 'openai';
  const url = isOpenAI ? 'https://api.openai.com/v1/chat/completions' : 'https://gen.pollinations.ai/v1/chat/completions';
  const model = isOpenAI ? c.openaiModel : c.pollinationsModel;
  const body = { model, max_tokens: maxTokens, messages: [{ role: 'system', content: system }, ...messages] };
  if (json && isOpenAI) body.response_format = { type: 'json_object' };
  const r = await fetch(url, {
    method: 'POST',
    signal,
    headers: { authorization: `Bearer ${isOpenAI ? c.openaiKey : c.pollinationsKey}`, 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`${name} ${r.status}`);
  const data = await r.json();
  return { text: data.choices?.[0]?.message?.content || '', engine: `${name}:${model}` };
}

/** Essaie chaque fournisseur configuré ; renvoie null si aucun n'est disponible. */
async function callLLM(messages, { system = SYSTEM_PROMPT, maxTokens = 8000, json = true } = {}) {
  let lastError = null;
  for (const name of providers()) {
    try {
      return await callProvider(name, { system, messages, maxTokens, json });
    } catch (e) {
      lastError = e;
      console.warn(`[ia] ${name} indisponible :`, e.message);
    }
  }
  if (lastError) throw lastError;
  return null;
}

function extractJson(text) {
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start === -1 || end <= start) throw new Error('Réponse IA sans JSON');
  return JSON.parse(text.slice(start, end + 1));
}

// ---------------- Générateur à base de règles ----------------
const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');

const CATEGORY_KEYWORDS = {
  education: ['ecole', 'education', 'cours', 'quiz', 'apprendre', 'eleve', 'etudiant', 'revision', 'examen', 'school', 'learn', 'formation', 'langue', 'math'],
  games: ['jeu', 'jeux', 'game', 'arcade', 'score', 'reflexe', 'joueur', 'divertissement'],
  social: ['social', 'reseau', 'communaute', 'amis', 'messag', 'discussion', 'publication', 'forum', 'club', 'eglise', 'association'],
  productivity: ['tache', 'todo', 'productiv', 'organis', 'pomodoro', 'concentration', 'focus', 'agenda', 'habitude', 'planning', 'note'],
  business: ['entreprise', 'business', 'boutique', 'magasin', 'vente', 'client', 'restaurant', 'service', 'shop', 'commerce', 'produit', 'salon', 'hotel', 'commande', 'livraison'],
};
CATEGORY_KEYWORDS.custom = ['outils ia', 'outil ia', 'intelligence artificielle', 'studio ia', 'application ia', 'app ia', 'assistant ia', 'chatbot', 'generateur d\'image', 'image ia'];
const CATEGORY_TEMPLATE = {
  custom: 'ai-studio',
  education: 'edu-quiz', games: 'game-tap', social: 'social-community', productivity: 'prod-focus', business: 'biz-vitrine',
};
const COLORS = {
  rouge: ['#EF4444', '#F97316'], red: ['#EF4444', '#F97316'],
  bleu: ['#3B82F6', '#22D3EE'], blue: ['#3B82F6', '#22D3EE'],
  vert: ['#10B981', '#A3E635'], green: ['#10B981', '#A3E635'],
  rose: ['#EC4899', '#F472B6'], pink: ['#EC4899', '#F472B6'],
  orange: ['#F97316', '#FACC15'], jaune: ['#EAB308', '#F97316'],
  violet: ['#8B5CF6', '#22D3EE'], purple: ['#8B5CF6', '#22D3EE'],
  cyan: ['#06B6D4', '#8B5CF6'], or: ['#F59E0B', '#FDE68A'],
};

function detectCategory(text) {
  const t = norm(text);
  let best = 'custom';
  let bestScore = 0;
  for (const [cat, words] of Object.entries(CATEGORY_KEYWORDS)) {
    const score = words.reduce((n, w) => n + (t.includes(w) ? 1 : 0), 0);
    if (score > bestScore) { best = cat; bestScore = score; }
  }
  return best;
}

function detectName(text) {
  const quoted = text.match(/[«"“']\s*([^»"”']{2,40}?)\s*[»"”']/);
  if (quoted) return quoted[1];
  const named = text.match(/(?:appel[ée]e?s?|nomm[ée]e?s?|intitul[ée]e?s?|called|named)\s+([A-Za-zÀ-ÿ0-9][\wÀ-ÿ' -]{1,38})/i);
  if (named) return named[1].split(/[,.;!?]| qui | pour | avec /)[0].trim();
  return null;
}

function detectColor(text) {
  const t = norm(text);
  for (const [word, pair] of Object.entries(COLORS)) {
    if (new RegExp(`\\b${word}\\b`).test(t)) return pair;
  }
  return null;
}

const SNIPPETS = {
  quiz: () => ({ type: 'quiz', props: { title: 'Quiz', questions: [
    { question: 'Question 1 : quelle est la bonne réponse ?', options: ['Réponse A', 'Réponse B', 'Réponse C'], answer: 0 },
    { question: 'Question 2 : vrai ou faux ?', options: ['Vrai', 'Faux'], answer: 0 },
  ] } }),
  todo: () => ({ type: 'todo', props: { title: 'Mes tâches', items: ['Première tâche'] } }),
  contact: () => [
    { type: 'input', props: { label: 'Nom', placeholder: 'Votre nom' } },
    { type: 'input', props: { label: 'Email', placeholder: 'vous@exemple.com', keyboard: 'email-address' } },
    { type: 'input', props: { label: 'Message', placeholder: 'Votre message…', multiline: true } },
    { type: 'button', props: { label: 'Envoyer', action: 'alert', message: 'Message envoyé, merci !' } },
  ],
  timer: () => ({ type: 'timer', props: { label: 'Minuteur', minutes: 25 } }),
  feed: () => ({ type: 'feed', props: { title: 'Fil d’actualité', posts: [{ author: 'Admin', text: 'Bienvenue dans la communauté !', likes: 3 }] } }),
  game: () => ({ type: 'tapgame', props: { title: 'Tape le plus vite possible !', duration: 10 } }),
  counter: () => ({ type: 'counter', props: { label: 'Compteur', step: 1 } }),
  image: () => ({ type: 'image', props: { uri: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800', height: 180 } }),
  stats: () => ({ type: 'stats', props: { items: [{ label: 'Utilisateurs', value: '120' }, { label: 'Note', value: '4,8' }] } }),
  imagegen: () => ({ type: 'imagegen', props: { title: 'Crée une image avec l’IA', style: 'auto' } }),
  chatbot: () => ({ type: 'chatbot', props: {
    name: 'Assistant', welcome: 'Bonjour ! Je suis là pour répondre à tes questions.',
    faq: [{ question: 'Comment vous contacter ?', answer: 'Tu peux nous écrire depuis l’écran Contact.' }],
  } }),
  search: () => ({ type: 'search', props: { title: 'Rechercher', source: 'app' } }),
  wiki: () => ({ type: 'search', props: { title: 'Moteur de recherche', placeholder: 'Cherche sur Wikipédia…', source: 'wikipedia' } }),
  video: () => ({ type: 'video', props: { title: 'Notre vidéo', url: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ', caption: 'Remplace ce lien par ta vidéo dans l’éditeur.' } }),
  gallery: () => ({ type: 'gallery', props: { title: 'Galerie', images: [
    'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=600',
    'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=600',
    'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?w=600',
    'https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=600',
  ] } }),
  faq: () => ({ type: 'faq', props: { title: 'Questions fréquentes', items: [
    { question: 'Comment ça marche ?', answer: 'Explique ici le fonctionnement de ton application.' },
    { question: 'Est-ce gratuit ?', answer: 'Oui, l’application est gratuite.' },
  ] } }),
};
const FEATURE_KEYWORDS = [
  ['imagegen', ['generateur d\'image', 'generateur d’image', 'image ia', 'images ia', 'image par ia', 'images par ia', 'creer des images', 'dessin ia', 'generer des images', 'generer une image']],
  ['chatbot', ['chatbot', 'chat bot', 'assistant', 'robot', 'bot ']],
  ['wiki', ['moteur de recherche', 'wikipedia', 'encyclopedie']],
  ['search', ['recherche', 'rechercher', 'chercher']],
  ['video', ['video']],
  ['gallery', ['galerie', 'album']],
  ['faq', ['faq', 'questions frequentes', 'centre d\'aide']],
  ['quiz', ['quiz', 'qcm']],
  ['todo', ['tache', 'todo', 'liste de choses', 'checklist']],
  ['contact', ['contact', 'formulaire', 'reservation', 'rendez-vous', 'devis', 'inscription']],
  ['timer', ['minuteur', 'chrono', 'pomodoro', 'timer']],
  ['feed', ['fil', 'publication', 'post', 'actualite', 'mur']],
  ['game', ['jeu', 'game', 'reflexe']],
  ['counter', ['compteur', 'quantite', 'counter']],
  ['image', ['photo', 'image']],
  ['stats', ['statistique', 'tableau de bord', 'dashboard', 'chiffres']],
];

function detectFeatures(text) {
  const t = norm(text);
  return FEATURE_KEYWORDS.filter(([, words]) => words.some((w) => t.includes(w))).map(([f]) => f);
}

const asArray = (x) => (Array.isArray(x) ? x : [x]);
const FEATURE_LABEL = {
  imagegen: "un générateur d'images IA", chatbot: 'un chatbot', search: 'une recherche', wiki: 'un moteur de recherche',
  video: 'une vidéo', gallery: 'une galerie', faq: 'une FAQ',
  quiz: 'un quiz', todo: 'une liste de tâches', contact: 'un formulaire de contact', timer: 'un minuteur',
  feed: "un fil d'actualité", game: 'un mini-jeu', counter: 'un compteur', image: 'une image', stats: 'des statistiques',
};

function ruleBasedGenerate(prompt) {
  const category = detectCategory(prompt);
  const base = TEMPLATES.find((t) => t.id === (CATEGORY_TEMPLATE[category] || 'prod-focus'));
  const spec = JSON.parse(JSON.stringify(base.spec));
  const name = detectName(prompt);
  if (name) spec.name = name;
  spec.description = prompt.slice(0, 300);
  spec.category = category === 'custom' ? base.spec.category : category;
  const color = detectColor(prompt);
  if (color) { spec.theme.primary = color[0]; spec.theme.secondary = color[1]; }
  if (spec.screens[0]?.components[0]?.type === 'header') spec.screens[0].components[0].props.title = spec.name;

  // Ajoute les fonctionnalités demandées absentes du modèle de base
  const existing = new Set(spec.screens.flatMap((s) => s.components.map((c) => c.type)));
  const typeOf = {
    quiz: 'quiz', todo: 'todo', timer: 'timer', feed: 'feed', game: 'tapgame', counter: 'counter', image: 'image', stats: 'stats', contact: 'input',
    imagegen: 'imagegen', chatbot: 'chatbot', search: 'search', wiki: 'search', video: 'video', gallery: 'gallery', faq: 'faq',
  };
  const features = detectFeatures(prompt).filter((f) => !(f === 'image' && detectFeatures(prompt).some((x) => ['imagegen', 'gallery'].includes(x)))
    && !(f === 'search' && detectFeatures(prompt).includes('wiki')));
  const added = [];
  for (const f of features) {
    if (existing.has(typeOf[f]) || spec.screens.length >= 6) continue;
    spec.screens.push({
      id: f,
      title: ({ contact: 'Contact', imagegen: 'Studio IA', chatbot: 'Assistant', wiki: 'Recherche', search: 'Recherche', faq: 'FAQ' })[f]
        || FEATURE_LABEL[f].replace(/^(un|une|des) /, '').replace(/^./, (c) => c.toUpperCase()),
      icon: {
        quiz: 'help-circle', todo: 'checkbox', contact: 'mail', timer: 'timer', feed: 'newspaper', game: 'game-controller', counter: 'add-circle',
        image: 'image', stats: 'stats-chart', imagegen: 'color-palette', chatbot: 'chatbubbles', search: 'search', wiki: 'globe',
        video: 'play-circle', gallery: 'images', faq: 'help-buoy',
      }[f],
      components: asArray(SNIPPETS[f]()),
    });
    added.push(FEATURE_LABEL[f]);
  }
  const reply = `J'ai créé « ${spec.name} » (${spec.screens.length} écrans)${added.length ? ` avec ${added.join(', ')}` : ''}. Ouvre l'aperçu pour l'essayer, ou demande-moi des modifications : « ajoute un écran Contact », « mets le thème en bleu »…`;
  return { spec: sanitizeSpec(spec), reply };
}

function ruleBasedRefine(current, instruction) {
  const spec = JSON.parse(JSON.stringify(current));
  const t = norm(instruction);
  const changes = [];

  const color = detectColor(instruction);
  if (color && /(couleur|theme|color|mets|passe|change)/.test(t)) {
    spec.theme.primary = color[0]; spec.theme.secondary = color[1];
    changes.push('la couleur du thème');
  }
  if (/(clair|light|blanc)/.test(t) && /(theme|mode|fond)/.test(t)) {
    Object.assign(spec.theme, { background: '#F7F7FB', surface: '#FFFFFF', text: '#14142B' });
    changes.push('le thème clair');
  } else if (/(sombre|dark|noir)/.test(t) && /(theme|mode|fond)/.test(t)) {
    Object.assign(spec.theme, { background: '#0B0B1A', surface: '#16162E', text: '#F5F5FF' });
    changes.push('le thème sombre');
  }
  const rename = instruction.match(/(?:renomme|appelle|rename)[^«"“]*[«"“]?\s*([^»"”]{2,40}?)\s*[»"”]?\s*$/i);
  if (rename) { spec.name = rename[1].replace(/^(en|l'app|l’app|l'application)\s+/i, '').trim(); changes.push('le nom'); }

  const screenMatch = instruction.match(/(?:ajoute|cr[ée]e|add)\s+(?:un|une|a)?\s*(?:nouvel?\s+)?(?:[ée]cran|page|screen)\s+(?:de\s+|d'|appel[ée]e?\s+)?[«"“]?([A-Za-zÀ-ÿ0-9' -]{2,30})/i);
  const features = detectFeatures(instruction);
  if (screenMatch && spec.screens.length < 8) {
    const title = screenMatch[1].trim().replace(/^./, (c) => c.toUpperCase());
    const comps = features.length ? features.flatMap((f) => asArray(SNIPPETS[f]())) : [{ type: 'header', props: { title } }, { type: 'text', props: { text: 'Contenu de la page.' } }];
    spec.screens.push({ id: norm(title).replace(/[^a-z0-9]+/g, '_').slice(0, 24) || 'page', title, icon: 'document-text', components: comps });
    changes.push(`l'écran « ${title} »`);
  } else if (/(ajoute|add|mets|insere)/.test(t) && features.length) {
    const target = spec.screens[0];
    for (const f of features) target.components.push(...asArray(SNIPPETS[f]()));
    changes.push(features.map((f) => FEATURE_LABEL[f]).join(', '));
  }
  if (/(ajoute|add).*(bouton|button)/.test(t) && !features.length) {
    spec.screens[0].components.push({ type: 'button', props: { label: 'Nouveau bouton', action: 'alert', message: 'Bonjour !' } });
    changes.push('un bouton');
  }

  if (!changes.length) {
    return {
      spec: sanitizeSpec(spec),
      reply: "Je n'ai pas bien compris la modification. Essaie par exemple : « ajoute un écran Contact », « ajoute un quiz », « mets la couleur en vert », « renomme en \"Super App\" ». Tu peux aussi tout modifier dans l'éditeur visuel.",
      changed: false,
    };
  }
  return { spec: sanitizeSpec(spec), reply: `C'est fait ! J'ai mis à jour ${changes.join(' et ')}.`, changed: true };
}

// ---------------- API publique ----------------
async function generateApp({ prompt, currentSpec }) {
  const llmMessages = currentSpec
    ? [{ role: 'user', content: `Application actuelle :\n${JSON.stringify(currentSpec)}\n\nModification demandée : ${prompt}` }]
    : [{ role: 'user', content: `Crée une application mobile : ${prompt}` }];
  try {
    const out = await callLLM(llmMessages);
    if (out) {
      const parsed = extractJson(out.text);
      const spec = sanitizeSpec(parsed.spec || parsed);
      const hasContent = spec.screens.some((s) => s.components.length);
      if (hasContent) {
        return { spec, reply: String(parsed.reply || 'Voici ton application !').slice(0, 500), engine: out.engine };
      }
    }
  } catch (e) {
    console.warn('[ia] bascule vers le générateur intégré :', e.message);
  }
  const res = currentSpec ? ruleBasedRefine(sanitizeSpec(currentSpec), prompt) : ruleBasedGenerate(prompt);
  return { ...res, engine: 'builtin' };
}

/** Réponse d'un chatbot intégré à une application générée. */
async function chatbotReply({ botName, instructions, messages }) {
  if (!hasLLM()) return null;
  const system = `Tu es « ${botName} », l'assistant d'une application mobile créée avec Kubo.
${instructions ? `Consignes du créateur de l'application : ${instructions}\n` : ''}Réponds dans la langue de l'utilisateur (français par défaut), de façon claire, aimable et brève (5 phrases maximum).
Refuse poliment les demandes dangereuses ou illégales.`;
  const out = await callLLM(messages, { system, maxTokens: 500, json: false });
  return out ? out.text.trim().slice(0, 2000) : null;
}

module.exports = { chatbotReply, hasLLM, generateApp, ruleBasedGenerate, ruleBasedRefine, detectCategory, COMPONENT_TYPES };
