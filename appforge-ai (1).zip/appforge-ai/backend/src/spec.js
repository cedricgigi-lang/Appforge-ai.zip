'use strict';
// Validation et normalisation du format d'application APPFORGE (« AppSpec »).
// Toute spécification (générée par l'IA, issue d'un modèle ou envoyée par l'éditeur)
// passe par sanitizeSpec() avant d'être enregistrée : types inconnus supprimés,
// longueurs bornées, couleurs et URL vérifiées.
const crypto = require('node:crypto');

const COMPONENT_TYPES = [
  'header', 'text', 'image', 'button', 'card', 'list', 'input', 'stats',
  'divider', 'todo', 'quiz', 'counter', 'tapgame', 'feed', 'timer',
  // Composants « IA & médias »
  'hero', 'gallery', 'video', 'faq', 'imagegen', 'chatbot', 'search',
];
const IMAGE_STYLES = ['auto', 'realiste', 'dessin', 'aquarelle', '3d', 'anime'];
const CATEGORIES = ['education', 'business', 'games', 'social', 'productivity', 'custom'];

const DEFAULT_THEME = {
  primary: '#8B5CF6',
  secondary: '#22D3EE',
  background: '#0B0B1A',
  surface: '#16162E',
  text: '#F5F5FF',
};

const str = (v, max, def = '') => (typeof v === 'string' ? v.trim().slice(0, max) : typeof v === 'number' ? String(v).slice(0, max) : def);
const int = (v, min, max, def) => {
  const n = Number.parseInt(v, 10);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : def;
};
const hex = (v, def) => (typeof v === 'string' && /^#([0-9a-fA-F]{6})$/.test(v.trim()) ? v.trim().toUpperCase() : def);
const icon = (v, def = 'apps') => (typeof v === 'string' && /^[a-z0-9-]{2,40}$/.test(v) ? v : def);
const httpsUrl = (v) => {
  if (typeof v !== 'string') return '';
  try {
    const u = new URL(v.trim());
    return u.protocol === 'https:' ? u.toString().slice(0, 500) : '';
  } catch { return ''; }
};
const arr = (v, max) => (Array.isArray(v) ? v.slice(0, max) : []);
const shortId = () => crypto.randomBytes(5).toString('hex');
const slugId = (v) => (typeof v === 'string' && /^[a-zA-Z0-9_-]{1,32}$/.test(v) ? v : shortId());

function sanitizeProps(type, p = {}, screenIds) {
  switch (type) {
    case 'header':
      return { title: str(p.title, 60, 'Titre'), subtitle: str(p.subtitle, 140) };
    case 'text':
      return {
        text: str(p.text, 1000, 'Texte'),
        size: ['sm', 'md', 'lg', 'xl'].includes(p.size) ? p.size : 'md',
        align: ['left', 'center', 'right'].includes(p.align) ? p.align : 'left',
        muted: Boolean(p.muted),
      };
    case 'image':
      return { uri: httpsUrl(p.uri), height: int(p.height, 80, 400, 180), caption: str(p.caption, 120) };
    case 'button': {
      const action = ['navigate', 'alert', 'link'].includes(p.action) ? p.action : 'alert';
      let target = str(p.target, 300);
      if (action === 'navigate' && !screenIds.includes(target)) target = screenIds[0] || '';
      if (action === 'link') target = httpsUrl(target);
      return {
        label: str(p.label, 40, 'Bouton'),
        action,
        target,
        message: str(p.message, 200),
        variant: ['primary', 'outline'].includes(p.variant) ? p.variant : 'primary',
      };
    }
    case 'card':
      return { title: str(p.title, 80, 'Carte'), text: str(p.text, 400), icon: icon(p.icon, 'sparkles') };
    case 'list':
      return {
        title: str(p.title, 60),
        items: arr(p.items, 30).map((it) => ({
          title: str(it && it.title, 80, 'Élément'),
          subtitle: str(it && it.subtitle, 140),
          icon: icon(it && it.icon, 'ellipse'),
        })),
      };
    case 'input':
      return {
        label: str(p.label, 60, 'Champ'),
        placeholder: str(p.placeholder, 80),
        keyboard: ['default', 'email-address', 'numeric', 'phone-pad'].includes(p.keyboard) ? p.keyboard : 'default',
        multiline: Boolean(p.multiline),
      };
    case 'stats':
      return {
        items: arr(p.items, 6).map((it) => ({ label: str(it && it.label, 30, 'Stat'), value: str(it && it.value, 20, '0') })),
      };
    case 'divider':
      return {};
    case 'todo':
      return {
        title: str(p.title, 60, 'Mes tâches'),
        placeholder: str(p.placeholder, 80, 'Nouvelle tâche…'),
        items: arr(p.items, 50).map((t) => str(typeof t === 'object' && t ? t.text : t, 120)).filter(Boolean),
      };
    case 'quiz':
      return {
        title: str(p.title, 60, 'Quiz'),
        questions: arr(p.questions, 20)
          .map((q) => {
            const options = arr(q && q.options, 5).map((o) => str(o, 100)).filter(Boolean);
            return { question: str(q && q.question, 200), options, answer: int(q && q.answer, 0, Math.max(0, options.length - 1), 0) };
          })
          .filter((q) => q.question && q.options.length >= 2),
      };
    case 'counter':
      return { label: str(p.label, 40, 'Compteur'), step: int(p.step, 1, 100, 1), start: int(p.start, -1e6, 1e6, 0) };
    case 'tapgame':
      return { title: str(p.title, 60, 'Tape le plus vite possible !'), duration: int(p.duration, 5, 60, 10) };
    case 'feed':
      return {
        title: str(p.title, 60, "Fil d'actualité"),
        allowPosting: p.allowPosting !== false,
        posts: arr(p.posts, 30).map((po) => ({
          author: str(po && po.author, 40, 'Utilisateur'),
          text: str(po && po.text, 400),
          likes: int(po && po.likes, 0, 1e6, 0),
        })).filter((po) => po.text),
      };
    case 'timer':
      return { label: str(p.label, 40, 'Minuteur'), minutes: int(p.minutes, 1, 120, 25) };
    case 'hero': {
      const target = str(p.target, 32);
      return {
        title: str(p.title, 60, 'Bienvenue'),
        subtitle: str(p.subtitle, 160),
        buttonLabel: str(p.buttonLabel, 30),
        target: screenIds.includes(target) ? target : '',
        image: httpsUrl(p.image),
      };
    }
    case 'gallery':
      return { title: str(p.title, 60), images: arr(p.images, 12).map(httpsUrl).filter(Boolean) };
    case 'video':
      return { title: str(p.title, 80, 'Vidéo'), url: httpsUrl(p.url), caption: str(p.caption, 160) };
    case 'faq':
      return {
        title: str(p.title, 60, 'Questions fréquentes'),
        items: arr(p.items, 20).map((it) => ({ question: str(it && it.question, 150), answer: str(it && it.answer, 600) })).filter((it) => it.question),
      };
    case 'imagegen':
      return {
        title: str(p.title, 60, 'Générateur d’images IA'),
        placeholder: str(p.placeholder, 100, 'Décris l’image à créer…'),
        style: IMAGE_STYLES.includes(p.style) ? p.style : 'auto',
      };
    case 'chatbot':
      return {
        name: str(p.name, 40, 'Assistant'),
        welcome: str(p.welcome, 200, 'Bonjour ! Comment puis-je t’aider ?'),
        instructions: str(p.instructions, 600),
        faq: arr(p.faq, 30).map((it) => ({ question: str(it && it.question, 150), answer: str(it && it.answer, 600) })).filter((it) => it.question && it.answer),
      };
    case 'search':
      return {
        title: str(p.title, 60, 'Rechercher'),
        placeholder: str(p.placeholder, 80, 'Que cherches-tu ?'),
        source: p.source === 'wikipedia' ? 'wikipedia' : 'app',
      };
    default:
      return {};
  }
}

function sanitizeSpec(input) {
  const s = input && typeof input === 'object' ? input : {};
  const t = s.theme && typeof s.theme === 'object' ? s.theme : {};
  const rawScreens = arr(s.screens, 8);
  const screens = (rawScreens.length ? rawScreens : [{ title: 'Accueil', components: [] }]).map((sc, i) => ({
    id: slugId(sc && sc.id) || `screen${i}`,
    title: str(sc && sc.title, 30, `Écran ${i + 1}`),
    icon: icon(sc && sc.icon, 'home'),
    _components: arr(sc && sc.components, 30),
  }));
  // Identifiants d'écran uniques
  const seen = new Set();
  for (const sc of screens) {
    while (seen.has(sc.id)) sc.id = shortId();
    seen.add(sc.id);
  }
  const screenIds = screens.map((sc) => sc.id);
  const compIds = new Set();
  const uniqueCompId = (v) => {
    let id = slugId(v);
    while (compIds.has(id)) id = shortId();
    compIds.add(id);
    return id;
  };

  return {
    version: 1,
    name: str(s.name, 40, 'Mon application'),
    description: str(s.description, 300),
    icon: icon(s.icon, 'rocket'),
    category: CATEGORIES.includes(s.category) ? s.category : 'custom',
    theme: {
      primary: hex(t.primary, DEFAULT_THEME.primary),
      secondary: hex(t.secondary, DEFAULT_THEME.secondary),
      background: hex(t.background, DEFAULT_THEME.background),
      surface: hex(t.surface, DEFAULT_THEME.surface),
      text: hex(t.text, DEFAULT_THEME.text),
    },
    screens: screens.map(({ _components, ...sc }) => ({
      ...sc,
      components: _components
        .filter((c) => c && COMPONENT_TYPES.includes(c.type))
        .map((c) => ({ id: uniqueCompId(c.id), type: c.type, props: sanitizeProps(c.type, c.props || {}, screenIds) })),
    })),
  };
}

module.exports = { sanitizeSpec, COMPONENT_TYPES, CATEGORIES, DEFAULT_THEME, IMAGE_STYLES };
