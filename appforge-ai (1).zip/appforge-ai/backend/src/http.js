'use strict';
// Micro-framework HTTP sans dépendance : routage, JSON, en-têtes de sécurité, CORS, erreurs.
const config = require('./config');

class HttpError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code || 'error';
  }
}

const MAX_BODY = 1024 * 1024; // 1 Mo

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(new HttpError(413, 'Requête trop volumineuse.', 'payload_too_large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'");
  res.setHeader('Cross-Origin-Resource-Policy', 'same-site');
  if (config.isProd) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}

function cors(req, res) {
  const origin = req.headers.origin;
  if (origin && config.corsOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    res.setHeader('Access-Control-Max-Age', '600');
  }
}

function send(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

class Router {
  constructor() {
    this.routes = [];
  }
  add(method, pattern, ...handlers) {
    const keys = [];
    const re = new RegExp(
      '^' + pattern.replace(/\/:([a-zA-Z_]+)/g, (_, k) => { keys.push(k); return '/([^/]+)'; }) + '/?$'
    );
    this.routes.push({ method, re, keys, handlers });
  }
  get(p, ...h) { this.add('GET', p, ...h); }
  post(p, ...h) { this.add('POST', p, ...h); }
  put(p, ...h) { this.add('PUT', p, ...h); }
  patch(p, ...h) { this.add('PATCH', p, ...h); }
  delete(p, ...h) { this.add('DELETE', p, ...h); }

  handler() {
    return async (req, res) => {
      securityHeaders(res);
      cors(req, res);
      if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
      const url = new URL(req.url, 'http://localhost');
      req.path = url.pathname;
      req.query = Object.fromEntries(url.searchParams);
      const fwd = process.env.TRUST_PROXY === '1' && req.headers['x-forwarded-for'];
      req.ip = (fwd ? String(fwd).split(',')[0].trim() : req.socket.remoteAddress) || 'unknown';
      try {
        const route = this.routes.find((r) => r.method === req.method && r.re.test(req.path));
        if (!route) throw new HttpError(404, 'Ressource introuvable.', 'not_found');
        const m = req.path.match(route.re);
        req.params = {};
        route.keys.forEach((k, i) => { req.params[k] = decodeURIComponent(m[i + 1]); });
        if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
          req.rawBody = await readBody(req);
          const ct = req.headers['content-type'] || '';
          if (req.rawBody.length && ct.includes('application/json')) {
            try { req.body = JSON.parse(req.rawBody.toString('utf8')); }
            catch { throw new HttpError(400, 'JSON invalide.', 'invalid_json'); }
          } else req.body = {};
        }
        for (const h of route.handlers) {
          const out = await h(req, res);
          if (res.headersSent) return;
          if (out !== undefined) return send(res, res.statusCode && res.statusCode !== 200 ? res.statusCode : 200, out);
        }
        if (!res.headersSent) send(res, 204, {});
      } catch (err) {
        if (res.headersSent) { res.destroy(); return; }
        if (err instanceof HttpError) return send(res, err.status, { error: err.code, message: err.message });
        console.error('[erreur]', err);
        send(res, 500, { error: 'server_error', message: 'Une erreur interne est survenue.' });
      }
    };
  }
}

module.exports = { Router, HttpError, send };
