'use strict';
const http = require('node:http');
const config = require('./config');
const { openDb } = require('./db');
const { Router } = require('./http');
const { rateLimiter } = require('./security');
const { HttpError } = require('./http');

async function createApp({ db } = {}) {
  const database = db || await openDb();
  const router = new Router();
  const globalLimiter = rateLimiter({ windowMs: 60_000, max: 300 });

  // Limite globale par IP (anti-abus)
  const origAdd = router.add.bind(router);
  router.add = (method, pattern, ...handlers) => origAdd(method, pattern, (req) => {
    if (!globalLimiter(req.ip)) throw new HttpError(429, 'Trop de requêtes.', 'rate_limited');
  }, ...handlers);

  router.get('/api/health', () => ({
    ok: true, name: 'Kubo', version: '1.1.0',
    ai: require('./ai/generator').hasLLM() ? 'llm' : 'builtin',
    premiumEnabled: config.premiumEnabled,
    database: database.kind,
  }));

  const ctx = { db: database };
  require('./routes/auth')(router, ctx);
  require('./routes/projects')(router, ctx);
  require('./routes/exports')(router, ctx);
  require('./routes/billing')(router, ctx);
  require('./routes/public')(router, ctx);

  return { server: http.createServer(router.handler()), db: database };
}

if (require.main === module) {
  createApp().then(({ server, db }) => {
    server.requestTimeout = 120_000;
    server.listen(config.port, () => {
      console.log(`🚀 Kubo API sur http://localhost:${config.port} (${config.isProd ? 'production' : 'développement'}, base : ${db.kind})`);
    });
  }).catch((e) => {
    console.error('❌ Démarrage impossible :', e.message);
    process.exit(1);
  });
}

module.exports = { createApp };
