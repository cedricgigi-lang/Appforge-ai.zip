'use strict';
// Accès à la base de données.
// - Par défaut : fichier SQLite local (module node:sqlite intégré à Node).
// - Si TURSO_DATABASE_URL est défini : base Turso (SQLite en ligne, offre gratuite),
//   via son API HTTP — indispensable sur les hébergeurs gratuits dont le disque est effacé
//   à chaque redémarrage (Render Free…).
// Les deux implémentations exposent la même interface asynchrone :
//   get(sql, ...params) → première ligne | undefined
//   all(sql, ...params) → tableau de lignes
//   run(sql, ...params) → { changes }
//   exec(sql)           → exécute un script (plusieurs requêtes séparées par « ; »)
const fs = require('node:fs');
const path = require('node:path');
const config = require('./config');

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    plan TEXT NOT NULL DEFAULT 'free',
    premium_until INTEGER,
    stripe_customer_id TEXT,
    language TEXT NOT NULL DEFAULT 'fr',
    token_version INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL DEFAULT 'custom',
    spec TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id, updated_at DESC);
  CREATE TABLE IF NOT EXISTS generations (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    prompt TEXT NOT NULL,
    engine TEXT NOT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_generations_user ON generations(user_id, created_at);
  CREATE TABLE IF NOT EXISTS exports (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    mode TEXT NOT NULL,
    status TEXT NOT NULL,
    file_path TEXT,
    build_url TEXT,
    message TEXT,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_exports_user ON exports(user_id, created_at DESC);
  CREATE TABLE IF NOT EXISTS posts (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    author TEXT NOT NULL,
    text TEXT NOT NULL,
    likes INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_posts_project ON posts(project_id, created_at DESC);
`;

const splitStatements = (sql) => sql.split(';').map((s) => s.trim()).filter(Boolean);

// ---------------------------------------------------------------- SQLite local
class LocalDb {
  constructor(file) {
    const { DatabaseSync } = require('node:sqlite');
    if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
    this.d = new DatabaseSync(file);
    this.d.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
    this.kind = 'sqlite';
  }
  async get(sql, ...params) { return this.d.prepare(sql).get(...params); }
  async all(sql, ...params) { return this.d.prepare(sql).all(...params); }
  async run(sql, ...params) { return { changes: Number(this.d.prepare(sql).run(...params).changes) }; }
  async exec(sql) { this.d.exec(sql); }
}

// ---------------------------------------------------------------- Turso (HTTP)
function encodeArg(v) {
  if (v === null || v === undefined) return { type: 'null' };
  if (typeof v === 'boolean') return { type: 'integer', value: v ? '1' : '0' };
  if (typeof v === 'number') {
    return Number.isInteger(v) ? { type: 'integer', value: String(v) } : { type: 'float', value: v };
  }
  if (typeof v === 'bigint') return { type: 'integer', value: v.toString() };
  if (Buffer.isBuffer(v)) return { type: 'blob', base64: v.toString('base64') };
  return { type: 'text', value: String(v) };
}

function decodeValue(v) {
  if (!v || v.type === 'null') return null;
  if (v.type === 'integer') return Number(v.value);
  if (v.type === 'float') return Number(v.value);
  if (v.type === 'blob') return Buffer.from(v.base64 || '', 'base64');
  return v.value;
}

class TursoDb {
  constructor(url, token, fetchImpl = fetch) {
    this.baseUrl = url.replace(/^(libsql|turso|wss?):\/\//, 'https://').replace(/\/$/, '');
    this.token = token;
    this.fetch = fetchImpl;
    this.kind = 'turso';
  }

  async pipeline(statements) {
    const requests = statements.map(([sql, args]) => ({ type: 'execute', stmt: { sql, args: (args || []).map(encodeArg) } }));
    requests.push({ type: 'close' });
    let res;
    try {
      res = await this.fetch(`${this.baseUrl}/v2/pipeline`, {
        method: 'POST',
        headers: { authorization: `Bearer ${this.token}`, 'content-type': 'application/json' },
        body: JSON.stringify({ requests }),
        signal: AbortSignal.timeout(15_000),
      });
    } catch (e) {
      throw new Error(`Base Turso injoignable : ${e.message}`);
    }
    if (!res.ok) throw new Error(`Base Turso : HTTP ${res.status} ${(await res.text()).slice(0, 200)}`);
    const data = await res.json();
    return data.results.slice(0, statements.length).map((r) => {
      if (r.type !== 'ok') throw new Error(`Erreur SQL Turso : ${(r.error && r.error.message) || 'inconnue'}`);
      const result = r.response.result;
      const cols = result.cols.map((c) => c.name);
      const rows = result.rows.map((row) => {
        const o = {};
        cols.forEach((c, i) => { o[c] = decodeValue(row[i]); });
        return o;
      });
      return { rows, changes: result.affected_row_count || 0 };
    });
  }

  async get(sql, ...params) { return (await this.pipeline([[sql, params]]))[0].rows[0]; }
  async all(sql, ...params) { return (await this.pipeline([[sql, params]]))[0].rows; }
  async run(sql, ...params) { return { changes: (await this.pipeline([[sql, params]]))[0].changes }; }
  async exec(sql) { await this.pipeline(splitStatements(sql).map((s) => [s, []])); }
}

/** Ouvre la base (Turso si configuré, sinon SQLite local) et crée les tables. */
async function openDb(file = config.dbPath) {
  const db = config.turso.url && file !== ':memory:'
    ? new TursoDb(config.turso.url, config.turso.token)
    : new LocalDb(file);
  await db.exec(SCHEMA);
  return db;
}

module.exports = { openDb, LocalDb, TursoDb, SCHEMA };
