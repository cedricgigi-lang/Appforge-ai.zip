'use strict';
// Modèles d'applications prêts à l'emploi (en français).
const { sanitizeSpec } = require('./spec');

const RAW_TEMPLATES = [
  {
    id: 'edu-quiz',
    title: 'Quiz Éducatif',
    summary: 'Révisions avec quiz interactifs, fiches de cours et suivi de progression.',
    spec: {
      name: 'Quiz Master',
      description: 'Apprends en t’amusant avec des quiz interactifs.',
      icon: 'school',
      category: 'education',
      theme: { primary: '#8B5CF6', secondary: '#22D3EE', background: '#0B0B1A', surface: '#17172F', text: '#F5F5FF' },
      screens: [
        {
          id: 'home', title: 'Accueil', icon: 'home', components: [
            { type: 'header', props: { title: 'Quiz Master', subtitle: 'Révise en 5 minutes par jour' } },
            { type: 'stats', props: { items: [{ label: 'Quiz', value: '12' }, { label: 'Score moyen', value: '78%' }, { label: 'Série', value: '4 j' }] } },
            { type: 'card', props: { title: 'Quiz du jour', text: 'Culture générale : 3 questions pour bien commencer.', icon: 'bulb' } },
            { type: 'button', props: { label: 'Commencer le quiz', action: 'navigate', target: 'quiz' } },
          ],
        },
        {
          id: 'quiz', title: 'Quiz', icon: 'help-circle', components: [
            { type: 'quiz', props: { title: 'Culture générale', questions: [
              { question: 'Quelle est la capitale du Canada ?', options: ['Toronto', 'Ottawa', 'Montréal'], answer: 1 },
              { question: 'Combien de continents compte la Terre ?', options: ['5', '6', '7'], answer: 2 },
              { question: 'Quel est le plus grand océan ?', options: ['Atlantique', 'Indien', 'Pacifique'], answer: 2 },
            ] } },
          ],
        },
        {
          id: 'courses', title: 'Cours', icon: 'book', components: [
            { type: 'list', props: { title: 'Fiches de révision', items: [
              { title: 'Géographie', subtitle: 'Capitales et continents', icon: 'earth' },
              { title: 'Sciences', subtitle: 'Le système solaire', icon: 'planet' },
              { title: 'Histoire', subtitle: 'Les grandes civilisations', icon: 'library' },
            ] } },
          ],
        },
      ],
    },
  },
  {
    id: 'biz-vitrine',
    title: 'Vitrine Entreprise',
    summary: 'Présente tes services, tes tarifs et reçois des demandes de contact.',
    spec: {
      name: 'Mon Entreprise',
      description: 'Application vitrine pour présenter une entreprise locale.',
      icon: 'briefcase',
      category: 'business',
      theme: { primary: '#6366F1', secondary: '#06B6D4', background: '#0A0F1E', surface: '#141B2E', text: '#F1F5FF' },
      screens: [
        {
          id: 'home', title: 'Accueil', icon: 'home', components: [
            { type: 'header', props: { title: 'Bienvenue', subtitle: 'Des services de qualité près de chez vous' } },
            { type: 'image', props: { uri: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800', height: 180, caption: 'Nos bureaux' } },
            { type: 'card', props: { title: 'Pourquoi nous choisir ?', text: '10 ans d’expérience, devis gratuit sous 24 h et satisfaction garantie.', icon: 'ribbon' } },
            { type: 'button', props: { label: 'Demander un devis', action: 'navigate', target: 'contact' } },
          ],
        },
        {
          id: 'services', title: 'Services', icon: 'pricetags', components: [
            { type: 'list', props: { title: 'Nos offres', items: [
              { title: 'Conseil', subtitle: 'À partir de 50 $ / heure', icon: 'chatbubbles' },
              { title: 'Installation', subtitle: 'Forfait dès 150 $', icon: 'construct' },
              { title: 'Maintenance', subtitle: 'Abonnement mensuel', icon: 'shield-checkmark' },
            ] } },
          ],
        },
        {
          id: 'contact', title: 'Contact', icon: 'mail', components: [
            { type: 'header', props: { title: 'Contactez-nous', subtitle: 'Réponse sous 24 h' } },
            { type: 'input', props: { label: 'Nom complet', placeholder: 'Jean Dupont' } },
            { type: 'input', props: { label: 'Email', placeholder: 'jean@exemple.com', keyboard: 'email-address' } },
            { type: 'input', props: { label: 'Message', placeholder: 'Décrivez votre besoin…', multiline: true } },
            { type: 'button', props: { label: 'Envoyer', action: 'alert', message: 'Merci ! Nous vous recontactons très vite.' } },
          ],
        },
      ],
    },
  },
  {
    id: 'game-tap',
    title: 'Jeu de Réflexes',
    summary: 'Un mini-jeu d’arcade : tape le plus vite possible avant la fin du chrono.',
    spec: {
      name: 'Tap Challenge',
      description: 'Teste tes réflexes et bats ton record !',
      icon: 'game-controller',
      category: 'games',
      theme: { primary: '#EC4899', secondary: '#22D3EE', background: '#0D0618', surface: '#1C1030', text: '#FFF5FB' },
      screens: [
        {
          id: 'play', title: 'Jouer', icon: 'game-controller', components: [
            { type: 'header', props: { title: 'Tap Challenge', subtitle: '10 secondes pour marquer un max de points' } },
            { type: 'tapgame', props: { title: 'Tape sur la cible !', duration: 10 } },
          ],
        },
        {
          id: 'rules', title: 'Règles', icon: 'information-circle', components: [
            { type: 'card', props: { title: 'Comment jouer', text: 'Appuie sur « Démarrer », puis tape sur la cible autant de fois que possible avant la fin du temps.', icon: 'hand-left' } },
            { type: 'counter', props: { label: 'Parties jouées', step: 1 } },
          ],
        },
      ],
    },
  },
  {
    id: 'social-community',
    title: 'Réseau Communautaire',
    summary: 'Un fil d’actualité où les membres publient et aiment des messages.',
    spec: {
      name: 'Ma Communauté',
      description: 'Le réseau social de ton club, ton école ou ton quartier.',
      icon: 'people',
      category: 'social',
      theme: { primary: '#A855F7', secondary: '#38BDF8', background: '#0A0A16', surface: '#15152A', text: '#F8F7FF' },
      screens: [
        {
          id: 'feed', title: 'Fil', icon: 'newspaper', components: [
            { type: 'hero', props: { title: 'Ma Communauté', subtitle: 'Partage, échange et reste connecté avec les membres.', buttonLabel: 'Voir les membres', target: 'members' } },
            { type: 'feed', props: { title: 'Quoi de neuf ?', allowPosting: true, posts: [
              { author: 'Amina', text: 'Réunion du club samedi à 10 h, venez nombreux ! 🎉', likes: 12 },
              { author: 'Lucas', text: 'Qui est partant pour un match de foot dimanche ?', likes: 5 },
            ] } },
          ],
        },
        {
          id: 'members', title: 'Membres', icon: 'people', components: [
            { type: 'list', props: { title: 'Membres actifs', items: [
              { title: 'Amina K.', subtitle: 'Organisatrice', icon: 'person-circle' },
              { title: 'Lucas M.', subtitle: 'Membre', icon: 'person-circle' },
              { title: 'Grace T.', subtitle: 'Membre', icon: 'person-circle' },
            ] } },
          ],
        },
        {
          id: 'profile', title: 'Profil', icon: 'person', components: [
            { type: 'header', props: { title: 'Mon profil' } },
            { type: 'input', props: { label: 'Pseudo', placeholder: 'Ton pseudo' } },
            { type: 'input', props: { label: 'Bio', placeholder: 'Parle-nous de toi…', multiline: true } },
            { type: 'button', props: { label: 'Enregistrer', action: 'alert', message: 'Profil mis à jour !' } },
          ],
        },
      ],
    },
  },
  {
    id: 'prod-focus',
    title: 'Tâches & Concentration',
    summary: 'Liste de tâches et minuteur Pomodoro pour rester productif.',
    spec: {
      name: 'Focus Pro',
      description: 'Organise ta journée et reste concentré.',
      icon: 'checkbox',
      category: 'productivity',
      theme: { primary: '#7C3AED', secondary: '#2DD4BF', background: '#090B14', surface: '#141826', text: '#EEF2FF' },
      screens: [
        {
          id: 'tasks', title: 'Tâches', icon: 'checkbox', components: [
            { type: 'header', props: { title: 'Aujourd’hui', subtitle: 'Concentre-toi sur l’essentiel' } },
            { type: 'todo', props: { title: 'Mes tâches', placeholder: 'Ajouter une tâche…', items: ['Répondre aux emails', 'Préparer la réunion', 'Faire du sport'] } },
          ],
        },
        {
          id: 'focus', title: 'Focus', icon: 'timer', components: [
            { type: 'timer', props: { label: 'Session Pomodoro', minutes: 25 } },
            { type: 'text', props: { text: 'Travaille 25 minutes, puis fais une pause de 5 minutes.', align: 'center', muted: true } },
          ],
        },
      ],
    },
  },
  {
    id: 'biz-shop',
    title: 'Boutique Locale',
    summary: 'Catalogue de produits avec promotions et prise de commande simple.',
    spec: {
      name: 'Ma Boutique',
      description: 'Catalogue mobile pour une petite boutique.',
      icon: 'cart',
      category: 'business',
      theme: { primary: '#F59E0B', secondary: '#8B5CF6', background: '#0F0A05', surface: '#1E160C', text: '#FFF8EE' },
      screens: [
        {
          id: 'catalog', title: 'Catalogue', icon: 'storefront', components: [
            { type: 'header', props: { title: 'Nouveautés', subtitle: 'Livraison gratuite dès 30 $' } },
            { type: 'list', props: { items: [
              { title: 'Sac en wax', subtitle: '25 $', icon: 'bag-handle' },
              { title: 'Chemise en lin', subtitle: '32 $', icon: 'shirt' },
              { title: 'Sandales cuir', subtitle: '40 $', icon: 'footsteps' },
            ] } },
            { type: 'button', props: { label: 'Commander', action: 'navigate', target: 'order' } },
          ],
        },
        {
          id: 'order', title: 'Commande', icon: 'cart', components: [
            { type: 'input', props: { label: 'Produit souhaité', placeholder: 'Ex : Sac en wax' } },
            { type: 'counter', props: { label: 'Quantité', step: 1, start: 1 } },
            { type: 'input', props: { label: 'Téléphone', placeholder: '+243 …', keyboard: 'phone-pad' } },
            { type: 'button', props: { label: 'Valider la commande', action: 'alert', message: 'Commande envoyée ! Nous vous appelons pour confirmer.' } },
          ],
        },
      ],
    },
  },
];

RAW_TEMPLATES.push({
  id: 'ai-studio',
  title: 'Studio IA',
  summary: 'Générateur d’images par IA, chatbot et moteur de recherche réunis dans une seule app.',
  spec: {
    name: 'Studio IA',
    description: 'Tes outils d’intelligence artificielle dans la poche.',
    icon: 'sparkles',
    category: 'custom',
    theme: { primary: '#A855F7', secondary: '#22D3EE', background: '#080718', surface: '#15132E', text: '#F7F5FF' },
    screens: [
      {
        id: 'home', title: 'Accueil', icon: 'home', components: [
          { type: 'hero', props: { title: 'Studio IA', subtitle: 'Crée des images, discute avec ton assistant et cherche tout ce que tu veux.', buttonLabel: 'Créer une image', target: 'images' } },
          { type: 'stats', props: { items: [{ label: 'Outils IA', value: '3' }, { label: 'Gratuit', value: '100 %' }] } },
          { type: 'card', props: { title: 'Assistant', text: 'Pose tes questions à ton assistant personnel.', icon: 'chatbubbles' } },
          { type: 'button', props: { label: 'Parler à l’assistant', action: 'navigate', target: 'chat', variant: 'outline' } },
        ],
      },
      {
        id: 'images', title: 'Images IA', icon: 'color-palette', components: [
          { type: 'imagegen', props: { title: 'Crée une image avec l’IA', placeholder: 'Ex : un lion en armure dorée au coucher du soleil', style: 'auto' } },
        ],
      },
      {
        id: 'chat', title: 'Assistant', icon: 'chatbubbles', components: [
          { type: 'chatbot', props: {
            name: 'Nova', welcome: 'Salut ! Je suis Nova, ton assistant. Pose-moi une question 😊',
            instructions: 'Tu aides les utilisateurs de façon amicale et pédagogique.',
            faq: [
              { question: 'Qui es-tu ?', answer: 'Je suis Nova, l’assistant de cette application.' },
              { question: 'Comment créer une image ?', answer: 'Va dans l’onglet « Images IA », décris ton image puis appuie sur Générer.' },
            ],
          } },
        ],
      },
      {
        id: 'search', title: 'Recherche', icon: 'search', components: [
          { type: 'search', props: { title: 'Moteur de recherche', placeholder: 'Cherche sur Wikipédia…', source: 'wikipedia' } },
        ],
      },
      {
        id: 'more', title: 'Plus', icon: 'apps', components: [
          { type: 'video', props: { title: 'Découvrir l’IA', url: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ', caption: 'Remplace ce lien par ta propre vidéo.' } },
          { type: 'faq', props: { title: 'Questions fréquentes', items: [
            { question: 'Les images sont-elles gratuites ?', answer: 'Oui, la génération d’images est gratuite (une image toutes les 15 secondes environ).' },
            { question: 'Mes conversations sont-elles enregistrées ?', answer: 'Non, elles restent sur ton téléphone.' },
          ] } },
        ],
      },
    ],
  },
});

const TEMPLATES = RAW_TEMPLATES.map((t) => ({
  id: t.id,
  title: t.title,
  summary: t.summary,
  category: t.spec.category,
  spec: sanitizeSpec(t.spec),
}));

module.exports = { TEMPLATES };
