'use strict';
// Compilation cloud de l'APK via Expo EAS Build (nécessite EXPO_TOKEN et un compte Expo).
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const config = require('../config');

function run(cmd, args, cwd, timeoutMs = 15 * 60_000) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, {
      cwd,
      env: { ...process.env, EXPO_TOKEN: config.expoToken, CI: '1', EAS_NO_VCS: '1' },
      shell: false,
    });
    let out = '';
    let err = '';
    const timer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error(`Délai dépassé : ${cmd} ${args.join(' ')}`)); }, timeoutMs);
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { err += d; });
    child.on('error', (e) => { clearTimeout(timer); reject(e); });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code === 0) resolve(out);
      else reject(new Error(`${cmd} ${args[0] || ''} a échoué (code ${code}) : ${(err || out).slice(-800)}`));
    });
  });
}

function parseJsonOutput(text) {
  const start = text.search(/[[{]/);
  if (start === -1) throw new Error('Sortie EAS illisible');
  return JSON.parse(text.slice(start));
}

/**
 * Lance la compilation et met à jour la ligne `exports` au fil de l'eau.
 * @param {object} ctx { db, exportId, dir, files }
 */
async function startEasBuild({ db, exportId, dir, files }) {
  const update = async (fields) => {
    const keys = Object.keys(fields);
    await db.run(`UPDATE exports SET ${keys.map((k) => `${k} = ?`).join(', ')}, updated_at = ? WHERE id = ?`,
      ...keys.map((k) => fields[k]), Date.now(), exportId).catch((e) => console.error('[eas] mise à jour impossible', e.message));
  };
  const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx';
  const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  try {
    for (const [name, content] of Object.entries(files)) {
      const p = path.join(dir, name);
      fs.mkdirSync(path.dirname(p), { recursive: true });
      fs.writeFileSync(p, content);
    }
    await update({ status: 'installing', message: 'Installation des dépendances…' });
    await run(npm, ['install', '--no-audit', '--no-fund'], dir);

    await update({ status: 'configuring', message: 'Configuration du projet Expo…' });
    await run(npx, ['--yes', 'eas-cli@latest', 'init', '--non-interactive', '--force'], dir, 5 * 60_000);

    await update({ status: 'queued', message: 'Compilation envoyée aux serveurs Expo…' });
    const out = await run(npx, ['--yes', 'eas-cli@latest', 'build', '-p', 'android', '--profile', 'preview', '--non-interactive', '--no-wait', '--json'], dir, 10 * 60_000);
    const builds = parseJsonOutput(out);
    const build = Array.isArray(builds) ? builds[0] : builds;
    if (!build || !build.id) throw new Error('Identifiant de compilation absent');
    await update({ status: 'building', message: `Compilation en cours (id ${build.id})…` });

    // Suivi : vérifie l'état toutes les 60 s pendant 60 min maximum
    for (let i = 0; i < 60; i += 1) {
      await new Promise((r) => setTimeout(r, 60_000));
      const view = parseJsonOutput(await run(npx, ['--yes', 'eas-cli@latest', 'build:view', build.id, '--json'], dir, 2 * 60_000));
      const status = String(view.status || '').toUpperCase();
      if (status === 'FINISHED') {
        const url = view.artifacts && (view.artifacts.applicationArchiveUrl || view.artifacts.buildUrl);
        await update({ status: 'done', build_url: url || null, message: 'APK prêt au téléchargement 🎉' });
        return;
      }
      if (['ERRORED', 'CANCELED'].includes(status)) {
        await update({ status: 'failed', message: `La compilation Expo a échoué (${status.toLowerCase()}).` });
        return;
      }
    }
    await update({ status: 'failed', message: 'Délai de compilation dépassé.' });
  } catch (e) {
    console.error('[eas]', e.message);
    await update({ status: 'failed', message: `Échec de la compilation : ${e.message.slice(0, 300)}` });
  }
}

module.exports = { startEasBuild };
