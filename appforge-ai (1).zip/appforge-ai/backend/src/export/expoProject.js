'use strict';
// Transforme un AppSpec en projet Expo autonome, prêt à être compilé en APK Android.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const config = require('../config');

const RUNTIME_DIR = path.join(__dirname, '..', '..', 'runtime');

function slugify(name) {
  return String(name).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30) || 'mon-app';
}

function androidPackage(name, projectId) {
  const base = slugify(name).replace(/-/g, '').replace(/^[0-9]+/, '') || 'app';
  const suffix = crypto.createHash('sha1').update(projectId).digest('hex').slice(0, 6);
  return `com.appforge.${base.slice(0, 20)}${suffix}`;
}

function buildExpoProject(project) {
  const spec = project.spec;
  const slug = slugify(spec.name);
  const pkg = androidPackage(spec.name, project.id);

  const files = {
    'package.json': JSON.stringify({
      name: slug,
      version: '1.0.0',
      main: 'index.js',
      private: true,
      scripts: { start: 'expo start', android: 'expo run:android', 'build:apk': 'eas build -p android --profile preview' },
      dependencies: {
        expo: '~54.0.0',
        'expo-status-bar': '~3.0.0',
        '@expo/vector-icons': '^15.0.2',
        react: '19.1.0',
        'react-native': '0.81.4',
        'react-native-safe-area-context': '~5.6.0',
      },
    }, null, 2),
    'app.json': JSON.stringify({
      expo: {
        name: spec.name,
        slug,
        version: '1.0.0',
        orientation: 'portrait',
        userInterfaceStyle: 'dark',
        backgroundColor: spec.theme.background,
        android: {
          package: pkg,
          versionCode: 1,
          adaptiveIcon: { backgroundColor: spec.theme.primary },
        },
        extra: { generatedBy: 'Kubo', projectId: project.id },
      },
    }, null, 2),
    'eas.json': JSON.stringify({
      cli: { version: '>= 12.0.0', appVersionSource: 'local' },
      build: {
        preview: { distribution: 'internal', android: { buildType: 'apk' } },
        production: { android: { buildType: 'app-bundle' } },
      },
    }, null, 2),
    'index.js': "import { registerRootComponent } from 'expo';\nimport App from './App';\n\nregisterRootComponent(App);\n",
    'App.js': fs.readFileSync(path.join(RUNTIME_DIR, 'App.template.js'), 'utf8'),
    'src/AppRuntime.js': fs.readFileSync(path.join(RUNTIME_DIR, 'AppRuntime.js'), 'utf8'),
    // apiUrl + projectId : utilisés par le chatbot et le fil d'actualité partagé
    'src/spec.json': JSON.stringify({ ...spec, apiUrl: config.publicUrl, projectId: project.id }, null, 2),
    'README.md': `# ${spec.name}\n\nApplication générée avec **Kubo**.\n\n` +
      `## Lancer en local\n\n\`\`\`bash\nnpm install\nnpx expo install --fix\nnpx expo start\n\`\`\`\n\n` +
      `## Générer l'APK Android\n\n\`\`\`bash\nnpm install -g eas-cli\neas login\neas build -p android --profile preview\n\`\`\`\n\n` +
      `Le lien de téléchargement de l'APK s'affiche à la fin de la compilation.\n\n` +
      `Package Android : \`${pkg}\`\n`,
  };
  return { slug, pkg, files };
}

module.exports = { buildExpoProject, slugify };
