'use strict';
const fs = require('node:fs');
const path = require('node:path');
const config = require('../config');
const { HttpError } = require('../http');
const { newId, signToken, verifyToken } = require('../security');
const { requireAuth, isPremium } = require('./auth');
const { buildExpoProject, slugify } = require('../export/expoProject');
const { createZip } = require('../export/zip');
const { startEasBuild } = require('../export/eas');

const ACTIVE = ['installing', 'configuring', 'queued', 'building'];

function toExport(row) {
  return {
    id: row.id, projectId: row.project_id, mode: row.mode, status: row.status,
    message: row.message, buildUrl: row.build_url, hasFile: row.status === 'done',
    createdAt: row.created_at, updatedAt: row.updated_at,
  };
}

module.exports = function exportRoutes(router, { db }) {
  const auth = requireAuth(db);

  /**
   * mode = "source" : projet Expo complet (.zip) — disponible pour tous.
   * mode = "apk"    : compilation cloud EAS — réservée aux membres Premium.
   * Le .zip n'est pas stocké : il est fabriqué au moment du téléchargement
   * (compatible avec les hébergeurs gratuits dont le disque est effacé).
   */
  router.post('/api/projects/:id/export', auth, async (req, res) => {
    const row = await db.get('SELECT * FROM projects WHERE id = ? AND user_id = ?', req.params.id, req.user.id);
    if (!row) throw new HttpError(404, 'Projet introuvable.', 'not_found');
    const mode = req.body.mode === 'apk' ? 'apk' : 'source';
    if (mode === 'apk' && config.premiumEnabled && !isPremium(req.user)) {
      throw new HttpError(402, "L'export APK est réservé aux membres Premium.", 'premium_required');
    }
    const running = (await db.get(
      `SELECT COUNT(*) AS n FROM exports WHERE user_id = ? AND status IN (${ACTIVE.map(() => '?').join(',')})`,
      req.user.id, ...ACTIVE,
    )).n;
    if (mode === 'apk' && running >= 2) throw new HttpError(429, 'Deux compilations sont déjà en cours.', 'too_many_builds');

    const id = newId();
    const now = Date.now();
    if (mode === 'apk' && config.expoToken) {
      const { files } = buildExpoProject({ id: row.id, spec: JSON.parse(row.spec) });
      await db.run('INSERT INTO exports (id, project_id, user_id, mode, status, message, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        id, row.id, req.user.id, 'apk', 'installing', 'Préparation de la compilation…', now, now);
      fs.mkdirSync(config.exportDir, { recursive: true });
      startEasBuild({ db, exportId: id, dir: path.join(config.exportDir, id), files }); // tâche de fond
    } else {
      const message = mode === 'apk'
        ? "Compilation cloud non configurée sur ce serveur (EXPO_TOKEN manquant). Le projet Expo complet est prêt : lance « eas build -p android --profile preview » pour obtenir l'APK."
        : 'Projet Expo prêt au téléchargement.';
      await db.run('INSERT INTO exports (id, project_id, user_id, mode, status, message, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        id, row.id, req.user.id, mode, 'done', message, now, now);
    }
    res.statusCode = 201;
    return { export: toExport(await db.get('SELECT * FROM exports WHERE id = ?', id)) };
  });

  router.get('/api/projects/:id/exports', auth, async (req) => {
    const rows = await db.all('SELECT * FROM exports WHERE project_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT 20', req.params.id, req.user.id);
    return { exports: rows.map(toExport) };
  });

  router.get('/api/exports/:id', auth, async (req) => {
    const row = await db.get('SELECT * FROM exports WHERE id = ? AND user_id = ?', req.params.id, req.user.id);
    if (!row) throw new HttpError(404, 'Export introuvable.', 'not_found');
    return { export: toExport(row) };
  });

  // Lien de téléchargement signé, valable 10 minutes (ouvrable dans le navigateur du téléphone)
  router.post('/api/exports/:id/link', auth, async (req) => {
    const row = await db.get('SELECT * FROM exports WHERE id = ? AND user_id = ?', req.params.id, req.user.id);
    if (!row || row.status !== 'done') throw new HttpError(404, 'Fichier introuvable.', 'not_found');
    const t = signToken({ typ: 'download', exp_id: row.id, sub: req.user.id }, 600);
    return { url: `${config.publicUrl}/api/exports/${row.id}/download?t=${encodeURIComponent(t)}` };
  });

  router.get('/api/exports/:id/download', async (req, res) => {
    const payload = verifyToken(req.query.t);
    if (!payload || payload.typ !== 'download' || payload.exp_id !== req.params.id) {
      throw new HttpError(401, 'Lien expiré.', 'unauthorized');
    }
    const row = await db.get(
      'SELECT e.id, e.status, p.id AS project_id, p.spec FROM exports e JOIN projects p ON p.id = e.project_id WHERE e.id = ? AND e.user_id = ?',
      req.params.id, payload.sub,
    );
    if (!row || row.status !== 'done') throw new HttpError(404, 'Fichier introuvable.', 'not_found');
    const { slug, files } = buildExpoProject({ id: row.project_id, spec: JSON.parse(row.spec) });
    const zip = createZip(Object.entries(files).map(([name, data]) => ({ name: `${slug}/${name}`, data })));
    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${slugify(slug)}-expo.zip"`,
      'Content-Length': zip.length,
      'Cache-Control': 'no-store',
    });
    res.end(zip);
  });
};
