'use strict';
// Routes publiques utilisées par les applications générées (aucun compte requis).
const { HttpError } = require('../http');
const { rateLimiter } = require('../security');
const { chatbotReply, hasLLM } = require('../ai/generator');
const { newId } = require('../security');

// Limites strictes : ces routes sont ouvertes à toutes les apps exportées
const perMinute = rateLimiter({ windowMs: 60_000, max: 15 });
const perDay = rateLimiter({ windowMs: 24 * 3600_000, max: 300 });
const postPerMinute = rateLimiter({ windowMs: 60_000, max: 6 });
const postPerDay = rateLimiter({ windowMs: 24 * 3600_000, max: 100 });
const likePerMinute = rateLimiter({ windowMs: 60_000, max: 60 });
const ID_RE = /^[0-9a-f-]{36}$/i;

module.exports = function publicRoutes(router, { db }) {
  // ---- Fil d'actualité partagé : les publications sont visibles par tous les utilisateurs de l'app
  const appExists = async (req) => {
    if (!ID_RE.test(req.params.projectId) || !(await db.get('SELECT 1 AS x FROM projects WHERE id = ?', req.params.projectId))) {
      throw new HttpError(404, 'Application introuvable.', 'not_found');
    }
  };
  const toPost = (r) => ({ id: r.id, author: r.author, text: r.text, likes: r.likes, createdAt: r.created_at });

  router.get('/api/public/apps/:projectId/feed', async (req) => {
    await appExists(req);
    const rows = await db.all('SELECT * FROM posts WHERE project_id = ? ORDER BY created_at DESC LIMIT 50', req.params.projectId);
    return { posts: rows.map(toPost) };
  });

  router.post('/api/public/apps/:projectId/feed', async (req, res) => {
    if (!postPerMinute(req.ip) || !postPerDay(req.ip)) throw new HttpError(429, 'Tu publies trop vite, patiente un peu.', 'rate_limited');
    await appExists(req);
    const text = String((req.body && req.body.text) || '').trim().slice(0, 500);
    const author = String((req.body && req.body.author) || '').trim().slice(0, 40) || 'Anonyme';
    if (!text) throw new HttpError(400, 'Le message est vide.', 'invalid_post');
    const row = { id: newId(), project_id: req.params.projectId, author, text, likes: 0, created_at: Date.now() };
    await db.run('INSERT INTO posts (id, project_id, author, text, likes, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      row.id, row.project_id, row.author, row.text, row.likes, row.created_at);
    res.statusCode = 201;
    return { post: toPost(row) };
  });

  router.post('/api/public/apps/:projectId/feed/:postId/like', async (req) => {
    if (!likePerMinute(req.ip)) throw new HttpError(429, 'Doucement !', 'rate_limited');
    const delta = req.body && req.body.delta === -1 ? -1 : 1;
    await db.run('UPDATE posts SET likes = MAX(0, likes + ?) WHERE id = ? AND project_id = ?', delta, req.params.postId, req.params.projectId);
    const row = await db.get('SELECT * FROM posts WHERE id = ? AND project_id = ?', req.params.postId, req.params.projectId);
    if (!row) throw new HttpError(404, 'Publication introuvable.', 'not_found');
    return { post: toPost(row) };
  });

  router.post('/api/public/chat', async (req) => {
    if (!perMinute(req.ip) || !perDay(req.ip)) {
      throw new HttpError(429, 'Trop de messages, réessaie dans un instant.', 'rate_limited');
    }
    const b = req.body || {};
    const raw = Array.isArray(b.messages) ? b.messages.slice(-12) : [];
    const messages = raw
      .filter((m) => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string' && m.content.trim())
      .map((m) => ({ role: m.role, content: m.content.slice(0, 1000) }));
    if (!messages.length || messages[messages.length - 1].role !== 'user') {
      throw new HttpError(400, 'Message manquant.', 'invalid_message');
    }
    if (!hasLLM()) throw new HttpError(503, "L'IA n'est pas encore activée sur ce serveur.", 'ai_unavailable');
    const reply = await chatbotReply({
      botName: String(b.botName || 'Assistant').slice(0, 40),
      instructions: String(b.instructions || '').slice(0, 600),
      messages,
    }).catch(() => null);
    if (!reply) throw new HttpError(503, "L'assistant est momentanément indisponible.", 'ai_unavailable');
    return { reply };
  });
};
