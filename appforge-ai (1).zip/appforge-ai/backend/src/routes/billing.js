'use strict';
// Abonnements Premium via Stripe Checkout (API REST, sans SDK).
const crypto = require('node:crypto');
const config = require('../config');
const { HttpError } = require('../http');
const { requireAuth, isPremium, publicUser } = require('./auth');

const PLANS = [
  {
    id: 'free', name: 'Gratuit', price: 0, interval: null,
    features: ['3 projets', '10 générations IA par jour', 'Aperçu en direct', 'Export du projet Expo (.zip)'],
  },
  {
    id: 'monthly', name: 'Premium Mensuel', price: 9.99, currency: 'USD', interval: 'month',
    features: ['Projets illimités', 'Générations IA illimitées', 'Export APK Android en un clic', 'Modèles exclusifs', 'Support prioritaire'],
  },
  {
    id: 'yearly', name: 'Premium Annuel', price: 79.99, currency: 'USD', interval: 'year', badge: '-33 %',
    features: ['Tout le Premium Mensuel', '4 mois offerts', 'Accès anticipé aux nouveautés'],
  },
];

const stripeEnabled = () => Boolean(config.stripe.secretKey && config.stripe.priceMonthly && config.stripe.priceYearly);

async function stripe(pathname, params) {
  const r = await fetch(`https://api.stripe.com/v1/${pathname}`, {
    method: 'POST',
    headers: { authorization: `Bearer ${config.stripe.secretKey}`, 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params).toString(),
    signal: AbortSignal.timeout(20_000),
  });
  const data = await r.json();
  if (!r.ok) throw new HttpError(502, 'Le service de paiement est indisponible.', 'payment_error');
  return data;
}

function verifyStripeSignature(raw, header, secret) {
  if (!header || !secret) return false;
  const parts = Object.fromEntries(header.split(',').map((kv) => kv.split('=')));
  const t = Number(parts.t);
  if (!t || Math.abs(Date.now() / 1000 - t) > 300) return false;
  const expected = crypto.createHmac('sha256', secret).update(`${t}.${raw.toString('utf8')}`).digest('hex');
  const sigs = header.split(',').filter((kv) => kv.startsWith('v1=')).map((kv) => kv.slice(3));
  return sigs.some((sig) => sig.length === expected.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected)));
}

const page = (title, text) => `<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title><body style="background:#0B0B1A;color:#F5F5FF;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center"><div><h1 style="background:linear-gradient(90deg,#8B5CF6,#22D3EE);-webkit-background-clip:text;color:transparent">${title}</h1><p>${text}</p></div></body></html>`;

module.exports = function billingRoutes(router, { db }) {
  const auth = requireAuth(db);

  router.get('/api/billing/plans', () => ({
    plans: PLANS, premiumEnabled: config.premiumEnabled, paymentsEnabled: stripeEnabled(), devMode: config.premiumTestMode && !stripeEnabled(),
  }));

  router.post('/api/billing/checkout', auth, async (req) => {
    const plan = req.body.plan === 'yearly' ? 'yearly' : 'monthly';
    if (!stripeEnabled()) {
      if (!config.premiumTestMode) throw new HttpError(503, 'Les paiements ne sont pas encore configurés.', 'payments_disabled');
      return { devMode: true };
    }
    const session = await stripe('checkout/sessions', {
      mode: 'subscription',
      'line_items[0][price]': plan === 'yearly' ? config.stripe.priceYearly : config.stripe.priceMonthly,
      'line_items[0][quantity]': '1',
      client_reference_id: req.user.id,
      customer_email: req.user.email,
      'metadata[user_id]': req.user.id,
      'subscription_data[metadata][user_id]': req.user.id,
      success_url: `${config.publicUrl}/api/billing/success`,
      cancel_url: `${config.publicUrl}/api/billing/cancelled`,
      locale: 'fr',
    });
    return { url: session.url };
  });

  // Mode développement uniquement : active Premium sans paiement pour tester l'app
  router.post('/api/billing/dev-activate', auth, async (req) => {
    if (!config.premiumTestMode || stripeEnabled()) throw new HttpError(403, 'Indisponible.', 'forbidden');
    const plan = req.body.plan === 'yearly' ? 'yearly' : 'monthly';
    const until = Date.now() + (plan === 'yearly' ? 365 : 30) * 24 * 3600_000;
    await db.run("UPDATE users SET plan = 'premium', premium_until = ? WHERE id = ?", until, req.user.id);
    return { user: publicUser(await db.get('SELECT * FROM users WHERE id = ?', req.user.id)) };
  });

  router.post('/api/billing/dev-cancel', auth, async (req) => {
    if (!config.premiumTestMode || stripeEnabled()) throw new HttpError(403, 'Indisponible.', 'forbidden');
    await db.run("UPDATE users SET plan = 'free', premium_until = NULL WHERE id = ?", req.user.id);
    return { user: publicUser(await db.get('SELECT * FROM users WHERE id = ?', req.user.id)) };
  });

  // Portail client Stripe pour gérer / résilier l'abonnement
  router.post('/api/billing/portal', auth, async (req) => {
    if (!stripeEnabled() || !req.user.stripe_customer_id) throw new HttpError(400, 'Aucun abonnement actif à gérer.', 'no_subscription');
    const s = await stripe('billing_portal/sessions', { customer: req.user.stripe_customer_id, return_url: `${config.publicUrl}/api/billing/success` });
    return { url: s.url };
  });

  router.post('/api/billing/webhook', async (req) => {
    if (!verifyStripeSignature(req.rawBody, req.headers['stripe-signature'], config.stripe.webhookSecret)) {
      throw new HttpError(400, 'Signature invalide.', 'invalid_signature');
    }
    const event = JSON.parse(req.rawBody.toString('utf8'));
    const obj = event.data && event.data.object ? event.data.object : {};
    if (event.type === 'checkout.session.completed') {
      const userId = obj.client_reference_id || (obj.metadata && obj.metadata.user_id);
      if (userId) {
        await db.run("UPDATE users SET plan = 'premium', premium_until = NULL, stripe_customer_id = ? WHERE id = ?", obj.customer || null, userId);
      }
    } else if (event.type === 'customer.subscription.updated' || event.type === 'customer.subscription.deleted') {
      const active = event.type === 'customer.subscription.updated' && ['active', 'trialing', 'past_due'].includes(obj.status);
      const until = obj.current_period_end ? obj.current_period_end * 1000 : null;
      if (obj.customer) {
        if (active) await db.run("UPDATE users SET plan = 'premium', premium_until = ? WHERE stripe_customer_id = ?", until, obj.customer);
        else await db.run("UPDATE users SET plan = 'free', premium_until = NULL WHERE stripe_customer_id = ?", obj.customer);
      }
    }
    return { received: true };
  });

  const html = (res, body) => {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'" });
    res.end(body);
  };
  router.get('/api/billing/success', (req, res) => html(res, page('Merci ! 🎉', "Ton abonnement Premium est actif. Retourne dans l'application Kubo.")));
  router.get('/api/billing/cancelled', (req, res) => html(res, page('Paiement annulé', "Aucun montant n'a été débité. Tu peux revenir dans l'application.")));

  router.get('/api/billing/status', auth, (req) => ({ premium: isPremium(req.user), user: publicUser(req.user) }));
};

module.exports.verifyStripeSignature = verifyStripeSignature;
