'use strict';
const { HttpError } = require('../http');
const { newId, rateLimiter } = require('../security');
const { sanitizeSpec } = require('../spec');
const { TEMPLATES } = require('../templates');
const { generateApp } = require('../ai/generator');
const { requireAuth, usage } = require('./auth');

const aiBurstLimiter = rateLimiter({ windowMs: 60_000, max: 8 });

function toProject(row, withSpec = true) {
  const spec = JSON.parse(row.spec);
  const p = {
    id: row.id, name: row.name, description: row.description, category: row.category,
    icon: spec.icon, theme: spec.theme, screenCount: spec.screens.length,
    createdAt: row.created_at, updatedAt: row.updated_at,
  };
  if (withSpec) p.spec = spec;
  return p;
}

module.exports = function projectRoutes(router, { db }) {
  const auth = requireAuth(db);

  const getOwned = async (req) => {
    const row = await db.get('SELECT * FROM projects WHERE id = ? AND user_id = ?', req.params.id, req.user.id);
    if (!row) throw new HttpError(404, 'Projet introuvable.', 'not_found');
    return row;
  };

  const assertCanCreate = async (user) => {
    const u = await usage(db, user);
    if (u.projectLimit !== null && u.projects >= u.projectLimit) {
      throw new HttpError(402, `La formule gratuite est limitée à ${u.projectLimit} projets. Passe à Premium pour en créer davantage.`, 'project_limit');
    }
  };

  const insert = async (userId, spec) => {
    const now = Date.now();
    const id = newId();
    await db.run('INSERT INTO projects (id, user_id, name, description, category, spec, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      id, userId, spec.name, spec.description, spec.category, JSON.stringify(spec), now, now);
    return db.get('SELECT * FROM projects WHERE id = ?', id);
  };

  // ---- Modèles
  router.get('/api/templates', () => ({
    templates: TEMPLATES.map((t) => ({ ...t, screenCount: t.spec.screens.length })),
  }));

  // ---- Projets
  router.get('/api/projects', auth, async (req) => {
    const rows = await db.all('SELECT * FROM projects WHERE user_id = ? ORDER BY updated_at DESC LIMIT 200', req.user.id);
    return { projects: rows.map((r) => toProject(r, false)) };
  });

  router.post('/api/projects', auth, async (req, res) => {
    await assertCanCreate(req.user);
    let spec;
    if (req.body.templateId) {
      const tpl = TEMPLATES.find((t) => t.id === req.body.templateId);
      if (!tpl) throw new HttpError(404, 'Modèle introuvable.', 'not_found');
      spec = JSON.parse(JSON.stringify(tpl.spec));
    } else {
      spec = sanitizeSpec(req.body.spec || { name: req.body.name || 'Nouvelle application' });
    }
    if (typeof req.body.name === 'string' && req.body.name.trim()) spec = sanitizeSpec({ ...spec, name: req.body.name });
    res.statusCode = 201;
    return { project: toProject(await insert(req.user.id, spec)) };
  });

  router.get('/api/projects/:id', auth, async (req) => ({ project: toProject(await getOwned(req)) }));

  router.put('/api/projects/:id', auth, async (req) => {
    await getOwned(req);
    if (!req.body.spec || typeof req.body.spec !== 'object') throw new HttpError(400, 'Spécification manquante.', 'invalid_spec');
    const spec = sanitizeSpec(req.body.spec);
    await db.run('UPDATE projects SET name = ?, description = ?, category = ?, spec = ?, updated_at = ? WHERE id = ? AND user_id = ?',
      spec.name, spec.description, spec.category, JSON.stringify(spec), Date.now(), req.params.id, req.user.id);
    return { project: toProject(await getOwned(req)) };
  });

  router.post('/api/projects/:id/duplicate', auth, async (req, res) => {
    const row = await getOwned(req);
    await assertCanCreate(req.user);
    const spec = JSON.parse(row.spec);
    spec.name = `${spec.name} (copie)`.slice(0, 40);
    res.statusCode = 201;
    return { project: toProject(await insert(req.user.id, sanitizeSpec(spec))) };
  });

  router.delete('/api/projects/:id', auth, async (req) => {
    await getOwned(req);
    await db.run('DELETE FROM posts WHERE project_id = ?', req.params.id);
    await db.run('DELETE FROM exports WHERE project_id = ? AND user_id = ?', req.params.id, req.user.id);
    await db.run('DELETE FROM projects WHERE id = ? AND user_id = ?', req.params.id, req.user.id);
    return { ok: true };
  });

  // ---- Modération du fil d'actualité partagé de l'application
  router.get('/api/projects/:id/posts', auth, async (req) => {
    await getOwned(req);
    return { posts: await db.all('SELECT id, author, text, likes, created_at AS createdAt FROM posts WHERE project_id = ? ORDER BY created_at DESC LIMIT 200', req.params.id) };
  });
  router.delete('/api/projects/:id/posts/:postId', auth, async (req) => {
    await getOwned(req);
    await db.run('DELETE FROM posts WHERE id = ? AND project_id = ?', req.params.postId, req.params.id);
    return { ok: true };
  });

  // ---- Assistant IA
  router.post('/api/ai/generate', auth, async (req, res) => {
    const prompt = String(req.body.prompt || '').trim();
    if (prompt.length < 3) throw new HttpError(400, 'Décris ton application en quelques mots.', 'invalid_prompt');
    if (prompt.length > 2000) throw new HttpError(400, 'Description trop longue (2000 caractères max).', 'invalid_prompt');
    if (!aiBurstLimiter(req.user.id)) throw new HttpError(429, 'Doucement ! Attends quelques secondes avant une nouvelle demande.', 'rate_limited');

    const u = await usage(db, req.user);
    if (u.generationLimit !== null && u.generationsToday >= u.generationLimit) {
      if (!u.premiumEnabled) {
        throw new HttpError(429, `Tu as utilisé tes ${u.generationLimit} générations IA du jour. Reviens demain pour continuer !`, 'daily_limit');
      }
      throw new HttpError(402, `Tu as atteint la limite de ${u.generationLimit} générations IA par jour. Passe à Premium pour un accès illimité.`, 'generation_limit');
    }

    let existing = null;
    if (req.body.projectId) {
      existing = await db.get('SELECT * FROM projects WHERE id = ? AND user_id = ?', String(req.body.projectId), req.user.id);
      if (!existing) throw new HttpError(404, 'Projet introuvable.', 'not_found');
    } else {
      await assertCanCreate(req.user);
    }

    const result = await generateApp({ prompt, currentSpec: existing ? JSON.parse(existing.spec) : null });
    await db.run('INSERT INTO generations (id, user_id, prompt, engine, created_at) VALUES (?, ?, ?, ?, ?)',
      newId(), req.user.id, prompt.slice(0, 2000), result.engine, Date.now());

    let row;
    if (existing) {
      await db.run('UPDATE projects SET name = ?, description = ?, category = ?, spec = ?, updated_at = ? WHERE id = ?',
        result.spec.name, result.spec.description, result.spec.category, JSON.stringify(result.spec), Date.now(), existing.id);
      row = await db.get('SELECT * FROM projects WHERE id = ?', existing.id);
    } else {
      row = await insert(req.user.id, result.spec);
      res.statusCode = 201;
    }
    return { project: toProject(row), reply: result.reply, engine: result.engine, created: !existing };
  });
};
