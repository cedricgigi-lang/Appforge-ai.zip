'use strict';
const { HttpError } = require('../http');
const { hashPassword, verifyPassword, DUMMY_HASH, signToken, verifyToken, rateLimiter, newId } = require('../security');
const config = require('../config');

const authLimiter = rateLimiter({ windowMs: 15 * 60_000, max: 20 });
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;

function isPremium(u) {
  return u.plan === 'premium' && (!u.premium_until || u.premium_until > Date.now());
}

function publicUser(u) {
  return {
    id: u.id, email: u.email, name: u.name, language: u.language,
    plan: isPremium(u) ? 'premium' : 'free', premiumUntil: u.premium_until || null, createdAt: u.created_at,
  };
}

async function usage(db, u) {
  const since = Date.now() - 24 * 3600_000;
  const generationsToday = (await db.get('SELECT COUNT(*) AS n FROM generations WHERE user_id = ? AND created_at > ?', u.id, since)).n;
  const projects = (await db.get('SELECT COUNT(*) AS n FROM projects WHERE user_id = ?', u.id)).n;
  // Premium désactivé : tout le monde a accès à tout, avec une limite anti-abus sur l'IA
  if (!config.premiumEnabled) {
    return { premiumEnabled: false, projects, projectLimit: null, generationsToday, generationLimit: config.limits.fairUseGenerationsPerDay };
  }
  const premium = isPremium(u);
  return {
    premiumEnabled: true,
    projects,
    projectLimit: premium ? null : config.limits.freeProjects,
    generationsToday,
    generationLimit: premium ? null : config.limits.freeGenerationsPerDay,
  };
}

/** Middleware : exige un jeton valide et charge l'utilisateur dans req.user */
function requireAuth(db) {
  return async (req) => {
    const h = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : null;
    const payload = verifyToken(token);
    if (!payload || payload.typ !== 'access') throw new HttpError(401, 'Session expirée, reconnecte-toi.', 'unauthorized');
    const user = await db.get('SELECT * FROM users WHERE id = ?', payload.sub);
    if (!user || user.token_version !== payload.tv) throw new HttpError(401, 'Session expirée, reconnecte-toi.', 'unauthorized');
    req.user = user;
  };
}

function validateCredentials(body, withName) {
  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '');
  if (!EMAIL_RE.test(email) || email.length > 254) throw new HttpError(400, 'Adresse email invalide.', 'invalid_email');
  if (withName) {
    const name = String(body.name || '').trim();
    if (name.length < 2 || name.length > 60) throw new HttpError(400, 'Le nom doit contenir entre 2 et 60 caractères.', 'invalid_name');
    if (password.length < 8 || password.length > 128 || !/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
      throw new HttpError(400, 'Le mot de passe doit contenir au moins 8 caractères, dont une lettre et un chiffre.', 'weak_password');
    }
    return { email, password, name };
  }
  if (!password || password.length > 128) throw new HttpError(400, 'Mot de passe requis.', 'invalid_password');
  return { email, password };
}

const issue = (u) => signToken({ sub: u.id, tv: u.token_version, typ: 'access' });

/** Supprime un utilisateur et toutes ses données (sans dépendre des clés étrangères). */
async function deleteUserData(db, userId) {
  await db.run('DELETE FROM posts WHERE project_id IN (SELECT id FROM projects WHERE user_id = ?)', userId);
  await db.run('DELETE FROM exports WHERE user_id = ?', userId);
  await db.run('DELETE FROM generations WHERE user_id = ?', userId);
  await db.run('DELETE FROM projects WHERE user_id = ?', userId);
  await db.run('DELETE FROM users WHERE id = ?', userId);
}

module.exports = function authRoutes(router, { db }) {
  const auth = requireAuth(db);
  const limit = (req) => {
    if (!authLimiter(req.ip)) throw new HttpError(429, 'Trop de tentatives. Réessaie dans quelques minutes.', 'rate_limited');
  };

  router.post('/api/auth/register', limit, async (req, res) => {
    const { email, password, name } = validateCredentials(req.body, true);
    if (await db.get('SELECT 1 AS x FROM users WHERE email = ?', email)) {
      throw new HttpError(409, 'Un compte existe déjà avec cet email.', 'email_taken');
    }
    const lang = req.body.language === 'en' ? 'en' : 'fr';
    const user = {
      id: newId(), email, name, password_hash: hashPassword(password), plan: 'free',
      language: lang, token_version: 0, created_at: Date.now(),
    };
    await db.run('INSERT INTO users (id, email, name, password_hash, plan, language, token_version, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      user.id, user.email, user.name, user.password_hash, user.plan, user.language, user.token_version, user.created_at);
    res.statusCode = 201;
    return { token: issue(user), user: publicUser(user) };
  });

  router.post('/api/auth/login', limit, async (req) => {
    const { email, password } = validateCredentials(req.body, false);
    const user = await db.get('SELECT * FROM users WHERE email = ?', email);
    const ok = verifyPassword(password, user ? user.password_hash : DUMMY_HASH);
    if (!user || !ok) throw new HttpError(401, 'Email ou mot de passe incorrect.', 'invalid_credentials');
    return { token: issue(user), user: publicUser(user) };
  });

  router.get('/api/auth/me', auth, async (req) => ({ user: publicUser(req.user), usage: await usage(db, req.user) }));

  router.patch('/api/auth/me', auth, async (req) => {
    const u = req.user;
    const name = req.body.name !== undefined ? String(req.body.name).trim() : u.name;
    if (name.length < 2 || name.length > 60) throw new HttpError(400, 'Nom invalide.', 'invalid_name');
    const language = ['fr', 'en'].includes(req.body.language) ? req.body.language : u.language;
    await db.run('UPDATE users SET name = ?, language = ? WHERE id = ?', name, language, u.id);
    return { user: publicUser({ ...u, name, language }) };
  });

  router.post('/api/auth/change-password', auth, limit, async (req) => {
    const u = req.user;
    if (!verifyPassword(String(req.body.currentPassword || ''), u.password_hash)) {
      throw new HttpError(401, 'Mot de passe actuel incorrect.', 'invalid_credentials');
    }
    const { password } = validateCredentials({ email: u.email, name: u.name, password: req.body.newPassword }, true);
    // Incrémente token_version : toutes les autres sessions sont révoquées
    await db.run('UPDATE users SET password_hash = ?, token_version = token_version + 1 WHERE id = ?', hashPassword(password), u.id);
    const fresh = await db.get('SELECT * FROM users WHERE id = ?', u.id);
    return { token: issue(fresh) };
  });

  router.post('/api/auth/logout-all', auth, async (req) => {
    await db.run('UPDATE users SET token_version = token_version + 1 WHERE id = ?', req.user.id);
    return { ok: true };
  });

  router.delete('/api/auth/me', auth, limit, async (req) => {
    // Le mot de passe passe par un en-tête (jamais dans l'URL, qui finit dans les journaux)
    if (!verifyPassword(String(req.headers['x-confirm-password'] || ''), req.user.password_hash)) {
      throw new HttpError(401, 'Mot de passe incorrect.', 'invalid_credentials');
    }
    await deleteUserData(db, req.user.id);
    return { ok: true };
  });
};

module.exports.requireAuth = requireAuth;
module.exports.isPremium = isPremium;
module.exports.publicUser = publicUser;
module.exports.usage = usage;
