'use strict';
// Mode par défaut : Premium désactivé, tout est gratuit. Nouveaux composants IA & médias.
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'secret-de-test-'.repeat(4);
process.env.PREMIUM_ENABLED = '';
process.env.ANTHROPIC_API_KEY = '';
process.env.OPENAI_API_KEY = '';
process.env.POLLINATIONS_API_KEY = '';
process.env.EXPO_TOKEN = '';

const test = require('node:test');
const assert = require('node:assert/strict');
const zlib = require('node:zlib');
const { createApp } = require('../src/server');
const { openDb } = require('../src/db');
const { sanitizeSpec } = require('../src/spec');
const { TEMPLATES } = require('../src/templates');

let base;
let server;
test.before(async () => {
  ({ server } = await createApp({ db: await openDb(':memory:') }));
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

async function api(method, path, { token, body } = {}) {
  const r = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const ct = r.headers.get('content-type') || '';
  return { status: r.status, data: ct.includes('json') ? await r.json() : Buffer.from(await r.arrayBuffer()) };
}

// Lit un fichier dans un zip (méthode deflate) — suffisant pour nos archives
function readZipEntry(buf, wanted) {
  let off = 0;
  while (buf.readUInt32LE(off) === 0x04034b50) {
    const compSize = buf.readUInt32LE(off + 18);
    const nameLen = buf.readUInt16LE(off + 26);
    const extra = buf.readUInt16LE(off + 28);
    const name = buf.slice(off + 30, off + 30 + nameLen).toString();
    const dataStart = off + 30 + nameLen + extra;
    if (name.endsWith(wanted)) return zlib.inflateRawSync(buf.slice(dataStart, dataStart + compSize)).toString();
    off = dataStart + compSize;
  }
  return null;
}

test('sans Premium : projets illimités, export APK ouvert, limite anti-abus sur l’IA', async () => {
  let r = await api('GET', '/api/health');
  assert.equal(r.data.premiumEnabled, false);
  r = await api('POST', '/api/auth/register', { body: { name: 'Cédric', email: 'c@test.cd', password: 'MotDePasse123' } });
  const token = r.data.token;
  r = await api('GET', '/api/auth/me', { token });
  assert.equal(r.data.usage.premiumEnabled, false);
  assert.equal(r.data.usage.projectLimit, null);
  assert.equal(r.data.usage.generationLimit, 50);

  let last;
  for (const id of ['edu-quiz', 'game-tap', 'prod-focus', 'biz-shop', 'ai-studio']) {
    last = await api('POST', '/api/projects', { token, body: { templateId: id } });
    assert.equal(last.status, 201, `modèle ${id}`);
  }
  r = await api('POST', `/api/projects/${last.data.project.id}/export`, { token, body: { mode: 'apk' } });
  assert.equal(r.status, 201, 'export APK sans Premium');

  // Le projet exporté contient l'adresse du serveur pour le chatbot
  r = await api('POST', `/api/exports/${r.data.export.id}/link`, { token });
  const u = new URL(r.data.url);
  const zip = (await api('GET', u.pathname + u.search)).data;
  const spec = JSON.parse(readZipEntry(zip, 'src/spec.json'));
  assert.ok(spec.apiUrl.startsWith('http'));
  assert.ok(spec.screens.some((s) => s.components.some((c) => c.type === 'chatbot')));
});

test('chatbot public : validé, limité, et 503 propre sans IA configurée', async () => {
  let r = await api('POST', '/api/public/chat', { body: { messages: [] } });
  assert.equal(r.status, 400);
  r = await api('POST', '/api/public/chat', { body: { botName: 'Nova', messages: [{ role: 'user', content: 'Bonjour' }] } });
  assert.equal(r.status, 503);
  assert.equal(r.data.error, 'ai_unavailable');
});

test('nouveaux composants nettoyés', () => {
  const s = sanitizeSpec({ screens: [{ id: 'a', components: [
    { type: 'hero', props: { title: 'X', target: 'inconnu', image: 'http://non-securise.com/a.jpg' } },
    { type: 'gallery', props: { images: ['https://ok.com/1.jpg', 'javascript:alert(1)', 42] } },
    { type: 'imagegen', props: { style: 'pirate' } },
    { type: 'chatbot', props: { faq: [{ question: 'Q', answer: '' }, { question: 'Q2', answer: 'R2' }] } },
    { type: 'search', props: { source: 'google' } },
    { type: 'faq', props: { items: [{ question: '', answer: 'x' }, { question: 'Q', answer: 'R' }] } },
    { type: 'video', props: { url: 'ftp://x' } },
  ] }] });
  const [hero, gallery, img, bot, search, faq, video] = s.screens[0].components.map((c) => c.props);
  assert.equal(hero.target, '');
  assert.equal(hero.image, '');
  assert.deepEqual(gallery.images, ['https://ok.com/1.jpg']);
  assert.equal(img.style, 'auto');
  assert.equal(bot.faq.length, 1);
  assert.equal(search.source, 'app');
  assert.equal(faq.items.length, 1);
  assert.equal(video.url, '');
  assert.ok(TEMPLATES.some((t) => t.id === 'ai-studio'));
});

test('fil d’actualité partagé entre utilisateurs, modération par le créateur', async () => {
  let r = await api('POST', '/api/auth/register', { body: { name: 'Admin', email: 'admin@test.cd', password: 'MotDePasse123' } });
  const token = r.data.token;
  r = await api('POST', '/api/projects', { token, body: { templateId: 'social-community' } });
  const pid = r.data.project.id;

  assert.equal((await api('GET', '/api/public/apps/inconnu/feed')).status, 404);
  r = await api('POST', `/api/public/apps/${pid}/feed`, { body: { author: 'Amina', text: 'Bonjour tout le monde !' } });
  assert.equal(r.status, 201);
  const postId = r.data.post.id;
  await api('POST', `/api/public/apps/${pid}/feed`, { body: { text: 'Message anonyme' } });
  r = await api('POST', `/api/public/apps/${pid}/feed`, { body: { text: '   ' } });
  assert.equal(r.status, 400);

  // Un autre utilisateur (autre téléphone) voit les publications
  r = await api('GET', `/api/public/apps/${pid}/feed`);
  assert.equal(r.data.posts.length, 2);
  assert.equal(r.data.posts[1].author, 'Amina');
  assert.equal(r.data.posts[0].author, 'Anonyme');

  r = await api('POST', `/api/public/apps/${pid}/feed/${postId}/like`, { body: { delta: 1 } });
  assert.equal(r.data.post.likes, 1);
  r = await api('POST', `/api/public/apps/${pid}/feed/${postId}/like`, { body: { delta: -1 } });
  r = await api('POST', `/api/public/apps/${pid}/feed/${postId}/like`, { body: { delta: -1 } });
  assert.equal(r.data.post.likes, 0, 'jamais négatif');

  // Modération : le créateur supprime une publication
  r = await api('GET', `/api/projects/${pid}/posts`, { token });
  assert.equal(r.data.posts.length, 2);
  await api('DELETE', `/api/projects/${pid}/posts/${postId}`, { token });
  r = await api('GET', `/api/public/apps/${pid}/feed`);
  assert.equal(r.data.posts.length, 1);

  // Supprimer le projet supprime ses publications
  await api('DELETE', `/api/projects/${pid}`, { token });
  assert.equal((await api('GET', `/api/public/apps/${pid}/feed`)).status, 404);
});
