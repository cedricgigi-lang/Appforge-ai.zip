'use strict';
// Tests de bout en bout de l'API (node --test). Base SQLite en mémoire, IA intégrée.
process.env.NODE_ENV = 'test';
process.env.PREMIUM_ENABLED = '1';
process.env.JWT_SECRET = 'secret-de-test-'.repeat(4);
process.env.ANTHROPIC_API_KEY = '';
process.env.OPENAI_API_KEY = '';
process.env.EXPO_TOKEN = '';
process.env.STRIPE_SECRET_KEY = '';
process.env.EXPORT_DIR = require('node:path').join(require('node:os').tmpdir(), 'appforge-test-exports');

const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { createApp } = require('../src/server');
const { openDb } = require('../src/db');
const { sanitizeSpec } = require('../src/spec');
const { ruleBasedGenerate, ruleBasedRefine } = require('../src/ai/generator');
const { verifyStripeSignature } = require('../src/routes/billing');

let base;
let server;

test.before(async () => {
  ({ server } = await createApp({ db: await openDb(':memory:') }));
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

async function api(method, path, { token, body, headers = {} } = {}) {
  const r = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const ct = r.headers.get('content-type') || '';
  return { status: r.status, data: ct.includes('json') ? await r.json() : await r.arrayBuffer(), headers: r.headers };
}

test('santé', async () => {
  const r = await api('GET', '/api/health');
  assert.equal(r.status, 200);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
});

test('parcours complet : inscription → IA → éditeur → export → premium', async () => {
  // Inscription : mot de passe faible refusé
  let r = await api('POST', '/api/auth/register', { body: { name: 'Awa', email: 'awa@test.cd', password: 'court' } });
  assert.equal(r.status, 400);
  r = await api('POST', '/api/auth/register', { body: { name: 'Awa', email: 'awa@test.cd', password: 'MotDePasse123' } });
  assert.equal(r.status, 201);
  assert.equal(r.data.user.plan, 'free');
  r = await api('POST', '/api/auth/register', { body: { name: 'Awa', email: 'AWA@test.cd', password: 'MotDePasse123' } });
  assert.equal(r.status, 409, 'email unique, insensible à la casse');

  // Connexion
  r = await api('POST', '/api/auth/login', { body: { email: 'awa@test.cd', password: 'mauvais1' } });
  assert.equal(r.status, 401);
  r = await api('POST', '/api/auth/login', { body: { email: 'awa@test.cd', password: 'MotDePasse123' } });
  assert.equal(r.status, 200);
  const token = r.data.token;

  // Accès protégé
  assert.equal((await api('GET', '/api/projects')).status, 401);
  assert.equal((await api('GET', '/api/projects', { token: token + 'x' })).status, 401);

  // Génération IA
  r = await api('POST', '/api/ai/generate', { token, body: { prompt: 'Une application de quiz pour mon école appelée "Génie Kids" en vert' } });
  assert.equal(r.status, 201);
  const project = r.data.project;
  assert.equal(project.spec.name, 'Génie Kids');
  assert.equal(project.category, 'education');
  assert.equal(project.spec.theme.primary, '#10B981');

  // Raffinement
  r = await api('POST', '/api/ai/generate', { token, body: { prompt: 'ajoute un écran Contact', projectId: project.id } });
  assert.equal(r.status, 200);
  assert.ok(r.data.project.spec.screens.some((s) => s.title === 'Contact'));

  // Éditeur : sauvegarde avec contenu malveillant → nettoyé
  const spec = r.data.project.spec;
  spec.screens[0].components.push({ type: 'script', props: { code: 'alert(1)' } });
  spec.screens[0].components.push({ type: 'image', props: { uri: 'javascript:alert(1)' } });
  spec.theme.primary = 'red; drop';
  r = await api('PUT', `/api/projects/${project.id}`, { token, body: { spec } });
  assert.equal(r.status, 200);
  const saved = r.data.project.spec;
  assert.ok(!saved.screens[0].components.some((c) => c.type === 'script'));
  assert.equal(saved.screens[0].components.at(-1).props.uri, '');
  assert.equal(saved.theme.primary, '#8B5CF6');

  // Isolation entre utilisateurs
  const other = await api('POST', '/api/auth/register', { body: { name: 'Bob', email: 'bob@test.cd', password: 'MotDePasse123' } });
  assert.equal((await api('GET', `/api/projects/${project.id}`, { token: other.data.token })).status, 404);

  // Limite de projets (formule gratuite : 3)
  await api('POST', '/api/projects', { token, body: { templateId: 'game-tap' } });
  await api('POST', '/api/projects', { token, body: { templateId: 'prod-focus' } });
  r = await api('POST', '/api/projects', { token, body: { templateId: 'biz-shop' } });
  assert.equal(r.status, 402);

  // Export source (zip)
  r = await api('POST', `/api/projects/${project.id}/export`, { token, body: { mode: 'source' } });
  assert.equal(r.status, 201);
  const exp = r.data.export;
  r = await api('POST', `/api/exports/${exp.id}/link`, { token });
  const url = new URL(r.data.url);
  const dl = await api('GET', url.pathname + url.search);
  assert.equal(dl.status, 200);
  const buf = Buffer.from(dl.data);
  assert.equal(buf.readUInt32LE(0), 0x04034b50, 'signature ZIP');
  assert.equal((await api('GET', `${url.pathname}?t=faux`)).status, 401);

  // Export APK : Premium requis
  assert.equal((await api('POST', `/api/projects/${project.id}/export`, { token, body: { mode: 'apk' } })).status, 402);

  // Premium (mode développement)
  r = await api('POST', '/api/billing/checkout', { token, body: { plan: 'monthly' } });
  assert.equal(r.data.devMode, true);
  r = await api('POST', '/api/billing/dev-activate', { token, body: { plan: 'monthly' } });
  assert.equal(r.data.user.plan, 'premium');
  r = await api('POST', '/api/projects', { token, body: { templateId: 'biz-shop' } });
  assert.equal(r.status, 201, 'plus de limite en Premium');
  r = await api('POST', `/api/projects/${project.id}/export`, { token, body: { mode: 'apk' } });
  assert.equal(r.status, 201);
  assert.equal(r.data.export.status, 'done');

  // Révocation des sessions
  await api('POST', '/api/auth/logout-all', { token });
  assert.equal((await api('GET', '/api/auth/me', { token })).status, 401);
});

test('le format AppSpec est toujours valide', () => {
  const s = sanitizeSpec({ screens: [{ components: [{ type: 'button', props: { action: 'navigate', target: 'inconnu' } }] }] });
  assert.equal(s.screens.length, 1);
  assert.equal(s.screens[0].components[0].props.target, s.screens[0].id);
  const empty = sanitizeSpec(null);
  assert.equal(empty.screens.length, 1);
});

test('générateur intégré : catégories et modifications', () => {
  assert.equal(ruleBasedGenerate('un jeu de réflexes').spec.category, 'games');
  assert.equal(ruleBasedGenerate('une app pour mon restaurant').spec.category, 'business');
  assert.equal(ruleBasedGenerate('réseau social pour mon club').spec.category, 'social');
  const base = ruleBasedGenerate('liste de tâches').spec;
  const r = ruleBasedRefine(base, 'mets la couleur en rose');
  assert.equal(r.spec.theme.primary, '#EC4899');
  assert.equal(ruleBasedRefine(base, 'blabla').changed, false);
});

test('signature des webhooks Stripe', () => {
  const secret = 'whsec_test';
  const raw = Buffer.from('{"type":"x"}');
  const t = Math.floor(Date.now() / 1000);
  const sig = crypto.createHmac('sha256', secret).update(`${t}.${raw}`).digest('hex');
  assert.ok(verifyStripeSignature(raw, `t=${t},v1=${sig}`, secret));
  assert.ok(!verifyStripeSignature(raw, `t=${t},v1=${'0'.repeat(64)}`, secret));
});
