'use strict';
// Vérifie le mode « Turso » : un faux serveur Turso (protocole HTTP /v2/pipeline)
// s'appuie sur SQLite en mémoire, et l'API complète fonctionne par-dessus.
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'secret-de-test-'.repeat(4);
process.env.ANTHROPIC_API_KEY = '';
process.env.OPENAI_API_KEY = '';

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { DatabaseSync } = require('node:sqlite');
const { TursoDb, SCHEMA } = require('../src/db');
const { createApp } = require('../src/server');

const TOKEN = 'jeton-turso-test';
let fake;
let fakeUrl;
let api;
let apiUrl;
const seen = { requests: 0, argTypes: new Set() };

function startFakeTurso() {
  const sqlite = new DatabaseSync(':memory:');
  const decode = (a) => {
    seen.argTypes.add(a.type);
    if (a.type === 'null') return null;
    if (a.type === 'integer') { assert.equal(typeof a.value, 'string', 'les entiers sont envoyés en texte'); return Number(a.value); }
    if (a.type === 'float') return a.value;
    if (a.type === 'blob') return Buffer.from(a.base64, 'base64');
    return a.value;
  };
  const encode = (v) => {
    if (v === null || v === undefined) return { type: 'null' };
    if (typeof v === 'number') return Number.isInteger(v) ? { type: 'integer', value: String(v) } : { type: 'float', value: v };
    if (typeof v === 'bigint') return { type: 'integer', value: v.toString() };
    return { type: 'text', value: String(v) };
  };
  return http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      if (req.url !== '/v2/pipeline' || req.headers.authorization !== `Bearer ${TOKEN}`) {
        res.writeHead(401); res.end('unauthorized'); return;
      }
      seen.requests += 1;
      const { requests } = JSON.parse(body);
      const results = requests.map((r) => {
        if (r.type === 'close') return { type: 'ok', response: { type: 'close' } };
        try {
          const stmt = sqlite.prepare(r.stmt.sql);
          const args = (r.stmt.args || []).map(decode);
          const cols = stmt.columns().map((c) => ({ name: c.name, decltype: null }));
          let rows = [];
          let changes = 0;
          if (cols.length) rows = stmt.all(...args).map((o) => cols.map((c) => encode(o[c.name])));
          else changes = Number(stmt.run(...args).changes);
          return { type: 'ok', response: { type: 'execute', result: { cols, rows, affected_row_count: changes, last_insert_rowid: null } } };
        } catch (e) {
          return { type: 'error', error: { message: e.message, code: 'SQLITE_ERROR' } };
        }
      });
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ baton: null, base_url: null, results }));
    });
  });
}

test.before(async () => {
  fake = startFakeTurso();
  await new Promise((r) => fake.listen(0, r));
  fakeUrl = `http://127.0.0.1:${fake.address().port}`;
  const db = new TursoDb(fakeUrl, TOKEN);
  await db.exec(SCHEMA);
  ({ server: api } = await createApp({ db }));
  await new Promise((r) => api.listen(0, r));
  apiUrl = `http://127.0.0.1:${api.address().port}`;
});
test.after(() => { api.close(); fake.close(); });

async function call(method, path, { token, body, headers = {} } = {}) {
  const r = await fetch(apiUrl + path, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const ct = r.headers.get('content-type') || '';
  return { status: r.status, data: ct.includes('json') ? await r.json() : Buffer.from(await r.arrayBuffer()) };
}

test('conversion de l’URL libsql:// en https://', () => {
  assert.equal(new TursoDb('libsql://ma-base-moi.turso.io', 'x').baseUrl, 'https://ma-base-moi.turso.io');
});

test('les erreurs SQL de Turso sont remontées', async () => {
  const db = new TursoDb(fakeUrl, TOKEN);
  await assert.rejects(db.get('SELECT * FROM table_inexistante'), /Erreur SQL Turso/);
  await assert.rejects(new TursoDb(fakeUrl, 'mauvais').get('SELECT 1'), /HTTP 401/);
});

test('parcours complet de l’API avec la base Turso', async () => {
  let r = await call('GET', '/api/health');
  assert.equal(r.data.database, 'turso');

  r = await call('POST', '/api/auth/register', { body: { name: 'Cédric', email: 'cedric@test.cd', password: 'MotDePasse123' } });
  assert.equal(r.status, 201);
  r = await call('POST', '/api/auth/login', { body: { email: 'cedric@test.cd', password: 'MotDePasse123' } });
  assert.equal(r.status, 200);
  const token = r.data.token;

  r = await call('GET', '/api/auth/me', { token });
  assert.equal(r.data.usage.projects, 0);
  assert.equal(r.data.user.premiumUntil, null, 'NULL relu correctement');

  r = await call('POST', '/api/ai/generate', { token, body: { prompt: 'un jeu de réflexes rose' } });
  assert.equal(r.status, 201);
  const id = r.data.project.id;
  assert.equal(r.data.project.category, 'games');

  const spec = r.data.project.spec;
  spec.name = 'Mon Super Jeu';
  r = await call('PUT', `/api/projects/${id}`, { token, body: { spec } });
  assert.equal(r.data.project.name, 'Mon Super Jeu');
  assert.equal(typeof r.data.project.updatedAt, 'number');

  r = await call('GET', '/api/auth/me', { token });
  assert.equal(r.data.usage.projects, 1);
  assert.equal(r.data.usage.generationsToday, 1);

  // Export : le zip est fabriqué à la volée au téléchargement
  r = await call('POST', `/api/projects/${id}/export`, { token, body: { mode: 'source' } });
  assert.equal(r.status, 201);
  r = await call('POST', `/api/exports/${r.data.export.id}/link`, { token });
  const u = new URL(r.data.url);
  r = await call('GET', u.pathname + u.search);
  assert.equal(r.status, 200);
  assert.equal(r.data.readUInt32LE(0), 0x04034b50);

  // Premium (mode test) : entier sur 13 chiffres (horodatage) conservé
  r = await call('POST', '/api/billing/dev-activate', { token, body: { plan: 'yearly' } });
  assert.ok(r.data.user.premiumUntil > Date.now());

  // Suppression du compte : toutes les données partent, sans clés étrangères
  r = await call('DELETE', '/api/auth/me', { token, headers: { 'x-confirm-password': 'MotDePasse123' } });
  assert.equal(r.status, 200);
  const db = new TursoDb(fakeUrl, TOKEN);
  for (const t of ['users', 'projects', 'generations', 'exports']) {
    assert.equal((await db.get(`SELECT COUNT(*) AS n FROM ${t}`)).n, 0, `table ${t} vidée`);
  }
  // Aller-retour de chaque type de valeur
  await db.exec('CREATE TABLE t (a, b, c, d)');
  await db.run('INSERT INTO t VALUES (?, ?, ?, ?)', null, 1763400000123, 1.5, 'é');
  assert.deepEqual({ ...(await db.get('SELECT * FROM t')) }, { a: null, b: 1763400000123, c: 1.5, d: 'é' });
  assert.ok(['integer', 'text', 'null', 'float'].every((x) => seen.argTypes.has(x)));
});
