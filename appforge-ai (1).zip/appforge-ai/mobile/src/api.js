import Constants from 'expo-constants';

// Adresse de l'API : EXPO_PUBLIC_API_URL (fichier .env ou eas.json) puis app.json > extra.apiUrl
export const API_URL = (
  process.env.EXPO_PUBLIC_API_URL
  || (Constants.expoConfig && Constants.expoConfig.extra && Constants.expoConfig.extra.apiUrl)
  || 'http://10.0.2.2:4000'
).replace(/\/$/, '');

let token = null;
let onUnauthorized = null;

export const setToken = (t) => { token = t; };
export const setUnauthorizedHandler = (fn) => { onUnauthorized = fn; };

export class ApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export async function request(method, path, body, extraHeaders = {}) {
  let res;
  try {
    res = await fetch(`${API_URL}${path}`, {
      method,
      headers: {
        Accept: 'application/json',
        ...(body ? { 'Content-Type': 'application/json' } : {}),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...extraHeaders,
      },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch (e) {
    throw new ApiError(0, 'network', `Impossible de joindre le serveur (${API_URL}). Vérifie ta connexion.`);
  }
  let data = {};
  try { data = await res.json(); } catch { /* réponse vide */ }
  if (!res.ok) {
    if (res.status === 401 && token && onUnauthorized) onUnauthorized();
    throw new ApiError(res.status, data.error || 'error', data.message || 'Une erreur est survenue.');
  }
  return data;
}

export const api = {
  // Authentification
  register: (name, email, password, language) => request('POST', '/api/auth/register', { name, email, password, language }),
  login: (email, password) => request('POST', '/api/auth/login', { email, password }),
  me: () => request('GET', '/api/auth/me'),
  updateMe: (patch) => request('PATCH', '/api/auth/me', patch),
  logoutAll: () => request('POST', '/api/auth/logout-all'),
  deleteAccount: (password) => request('DELETE', '/api/auth/me', null, { 'X-Confirm-Password': password }),
  // Projets & modèles
  templates: () => request('GET', '/api/templates'),
  projects: () => request('GET', '/api/projects'),
  project: (id) => request('GET', `/api/projects/${id}`),
  createProject: (payload) => request('POST', '/api/projects', payload),
  saveProject: (id, spec) => request('PUT', `/api/projects/${id}`, { spec }),
  duplicateProject: (id) => request('POST', `/api/projects/${id}/duplicate`),
  deleteProject: (id) => request('DELETE', `/api/projects/${id}`),
  // IA
  generate: (prompt, projectId) => request('POST', '/api/ai/generate', { prompt, projectId }),
  // Export
  startExport: (id, mode) => request('POST', `/api/projects/${id}/export`, { mode }),
  exports: (id) => request('GET', `/api/projects/${id}/exports`),
  exportStatus: (exportId) => request('GET', `/api/exports/${exportId}`),
  downloadLink: (exportId) => request('POST', `/api/exports/${exportId}/link`),
  // Abonnement
  plans: () => request('GET', '/api/billing/plans'),
  checkout: (plan) => request('POST', '/api/billing/checkout', { plan }),
  devActivate: (plan) => request('POST', '/api/billing/dev-activate', { plan }),
  devCancel: () => request('POST', '/api/billing/dev-cancel'),
  portal: () => request('POST', '/api/billing/portal'),
};
