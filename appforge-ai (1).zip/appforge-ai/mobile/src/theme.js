// Identité visuelle Kubo : noir profond + vert citron, formes arrondies, contrastes francs.
export const colors = {
  bg: '#0A0A0B',
  bgAlt: '#121214',
  card: 'rgba(255,255,255,0.045)',
  cardStrong: 'rgba(255,255,255,0.08)',
  border: 'rgba(255,255,255,0.08)',
  text: '#FAFAFA',
  muted: '#A1A1AA',
  faint: '#63636B',
  accent: '#C6F432', // vert citron Kubo
  onAccent: '#0A0A0B', // texte posé sur le citron
  accentSoft: 'rgba(198,244,50,0.12)',
  // Alias conservés pour les écrans existants : tous pointent vers l'identité Kubo
  purple: '#C6F432',
  violet: '#C6F432',
  cyan: '#D9FF7A',
  pink: '#F472B6',
  gold: '#FDE047',
  success: '#4ADE80',
  danger: '#FB7185',
};

export const gradients = {
  brand: ['#D4FF4F', '#B2EA1E'],
  brandSoft: ['rgba(198,244,50,0.22)', 'rgba(198,244,50,0.04)'],
  premium: ['#FDE047', '#C6F432'],
  dark: ['#18181B', '#0A0A0B'],
};

export const radius = { sm: 12, md: 16, lg: 24, xl: 32, pill: 999 };

export const font = {
  h1: { fontSize: 32, fontWeight: '900', letterSpacing: -1.2, color: colors.text },
  h2: { fontSize: 23, fontWeight: '800', letterSpacing: -0.6, color: colors.text },
  h3: { fontSize: 17, fontWeight: '700', letterSpacing: -0.2, color: colors.text },
  body: { fontSize: 15, color: colors.text, lineHeight: 22 },
  small: { fontSize: 13, color: colors.muted },
  label: { fontSize: 11, fontWeight: '800', letterSpacing: 1.4, color: colors.muted, textTransform: 'uppercase' },
};

export const CATEGORY_META = {
  education: { icon: 'school', color: '#C6F432' },
  business: { icon: 'briefcase', color: '#C6F432' },
  games: { icon: 'game-controller', color: '#C6F432' },
  social: { icon: 'people', color: '#C6F432' },
  productivity: { icon: 'checkbox', color: '#C6F432' },
  custom: { icon: 'sparkles', color: '#C6F432' },
};

/** true si la couleur (#RRGGBB) est claire — utile pour choisir une couleur de texte lisible */
export function isLight(hex) {
  const h = String(hex || '').replace('#', '');
  if (h.length !== 6) return false;
  const [r, g, b] = [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.6;
}
