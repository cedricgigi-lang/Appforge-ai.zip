// Catalogue des composants de l'éditeur visuel : libellés, icônes, valeurs par défaut
// et description des champs modifiables (le formulaire est généré automatiquement).

export const ICON_CHOICES = [
  'home', 'sparkles', 'star', 'heart', 'school', 'book', 'briefcase', 'cart', 'storefront', 'people', 'person',
  'chatbubbles', 'newspaper', 'game-controller', 'trophy', 'checkbox', 'timer', 'calendar', 'mail', 'call',
  'location', 'camera', 'image', 'musical-notes', 'fitness', 'restaurant', 'car', 'airplane', 'medkit',
  'cash', 'stats-chart', 'settings', 'help-circle', 'information-circle', 'bulb', 'rocket', 'leaf', 'paw',
  'color-palette', 'search', 'globe', 'play-circle', 'images', 'help-buoy', 'easel', 'apps',
];

export const COMPONENTS = {
  header: {
    label: 'Titre', icon: 'text', group: 'Base',
    defaults: { title: 'Nouveau titre', subtitle: 'Sous-titre' },
    fields: [{ key: 'title', label: 'Titre', type: 'text' }, { key: 'subtitle', label: 'Sous-titre', type: 'text' }],
  },
  text: {
    label: 'Texte', icon: 'document-text', group: 'Base',
    defaults: { text: 'Écris ton texte ici.', size: 'md', align: 'left' },
    fields: [
      { key: 'text', label: 'Texte', type: 'multiline' },
      { key: 'size', label: 'Taille', type: 'select', options: [['sm', 'Petit'], ['md', 'Normal'], ['lg', 'Grand'], ['xl', 'Très grand']] },
      { key: 'align', label: 'Alignement', type: 'select', options: [['left', 'Gauche'], ['center', 'Centre'], ['right', 'Droite']] },
      { key: 'muted', label: 'Texte discret', type: 'bool' },
    ],
  },
  image: {
    label: 'Image', icon: 'image', group: 'Base',
    defaults: { uri: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800', height: 180 },
    fields: [
      { key: 'uri', label: 'Adresse de l’image (https://…)', type: 'text' },
      { key: 'height', label: 'Hauteur', type: 'number' },
      { key: 'caption', label: 'Légende', type: 'text' },
    ],
  },
  button: {
    label: 'Bouton', icon: 'radio-button-on', group: 'Base',
    defaults: { label: 'Mon bouton', action: 'alert', message: 'Bonjour !', variant: 'primary' },
    fields: [
      { key: 'label', label: 'Texte du bouton', type: 'text' },
      { key: 'variant', label: 'Style', type: 'select', options: [['primary', 'Plein'], ['outline', 'Contour']] },
      { key: 'action', label: 'Action', type: 'select', options: [['alert', 'Afficher un message'], ['navigate', 'Aller à un écran'], ['link', 'Ouvrir un lien']] },
      { key: 'message', label: 'Message', type: 'text', showIf: (p) => p.action === 'alert' },
      { key: 'target', label: 'Écran cible', type: 'screen', showIf: (p) => p.action === 'navigate' },
      { key: 'target', label: 'Lien (https://…)', type: 'text', showIf: (p) => p.action === 'link' },
    ],
  },
  card: {
    label: 'Carte', icon: 'albums', group: 'Base',
    defaults: { title: 'Titre de la carte', text: 'Une courte description.', icon: 'sparkles' },
    fields: [{ key: 'title', label: 'Titre', type: 'text' }, { key: 'text', label: 'Texte', type: 'multiline' }, { key: 'icon', label: 'Icône', type: 'icon' }],
  },
  list: {
    label: 'Liste', icon: 'list', group: 'Base',
    defaults: { title: 'Ma liste', items: [{ title: 'Élément 1', subtitle: 'Détail', icon: 'star' }] },
    fields: [
      { key: 'title', label: 'Titre', type: 'text' },
      { key: 'items', label: 'Éléments', type: 'items', newItem: { title: 'Nouvel élément', subtitle: '', icon: 'ellipse' },
        sub: [{ key: 'title', label: 'Titre', type: 'text' }, { key: 'subtitle', label: 'Sous-titre', type: 'text' }, { key: 'icon', label: 'Icône', type: 'icon' }] },
    ],
  },
  stats: {
    label: 'Statistiques', icon: 'stats-chart', group: 'Base',
    defaults: { items: [{ label: 'Membres', value: '120' }, { label: 'Note', value: '4,9' }] },
    fields: [{ key: 'items', label: 'Chiffres', type: 'items', max: 4, newItem: { label: 'Libellé', value: '0' },
      sub: [{ key: 'label', label: 'Libellé', type: 'text' }, { key: 'value', label: 'Valeur', type: 'text' }] }],
  },
  input: {
    label: 'Champ de saisie', icon: 'create', group: 'Formulaires',
    defaults: { label: 'Ton nom', placeholder: 'Écris ici…', keyboard: 'default' },
    fields: [
      { key: 'label', label: 'Libellé', type: 'text' },
      { key: 'placeholder', label: 'Texte indicatif', type: 'text' },
      { key: 'keyboard', label: 'Clavier', type: 'select', options: [['default', 'Texte'], ['email-address', 'Email'], ['numeric', 'Nombres'], ['phone-pad', 'Téléphone']] },
      { key: 'multiline', label: 'Plusieurs lignes', type: 'bool' },
    ],
  },
  divider: { label: 'Séparateur', icon: 'remove', group: 'Base', defaults: {}, fields: [] },
  todo: {
    label: 'Liste de tâches', icon: 'checkbox', group: 'Interactifs',
    defaults: { title: 'Mes tâches', placeholder: 'Nouvelle tâche…', items: ['Première tâche'] },
    fields: [
      { key: 'title', label: 'Titre', type: 'text' },
      { key: 'placeholder', label: 'Texte indicatif', type: 'text' },
      { key: 'items', label: 'Tâches de départ', type: 'strings' },
    ],
  },
  quiz: {
    label: 'Quiz', icon: 'help-circle', group: 'Interactifs',
    defaults: { title: 'Quiz', questions: [{ question: 'Ma question ?', options: ['Réponse A', 'Réponse B'], answer: 0 }] },
    fields: [
      { key: 'title', label: 'Titre', type: 'text' },
      { key: 'questions', label: 'Questions', type: 'items', newItem: { question: 'Nouvelle question ?', options: ['Oui', 'Non'], answer: 0 },
        sub: [
          { key: 'question', label: 'Question', type: 'text' },
          { key: 'options', label: 'Réponses (une par ligne)', type: 'lines' },
          { key: 'answer', label: 'N° de la bonne réponse (1, 2, 3…)', type: 'answer' },
        ] },
    ],
  },
  counter: {
    label: 'Compteur', icon: 'add-circle', group: 'Interactifs',
    defaults: { label: 'Compteur', step: 1, start: 0 },
    fields: [{ key: 'label', label: 'Libellé', type: 'text' }, { key: 'step', label: 'Pas', type: 'number' }, { key: 'start', label: 'Valeur de départ', type: 'number' }],
  },
  timer: {
    label: 'Minuteur', icon: 'timer', group: 'Interactifs',
    defaults: { label: 'Minuteur', minutes: 25 },
    fields: [{ key: 'label', label: 'Libellé', type: 'text' }, { key: 'minutes', label: 'Durée (minutes)', type: 'number' }],
  },
  tapgame: {
    label: 'Mini-jeu', icon: 'game-controller', group: 'Interactifs',
    defaults: { title: 'Tape le plus vite possible !', duration: 10 },
    fields: [{ key: 'title', label: 'Titre', type: 'text' }, { key: 'duration', label: 'Durée (secondes)', type: 'number' }],
  },
  feed: {
    label: "Fil d'actualité", icon: 'newspaper', group: 'Interactifs',
    defaults: { title: 'Quoi de neuf ?', allowPosting: true, posts: [{ author: 'Admin', text: 'Bienvenue !', likes: 0 }] },
    fields: [
      { key: 'title', label: 'Titre', type: 'text' },
      { key: 'allowPosting', label: 'Autoriser les publications', type: 'bool' },
      { key: 'posts', label: 'Publications', type: 'items', newItem: { author: 'Moi', text: 'Nouveau message', likes: 0 },
        sub: [{ key: 'author', label: 'Auteur', type: 'text' }, { key: 'text', label: 'Message', type: 'multiline' }] },
    ],
  },
};

Object.assign(COMPONENTS, {
  hero: {
    label: 'Bannière', icon: 'easel', group: 'Design',
    defaults: { title: 'Bienvenue !', subtitle: 'Une phrase qui donne envie de découvrir ton app.', buttonLabel: 'Découvrir', target: '', image: '' },
    fields: [
      { key: 'title', label: 'Titre', type: 'text' },
      { key: 'subtitle', label: 'Sous-titre', type: 'multiline' },
      { key: 'buttonLabel', label: 'Texte du bouton (vide = pas de bouton)', type: 'text' },
      { key: 'target', label: 'Le bouton ouvre l’écran', type: 'screen' },
      { key: 'image', label: 'Image de fond (https://…, facultatif)', type: 'text' },
    ],
  },
  gallery: {
    label: 'Galerie', icon: 'images', group: 'Design',
    defaults: { title: 'Galerie', images: [
      'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=600',
      'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=600',
    ] },
    fields: [{ key: 'title', label: 'Titre', type: 'text' }, { key: 'images', label: 'Adresses des images (une par ligne, https://…)', type: 'strings' }],
  },
  video: {
    label: 'Vidéo', icon: 'play-circle', group: 'Design',
    defaults: { title: 'Notre vidéo', url: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ', caption: '' },
    fields: [{ key: 'title', label: 'Titre', type: 'text' }, { key: 'url', label: 'Lien YouTube ou vidéo (https://…)', type: 'text' }, { key: 'caption', label: 'Légende', type: 'text' }],
  },
  faq: {
    label: 'FAQ', icon: 'help-buoy', group: 'Design',
    defaults: { title: 'Questions fréquentes', items: [{ question: 'Comment ça marche ?', answer: 'Explique ici le fonctionnement.' }] },
    fields: [
      { key: 'title', label: 'Titre', type: 'text' },
      { key: 'items', label: 'Questions', type: 'items', newItem: { question: 'Nouvelle question ?', answer: 'Réponse.' },
        sub: [{ key: 'question', label: 'Question', type: 'text' }, { key: 'answer', label: 'Réponse', type: 'multiline' }] },
    ],
  },
  imagegen: {
    label: 'Images IA', icon: 'color-palette', group: 'IA',
    defaults: { title: 'Crée une image avec l’IA', placeholder: 'Décris l’image à créer…', style: 'auto' },
    fields: [
      { key: 'title', label: 'Titre', type: 'text' },
      { key: 'placeholder', label: 'Texte indicatif', type: 'text' },
      { key: 'style', label: 'Style par défaut', type: 'select', options: [['auto', 'Libre'], ['realiste', 'Réaliste'], ['dessin', 'Dessin'], ['aquarelle', 'Aquarelle'], ['3d', '3D'], ['anime', 'Anime']] },
    ],
  },
  chatbot: {
    label: 'Chatbot', icon: 'chatbubbles', group: 'IA',
    defaults: { name: 'Assistant', welcome: 'Bonjour ! Comment puis-je t’aider ?', instructions: '', faq: [{ question: 'Qui es-tu ?', answer: 'Je suis l’assistant de cette application.' }] },
    fields: [
      { key: 'name', label: 'Nom de l’assistant', type: 'text' },
      { key: 'welcome', label: 'Message d’accueil', type: 'multiline' },
      { key: 'instructions', label: 'Personnalité et consignes pour l’IA (facultatif)', type: 'multiline' },
      { key: 'faq', label: 'Réponses prêtes (sans IA)', type: 'items', newItem: { question: 'Nouvelle question ?', answer: 'Réponse.' },
        sub: [{ key: 'question', label: 'Question', type: 'text' }, { key: 'answer', label: 'Réponse', type: 'multiline' }] },
    ],
  },
  search: {
    label: 'Recherche', icon: 'search', group: 'IA',
    defaults: { title: 'Rechercher', placeholder: 'Que cherches-tu ?', source: 'app' },
    fields: [
      { key: 'title', label: 'Titre', type: 'text' },
      { key: 'placeholder', label: 'Texte indicatif', type: 'text' },
      { key: 'source', label: 'Chercher dans', type: 'select', options: [['app', 'Mon application'], ['wikipedia', 'Wikipédia (Internet)']] },
    ],
  },
});

export const GROUPS = ['IA', 'Design', 'Base', 'Formulaires', 'Interactifs'];

export const PALETTES = [
  { name: 'Néon', primary: '#8B5CF6', secondary: '#22D3EE', background: '#0B0B1A', surface: '#16162E', text: '#F5F5FF' },
  { name: 'Océan', primary: '#3B82F6', secondary: '#2DD4BF', background: '#06111F', surface: '#0F1E33', text: '#EAF4FF' },
  { name: 'Coucher de soleil', primary: '#F97316', secondary: '#EC4899', background: '#140A0A', surface: '#24130F', text: '#FFF4EE' },
  { name: 'Forêt', primary: '#10B981', secondary: '#A3E635', background: '#07130D', surface: '#10231A', text: '#ECFDF5' },
  { name: 'Rose', primary: '#EC4899', secondary: '#A855F7', background: '#14061A', surface: '#22102B', text: '#FFF0FA' },
  { name: 'Or', primary: '#F59E0B', secondary: '#FDE68A', background: '#0F0C05', surface: '#1E180C', text: '#FFF9EB' },
  { name: 'Clair', primary: '#7C3AED', secondary: '#0EA5E9', background: '#F6F6FB', surface: '#FFFFFF', text: '#16162B' },
];

let counter = 0;
export const uid = () => `c${Date.now().toString(36)}${(counter++).toString(36)}`;
