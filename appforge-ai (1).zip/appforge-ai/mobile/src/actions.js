import { Alert } from 'react-native';
import { router } from 'expo-router';
import { api } from './api';

/** Affiche une erreur API ; propose Premium si une limite de la formule gratuite est atteinte. */
export function showApiError(e, t) {
  if (e && e.status === 402) {
    Alert.alert(t('limit.title'), e.message, [
      { text: t('common.cancel'), style: 'cancel' },
      { text: t('common.upgrade'), onPress: () => router.push('/premium') },
    ]);
  } else {
    Alert.alert(t('common.error'), (e && e.message) || 'Erreur');
  }
}

/** Crée un projet à partir d'un modèle puis ouvre l'éditeur. */
export async function createFromTemplate(id, t, refresh) {
  try {
    const r = await api.createProject({ templateId: id });
    if (refresh) refresh();
    router.push(`/editor/${r.project.id}`);
  } catch (e) {
    showApiError(e, t);
  }
}
