import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import * as SecureStore from 'expo-secure-store';
import { api, setToken, setUnauthorizedHandler } from './api';

const TOKEN_KEY = 'appforge_token';
const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [usage, setUsage] = useState(null);
  const [ready, setReady] = useState(false);

  const logout = useCallback(async () => {
    setToken(null);
    setUser(null);
    setUsage(null);
    await SecureStore.deleteItemAsync(TOKEN_KEY).catch(() => {});
  }, []);

  const refresh = useCallback(async () => {
    const data = await api.me();
    setUser(data.user);
    setUsage(data.usage);
    return data;
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(() => { logout(); });
    (async () => {
      try {
        const saved = await SecureStore.getItemAsync(TOKEN_KEY);
        if (saved) {
          setToken(saved);
          await refresh();
        }
      } catch {
        // jeton expiré ou serveur injoignable : on repart de l'écran d'accueil
        setToken(null);
      } finally {
        setReady(true);
      }
    })();
  }, [logout, refresh]);

  const signIn = useCallback(async ({ token, user: u }) => {
    setToken(token);
    await SecureStore.setItemAsync(TOKEN_KEY, token);
    setUser(u);
    refresh().catch(() => {});
  }, [refresh]);

  const login = useCallback(async (email, password) => signIn(await api.login(email, password)), [signIn]);
  const register = useCallback(async (name, email, password, language) => signIn(await api.register(name, email, password, language)), [signIn]);

  const value = useMemo(() => ({
    user, usage, ready, login, register, logout, refresh, setUser,
    isPremium: user && user.plan === 'premium',
    // Premium désactivé côté serveur : tout le monde a accès à tout
    premiumEnabled: !!(usage && usage.premiumEnabled),
    fullAccess: !(usage && usage.premiumEnabled) || (user && user.plan === 'premium'),
  }), [user, usage, ready, login, register, logout, refresh]);

  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export const useAuth = () => useContext(AuthCtx);
