// Briques de l'éditeur visuel : formulaire de propriétés auto-généré, sélecteurs, palette.
import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COMPONENTS, GROUPS, ICON_CHOICES } from '../catalog';
import { colors } from '../theme';

export function Label({ children }) {
  return <Text style={st.label}>{children}</Text>;
}

export function TextBox({ value, onChange, multiline, placeholder, keyboardType }) {
  return (
    <TextInput
      value={value == null ? '' : String(value)}
      onChangeText={onChange}
      multiline={multiline}
      placeholder={placeholder}
      placeholderTextColor={colors.faint}
      keyboardType={keyboardType}
      autoCapitalize="sentences"
      style={[st.input, multiline && { minHeight: 76, textAlignVertical: 'top' }]}
    />
  );
}

/** Champ numérique : garde la saisie locale et ne valide que les nombres */
export function NumberBox({ value, onChange, min = -1e6, max = 1e6 }) {
  const [txt, setTxt] = useState(String(value ?? ''));
  useEffect(() => { setTxt(String(value ?? '')); }, [value]);
  return (
    <TextInput
      value={txt}
      keyboardType="numeric"
      onChangeText={(v) => {
        setTxt(v);
        const n = parseInt(v, 10);
        if (Number.isFinite(n)) onChange(Math.min(max, Math.max(min, n)));
      }}
      style={st.input}
    />
  );
}

/** Champ couleur hexadécimale avec pastille */
export function ColorBox({ label, value, onChange }) {
  const [txt, setTxt] = useState(value);
  useEffect(() => { setTxt(value); }, [value]);
  return (
    <View style={{ flex: 1, minWidth: '45%' }}>
      <Label>{label}</Label>
      <View style={[st.input, { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 }]}>
        <View style={{ width: 24, height: 24, borderRadius: 7, backgroundColor: /^#[0-9a-fA-F]{6}$/.test(txt) ? txt : value, marginRight: 10, borderWidth: 1, borderColor: '#ffffff30' }} />
        <TextInput
          value={txt}
          autoCapitalize="characters"
          maxLength={7}
          onChangeText={(v) => {
            const s = v.startsWith('#') ? v : `#${v}`;
            setTxt(s);
            if (/^#[0-9a-fA-F]{6}$/.test(s)) onChange(s.toUpperCase());
          }}
          style={{ color: colors.text, flex: 1, fontSize: 14, padding: 0 }}
        />
      </View>
    </View>
  );
}

export function Segmented({ options, value, onChange, wrap }) {
  const Wrap = wrap ? View : ScrollView;
  const wrapProps = wrap ? { style: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 } } : { horizontal: true, showsHorizontalScrollIndicator: false, contentContainerStyle: { gap: 6 } };
  return (
    <Wrap {...wrapProps}>
      {options.map(([v, l]) => {
        const active = v === value;
        return (
          <Pressable key={v} onPress={() => onChange(v)} style={[st.seg, active && { backgroundColor: colors.violet, borderColor: colors.violet }]}>
            <Text style={{ color: active ? colors.onAccent : colors.muted, fontWeight: '700', fontSize: 13 }}>{l}</Text>
          </Pressable>
        );
      })}
    </Wrap>
  );
}

export function IconPicker({ value, onChange }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6 }}>
      {ICON_CHOICES.map((ic) => (
        <Pressable key={ic} onPress={() => onChange(ic)} style={[st.iconCell, value === ic && { borderColor: colors.cyan, backgroundColor: 'rgba(198,244,50,0.15)' }]}>
          <Ionicons name={ic} size={20} color={value === ic ? colors.cyan : colors.muted} />
        </Pressable>
      ))}
    </ScrollView>
  );
}

function FieldInput({ field, value, onChange, screens, props }) {
  switch (field.type) {
    case 'text': return <TextBox value={value} onChange={onChange} />;
    case 'multiline': return <TextBox value={value} onChange={onChange} multiline />;
    case 'number': return <NumberBox value={value} onChange={onChange} />;
    case 'select': return <Segmented options={field.options} value={value} onChange={onChange} wrap />;
    case 'bool': return <Switch value={!!value} onValueChange={onChange} trackColor={{ true: colors.violet, false: '#33334D' }} thumbColor="#fff" />;
    case 'icon': return <IconPicker value={value} onChange={onChange} />;
    case 'screen': return <Segmented options={screens.map((s) => [s.id, s.title])} value={value} onChange={onChange} wrap />;
    case 'strings':
    case 'lines':
      return (
        <TextBox
          multiline
          value={(value || []).join('\n')}
          onChange={(v) => onChange(v.split('\n'))}
          placeholder="Un élément par ligne"
        />
      );
    case 'answer': {
      const count = (props.options || []).length || 1;
      return <Segmented options={Array.from({ length: count }, (_, i) => [i, String(i + 1)])} value={value || 0} onChange={onChange} />;
    }
    case 'items': return <ItemsEditor field={field} value={value || []} onChange={onChange} screens={screens} />;
    default: return null;
  }
}

/** Éditeur de listes d'objets (éléments de liste, questions, publications…) */
function ItemsEditor({ field, value, onChange, screens }) {
  const max = field.max || 30;
  const set = (i, key, v) => onChange(value.map((it, j) => (j === i ? { ...it, [key]: v } : it)));
  const move = (i, d) => {
    const j = i + d;
    if (j < 0 || j >= value.length) return;
    const next = [...value];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };
  return (
    <View style={{ gap: 10 }}>
      {value.map((it, i) => (
        <View key={i} style={st.itemBox}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6 }}>
            <Text style={{ color: colors.cyan, fontWeight: '800', flex: 1 }}>#{i + 1}</Text>
            <Pressable onPress={() => move(i, -1)} hitSlop={6} style={st.mini}><Ionicons name="arrow-up" size={16} color={colors.muted} /></Pressable>
            <Pressable onPress={() => move(i, 1)} hitSlop={6} style={st.mini}><Ionicons name="arrow-down" size={16} color={colors.muted} /></Pressable>
            <Pressable onPress={() => onChange(value.filter((_, j) => j !== i))} hitSlop={6} style={st.mini}><Ionicons name="trash-outline" size={16} color={colors.danger} /></Pressable>
          </View>
          {field.sub.map((sf) => (
            <View key={sf.key} style={{ marginBottom: 8 }}>
              <Label>{sf.label}</Label>
              <FieldInput field={sf} value={it[sf.key]} props={it} screens={screens} onChange={(v) => set(i, sf.key, v)} />
            </View>
          ))}
        </View>
      ))}
      {value.length < max && (
        <Pressable onPress={() => onChange([...value, JSON.parse(JSON.stringify(field.newItem))])} style={st.addRow}>
          <Ionicons name="add-circle" size={18} color={colors.cyan} />
          <Text style={{ color: colors.cyan, fontWeight: '700', marginLeft: 8 }}>Ajouter</Text>
        </Pressable>
      )}
    </View>
  );
}

/** Formulaire complet d'un composant, généré depuis le catalogue */
export function PropEditor({ component, screens, onChange }) {
  const def = COMPONENTS[component.type];
  if (!def) return null;
  if (!def.fields.length) return <Text style={{ color: colors.muted }}>Ce composant n'a pas de réglages.</Text>;
  const p = component.props || {};
  return (
    <View>
      {def.fields.filter((f) => !f.showIf || f.showIf(p)).map((f, i) => (
        <View key={`${f.key}-${i}`} style={{ marginBottom: 14 }}>
          <Label>{f.label}</Label>
          <FieldInput field={f} value={p[f.key]} props={p} screens={screens} onChange={(v) => onChange(f.key, v)} />
        </View>
      ))}
    </View>
  );
}

/** Grille d'ajout de composants */
export function ComponentPalette({ onAdd }) {
  return (
    <View>
      {GROUPS.map((g) => (
        <View key={g} style={{ marginBottom: 14 }}>
          <Text style={[st.label, { textTransform: 'uppercase', letterSpacing: 1, fontSize: 11, color: g === 'IA' ? colors.cyan : colors.muted }]}>
            {g === 'IA' ? '✨ Intelligence artificielle' : g}
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {Object.entries(COMPONENTS).filter(([, d]) => d.group === g).map(([type, d]) => (
              <Pressable key={type} onPress={() => onAdd(type)} style={({ pressed }) => [st.paletteCell, pressed && { backgroundColor: 'rgba(198,244,50,0.2)', borderColor: colors.purple }]}>
                <Ionicons name={d.icon} size={22} color={colors.cyan} />
                <Text style={{ color: colors.text, fontSize: 12, fontWeight: '600', marginTop: 6, textAlign: 'center' }} numberOfLines={1}>{d.label}</Text>
              </Pressable>
            ))}
          </View>
        </View>
      ))}
    </View>
  );
}

const st = StyleSheet.create({
  label: { color: colors.muted, fontSize: 12, fontWeight: '700', marginBottom: 6 },
  input: { backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1, borderColor: colors.border, borderRadius: 12, color: colors.text, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14 },
  seg: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10, borderWidth: 1, borderColor: colors.border, backgroundColor: 'rgba(255,255,255,0.04)' },
  iconCell: { width: 42, height: 42, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.border },
  itemBox: { backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: 14, padding: 12, borderWidth: 1, borderColor: colors.border },
  mini: { width: 30, height: 30, alignItems: 'center', justifyContent: 'center' },
  addRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 12, borderRadius: 12, borderWidth: 1, borderStyle: 'dashed', borderColor: 'rgba(198,244,50,0.4)' },
  paletteCell: { width: '31%', paddingVertical: 14, alignItems: 'center', borderRadius: 14, borderWidth: 1, borderColor: colors.border, backgroundColor: 'rgba(255,255,255,0.04)' },
});
