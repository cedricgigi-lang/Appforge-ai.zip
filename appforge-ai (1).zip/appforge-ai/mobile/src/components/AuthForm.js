import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, View } from 'react-native';
import { router } from 'expo-router';
import { Screen, TopBar, Field, GradientButton, Logo } from './ui';
import { useAuth } from '../auth';
import { useI18n } from '../i18n';
import { colors, font } from '../theme';

export function AuthForm({ mode }) {
  const isRegister = mode === 'register';
  const { login, register } = useAuth();
  const { t, lang } = useI18n();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    setError('');
    if (!email || !password || (isRegister && !name)) { setError(t('auth.fillAll')); return; }
    setLoading(true);
    try {
      if (isRegister) await register(name.trim(), email.trim(), password, lang);
      else await login(email.trim(), password);
      router.replace('/home');
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <TopBar title="" />
        <ScrollView contentContainerStyle={{ padding: 24 }} keyboardShouldPersistTaps="handled">
          <Logo size={56} />
          <Text style={[font.h1, { marginTop: 22 }]}>{t(isRegister ? 'auth.registerTitle' : 'auth.loginTitle')}</Text>
          <Text style={[font.body, { color: colors.muted, marginTop: 6, marginBottom: 28 }]}>{t(isRegister ? 'auth.registerSubtitle' : 'auth.loginSubtitle')}</Text>

          {isRegister && (
            <Field label={t('auth.name')} icon="person-outline" value={name} onChangeText={setName} autoCapitalize="words" placeholder="Awa Mbuyi" textContentType="name" />
          )}
          <Field label={t('auth.email')} icon="mail-outline" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="toi@exemple.com" textContentType="emailAddress" autoComplete="email" />
          <Field label={t('auth.password')} icon="lock-closed-outline" value={password} onChangeText={setPassword} secure placeholder="••••••••"
            hint={isRegister ? t('auth.passwordHint') : undefined} textContentType={isRegister ? 'newPassword' : 'password'} onSubmitEditing={submit} />

          {!!error && (
            <View style={{ backgroundColor: 'rgba(244,63,94,0.12)', borderColor: 'rgba(244,63,94,0.35)', borderWidth: 1, borderRadius: 12, padding: 12, marginBottom: 14 }}>
              <Text style={{ color: '#FDA4AF' }}>{error}</Text>
            </View>
          )}

          <GradientButton title={t(isRegister ? 'auth.register' : 'auth.login')} onPress={submit} loading={loading} style={{ marginTop: 6 }} />
          <Pressable onPress={() => router.replace(isRegister ? '/login' : '/register')} style={{ marginTop: 22, alignItems: 'center' }}>
            <Text style={{ color: colors.cyan, fontWeight: '700' }}>{t(isRegister ? 'auth.hasAccount' : 'auth.noAccount')}</Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}
