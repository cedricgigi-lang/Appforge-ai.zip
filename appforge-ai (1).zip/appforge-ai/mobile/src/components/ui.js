// Composants d'interface Kubo : boutons-pilules citron, cartes très arrondies, typographie forte.
import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator, Animated, Image, Pressable, StyleSheet, Text, TextInput, View,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { colors, gradients, radius, font, isLight } from '../theme';

const LOGO = require('../../assets/logo.png');
const tap = () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});

/** Fond noir profond avec un halo citron discret */
export function Screen({ children, edges = ['top'], style }) {
  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <View pointerEvents="none" style={[styles.glow, { top: -220, right: -160 }]} />
      <SafeAreaView edges={edges} style={[{ flex: 1 }, style]}>{children}</SafeAreaView>
    </View>
  );
}

/** Icône de l'application (cube Kubo) */
export function Logo({ size = 44 }) {
  return <Image source={LOGO} style={{ width: size, height: size, borderRadius: size * 0.26 }} />;
}

/** Logo + nom « kubo » */
export function Brand({ size = 36 }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
      <Logo size={size} />
      <Text style={{ color: colors.text, fontSize: size * 0.72, fontWeight: '900', letterSpacing: -1 }}>
        kubo<Text style={{ color: colors.accent }}>.</Text>
      </Text>
    </View>
  );
}

/** Bouton principal : pilule citron, texte noir (couleurs personnalisables) */
export function GradientButton({ title, onPress, icon, loading, disabled, size = 'md', colorsOverride, style }) {
  const big = size === 'lg';
  const bg = colorsOverride || gradients.brand;
  const fg = isLight(bg[0]) ? colors.onAccent : '#FFFFFF';
  return (
    <Pressable
      onPress={() => { if (!loading && !disabled) { tap(); onPress && onPress(); } }}
      style={({ pressed }) => [{ opacity: disabled ? 0.45 : pressed ? 0.9 : 1, transform: [{ scale: pressed ? 0.97 : 1 }] }, style]}
    >
      <LinearGradient colors={bg} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.btn, big && styles.btnBig]}>
        {loading ? <ActivityIndicator color={fg} /> : (
          <>
            {icon && <Ionicons name={icon} size={big ? 22 : 19} color={fg} style={{ marginRight: 10 }} />}
            <Text style={[styles.btnText, { color: fg }, big && { fontSize: 17 }]} numberOfLines={1}>{title}</Text>
          </>
        )}
      </LinearGradient>
    </Pressable>
  );
}

/** Bouton secondaire : pilule à contour */
export function GhostButton({ title, onPress, icon, color = colors.text, style, danger }) {
  const c = danger ? colors.danger : color;
  return (
    <Pressable onPress={() => { tap(); onPress && onPress(); }}
      style={({ pressed }) => [styles.ghost, { borderColor: danger ? 'rgba(251,113,133,0.4)' : 'rgba(255,255,255,0.16)', opacity: pressed ? 0.7 : 1 }, style]}>
      {icon && <Ionicons name={icon} size={18} color={c} style={{ marginRight: 8 }} />}
      <Text style={{ color: c, fontWeight: '700', fontSize: 15 }}>{title}</Text>
    </Pressable>
  );
}

export function Card({ children, style, onPress, strong }) {
  const content = <View style={[styles.card, strong && { backgroundColor: colors.cardStrong }, style]}>{children}</View>;
  if (!onPress) return content;
  return (
    <Pressable onPress={() => { tap(); onPress(); }} style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.985 : 1 }] })}>
      {content}
    </Pressable>
  );
}

export function Field({ label, icon, secure, hint, style, ...props }) {
  const [hidden, setHidden] = useState(!!secure);
  const [focus, setFocus] = useState(false);
  return (
    <View style={[{ marginBottom: 14 }, style]}>
      {!!label && <Text style={styles.label}>{label}</Text>}
      <View style={[styles.field, focus && { borderColor: colors.accent, backgroundColor: colors.accentSoft }]}>
        {icon && <Ionicons name={icon} size={18} color={focus ? colors.accent : colors.faint} style={{ marginRight: 10 }} />}
        <TextInput
          placeholderTextColor={colors.faint}
          secureTextEntry={hidden}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          selectionColor={colors.accent}
          style={[styles.input, props.multiline && { minHeight: 80, textAlignVertical: 'top', paddingTop: 12 }]}
          {...props}
        />
        {secure && (
          <Pressable onPress={() => setHidden(!hidden)} hitSlop={10}>
            <Ionicons name={hidden ? 'eye-outline' : 'eye-off-outline'} size={20} color={colors.faint} />
          </Pressable>
        )}
      </View>
      {!!hint && <Text style={[font.small, { marginTop: 6, fontSize: 12 }]}>{hint}</Text>}
    </View>
  );
}

export function TopBar({ title, right, onBack, subtitle }) {
  return (
    <View style={styles.topbar}>
      <IconButton icon="arrow-back" onPress={onBack || (() => (router.canGoBack() ? router.back() : router.replace('/home')))} />
      <View style={{ flex: 1, marginHorizontal: 12 }}>
        <Text style={[font.h3, { fontSize: 18 }]} numberOfLines={1}>{title}</Text>
        {!!subtitle && <Text style={[font.small, { fontSize: 12 }]} numberOfLines={1}>{subtitle}</Text>}
      </View>
      {right}
    </View>
  );
}

export function IconButton({ icon, onPress, color = colors.text, bg, size = 20, style }) {
  const filled = bg === colors.accent || bg === colors.violet;
  return (
    <Pressable onPress={() => { tap(); onPress && onPress(); }} hitSlop={6}
      style={({ pressed }) => [styles.iconBtn, bg && { backgroundColor: bg, borderColor: bg }, { opacity: pressed ? 0.6 : 1 }, style]}>
      <Ionicons name={icon} size={size} color={filled ? colors.onAccent : color} />
    </Pressable>
  );
}

export function Chip({ label, active, onPress, icon }) {
  return (
    <Pressable onPress={() => { tap(); onPress && onPress(); }}
      style={[styles.chip, active ? { backgroundColor: colors.accent, borderColor: colors.accent } : null]}>
      {icon && <Ionicons name={icon} size={14} color={active ? colors.onAccent : colors.muted} style={{ marginRight: 6 }} />}
      <Text style={{ color: active ? colors.onAccent : colors.muted, fontWeight: active ? '800' : '600', fontSize: 13 }}>{label}</Text>
    </Pressable>
  );
}

export function ProBadge({ small }) {
  return (
    <View style={{ backgroundColor: colors.accent, paddingHorizontal: small ? 7 : 10, paddingVertical: small ? 2 : 4, borderRadius: 99, flexDirection: 'row', alignItems: 'center' }}>
      <Ionicons name="flash" size={small ? 10 : 12} color={colors.onAccent} />
      <Text style={{ color: colors.onAccent, fontWeight: '900', fontSize: small ? 10 : 12, marginLeft: 3 }}>PRO</Text>
    </View>
  );
}

/** Icône d'un projet créé par l'utilisateur (couleurs de son application) */
export function AppIcon({ icon, colorsPair, size = 52 }) {
  return (
    <LinearGradient colors={colorsPair} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
      style={{ width: size, height: size, borderRadius: size * 0.3, alignItems: 'center', justifyContent: 'center' }}>
      <Ionicons name={Ionicons.glyphMap[icon] ? icon : 'apps'} size={size * 0.48} color={isLight(colorsPair[0]) ? colors.onAccent : '#fff'} />
    </LinearGradient>
  );
}

export function SectionTitle({ title, action, onAction }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 30, marginBottom: 14 }}>
      <Text style={[font.h2, { fontSize: 20 }]}>{title}</Text>
      {!!action && (
        <Pressable onPress={onAction} hitSlop={8} style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ color: colors.accent, fontWeight: '700' }}>{action}</Text>
          <Ionicons name="arrow-forward" size={15} color={colors.accent} style={{ marginLeft: 4 }} />
        </Pressable>
      )}
    </View>
  );
}

export function EmptyState({ icon = 'cube-outline', text, action, onAction }) {
  return (
    <View style={{ alignItems: 'center', padding: 28 }}>
      <View style={{ width: 76, height: 76, borderRadius: 26, backgroundColor: colors.accentSoft, alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
        <Ionicons name={icon} size={34} color={colors.accent} />
      </View>
      <Text style={[font.body, { color: colors.muted, textAlign: 'center', marginBottom: 18 }]}>{text}</Text>
      {action && <GradientButton title={action} icon="sparkles" onPress={onAction} />}
    </View>
  );
}

export function ProgressBar({ value, max }) {
  const pct = max ? Math.min(1, value / max) : 0.15;
  return (
    <View style={{ height: 8, borderRadius: 4, backgroundColor: colors.cardStrong, overflow: 'hidden' }}>
      <View style={{ width: `${Math.max(4, pct * 100)}%`, height: '100%', backgroundColor: colors.accent, borderRadius: 4 }} />
    </View>
  );
}

/** Trois points animés (« l'IA réfléchit ») */
export function TypingDots({ color = colors.accent }) {
  const dots = [useRef(new Animated.Value(0.3)).current, useRef(new Animated.Value(0.3)).current, useRef(new Animated.Value(0.3)).current];
  useEffect(() => {
    const anims = dots.map((d, i) => Animated.loop(Animated.sequence([
      Animated.delay(i * 160),
      Animated.timing(d, { toValue: 1, duration: 320, useNativeDriver: true }),
      Animated.timing(d, { toValue: 0.3, duration: 320, useNativeDriver: true }),
      Animated.delay((2 - i) * 160),
    ])));
    anims.forEach((a) => a.start());
    return () => anims.forEach((a) => a.stop());
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <View style={{ flexDirection: 'row', gap: 5 }}>
      {dots.map((d, i) => <Animated.View key={i} style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: color, opacity: d }} />)}
    </View>
  );
}

const styles = StyleSheet.create({
  glow: { position: 'absolute', width: 420, height: 420, borderRadius: 210, backgroundColor: 'rgba(198,244,50,0.07)' },
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 16, paddingHorizontal: 24, borderRadius: radius.pill },
  btnBig: { paddingVertical: 19 },
  btnText: { fontWeight: '800', fontSize: 16, letterSpacing: -0.2 },
  ghost: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 15, paddingHorizontal: 20, borderRadius: radius.pill, borderWidth: 1.5 },
  card: { backgroundColor: colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: 18 },
  label: { color: colors.muted, fontSize: 13, fontWeight: '600', marginBottom: 8 },
  field: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: colors.border, backgroundColor: colors.card, borderRadius: radius.md, paddingHorizontal: 16 },
  input: { flex: 1, color: colors.text, fontSize: 15, paddingVertical: 14 },
  topbar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10 },
  iconBtn: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border },
  chip: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 15, paddingVertical: 9, borderRadius: 99, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border },
});
