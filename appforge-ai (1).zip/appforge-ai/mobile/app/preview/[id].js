import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, Text, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AppRuntime from '../../src/runtime/AppRuntime';
import { GradientButton, GhostButton } from '../../src/components/ui';
import { useI18n } from '../../src/i18n';
import { useAuth } from '../../src/auth';
import { api, API_URL } from '../../src/api';
import { createFromTemplate } from '../../src/actions';
import { colors, isLight } from '../../src/theme';

export default function Preview() {
  const { id } = useLocalSearchParams();
  const { t } = useI18n();
  const { refresh } = useAuth();
  const insets = useSafeAreaInsets();
  const isTemplate = String(id).startsWith('tpl:');
  const templateId = isTemplate ? String(id).slice(4) : null;
  const [spec, setSpec] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [runKey, setRunKey] = useState(0);

  useEffect(() => {
    const load = isTemplate
      ? api.templates().then((r) => {
        const tp = r.templates.find((x) => x.id === templateId);
        if (!tp) throw new Error('Modèle introuvable');
        return tp.spec;
      })
      : api.project(String(id)).then((r) => r.project.spec);
    load.then(setSpec).catch((e) => setError(e.message));
  }, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (error) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg, padding: 24, justifyContent: 'center' }}>
        <Text style={{ color: colors.danger, textAlign: 'center', marginBottom: 16 }}>{error}</Text>
        <GhostButton title="Retour" onPress={() => router.back()} />
      </SafeAreaView>
    );
  }
  if (!spec) {
    return <View style={{ flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={colors.cyan} /></View>;
  }

  const light = isLight(spec.theme.surface);
  const barColor = light ? '#16162B' : '#FFFFFF';

  return (
    <View style={{ flex: 1, backgroundColor: spec.theme.background, paddingTop: insets.top }}>
      {/* Barre de l'aperçu */}
      <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 8, backgroundColor: spec.theme.surface, borderBottomWidth: 1, borderBottomColor: barColor + '14' }}>
        <Pressable onPress={() => router.back()} hitSlop={10} style={{ padding: 6 }}>
          <Ionicons name="close" size={24} color={barColor} />
        </Pressable>
        <View style={{ flex: 1, alignItems: 'center' }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: '#22C55E', marginRight: 6 }} />
            <Text style={{ color: barColor, fontWeight: '800' }} numberOfLines={1}>{spec.name}</Text>
          </View>
          <Text style={{ color: barColor + '99', fontSize: 11 }}>Aperçu en direct</Text>
        </View>
        <Pressable onPress={() => setRunKey((k) => k + 1)} hitSlop={10} style={{ padding: 6 }}>
          <Ionicons name="refresh" size={22} color={barColor} />
        </Pressable>
        {!isTemplate && (
          <Pressable onPress={() => router.replace(`/editor/${id}`)} hitSlop={10} style={{ padding: 6 }}>
            <Ionicons name="color-wand" size={22} color={spec.theme.secondary} />
          </Pressable>
        )}
      </View>

      <View style={{ flex: 1 }}>
        <AppRuntime key={runKey} spec={spec} apiUrl={API_URL} projectId={isTemplate ? undefined : String(id)} bottomInset={isTemplate ? 0 : insets.bottom} />
      </View>

      {isTemplate && (
        <View style={{ padding: 14, paddingBottom: 14 + insets.bottom, backgroundColor: colors.bg, borderTopWidth: 1, borderTopColor: colors.border }}>
          <GradientButton title={t('templates.use')} icon="sparkles" loading={busy}
            onPress={async () => { setBusy(true); await createFromTemplate(templateId, t, refresh); setBusy(false); }} />
        </View>
      )}
    </View>
  );
}
