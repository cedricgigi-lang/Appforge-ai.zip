import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Linking, Pressable, ScrollView, Text, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import * as WebBrowser from 'expo-web-browser';
import { Ionicons } from '@expo/vector-icons';
import { Screen, TopBar, Card, GradientButton, GhostButton, AppIcon, ProBadge } from '../../src/components/ui';
import { useAuth } from '../../src/auth';
import { useI18n } from '../../src/i18n';
import { api } from '../../src/api';
import { showApiError } from '../../src/actions';
import { colors, font, gradients } from '../../src/theme';

const STEPS = { installing: 1, configuring: 2, queued: 3, building: 4, done: 5 };
const STATUS_LABEL = {
  installing: 'Installation des dépendances', configuring: 'Configuration', queued: 'En file d’attente',
  building: 'Compilation de l’APK', done: 'Terminé', failed: 'Échec',
};
const ACTIVE = ['installing', 'configuring', 'queued', 'building'];

export default function Export() {
  const { id } = useLocalSearchParams();
  const { fullAccess } = useAuth();
  const { t } = useI18n();
  const [project, setProject] = useState(null);
  const [mode, setMode] = useState('apk');
  const [exportsList, setExportsList] = useState([]);
  const [busy, setBusy] = useState(false);
  const timer = useRef(null);

  const loadExports = useCallback(async () => {
    try {
      const r = await api.exports(String(id));
      setExportsList(r.exports);
      return r.exports;
    } catch { return []; }
  }, [id]);

  useEffect(() => {
    api.project(String(id)).then((r) => setProject(r.project)).catch((e) => Alert.alert(t('common.error'), e.message));
    loadExports();
    return () => clearInterval(timer.current);
  }, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Suivi automatique des compilations en cours
  useEffect(() => {
    clearInterval(timer.current);
    if (exportsList.some((e) => ACTIVE.includes(e.status))) {
      timer.current = setInterval(loadExports, 8000);
    }
    return () => clearInterval(timer.current);
  }, [exportsList, loadExports]);

  const start = async () => {
    if (mode === 'apk' && !fullAccess) { router.push('/premium'); return; }
    setBusy(true);
    try {
      await api.startExport(String(id), mode);
      await loadExports();
    } catch (e) { showApiError(e, t); } finally { setBusy(false); }
  };

  const download = async (exp) => {
    try {
      if (exp.buildUrl) { await Linking.openURL(exp.buildUrl); return; }
      const r = await api.downloadLink(exp.id);
      await WebBrowser.openBrowserAsync(r.url);
    } catch (e) { Alert.alert(t('common.error'), e.message); }
  };

  if (!project) return <Screen><TopBar title={t('export.title')} /><ActivityIndicator color={colors.cyan} style={{ marginTop: 40 }} /></Screen>;

  const Option = ({ value, icon, title, text, pro }) => {
    const active = mode === value;
    return (
      <Pressable onPress={() => setMode(value)} style={{ marginBottom: 12 }}>
        <View style={{ borderRadius: 20, borderWidth: 2, borderColor: active ? colors.purple : colors.border, backgroundColor: active ? 'rgba(198,244,50,0.10)' : colors.card, padding: 16, flexDirection: 'row', alignItems: 'center' }}>
          <View style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: 'rgba(198,244,50,0.12)', alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name={icon} size={24} color={colors.cyan} />
          </View>
          <View style={{ flex: 1, marginLeft: 14 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Text style={font.h3}>{title}</Text>
              {pro && <ProBadge small />}
            </View>
            <Text style={[font.small, { marginTop: 3 }]}>{text}</Text>
          </View>
          <Ionicons name={active ? 'radio-button-on' : 'radio-button-off'} size={22} color={active ? colors.purple : colors.faint} />
        </View>
      </Pressable>
    );
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <TopBar title={t('export.title')} subtitle={project.name} />
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        <LinearGradient colors={[project.theme.primary + '55', 'transparent']} style={{ borderRadius: 24, padding: 20, alignItems: 'center', marginBottom: 20, borderWidth: 1, borderColor: colors.border }}>
          <AppIcon icon={project.icon} colorsPair={[project.theme.primary, project.theme.secondary]} size={76} />
          <Text style={[font.h2, { marginTop: 12 }]}>{project.name}</Text>
          <Text style={font.small}>{project.screenCount} {t('common.screens')} · Android</Text>
        </LinearGradient>

        <Option value="apk" icon="logo-android" title={t('export.apk')} text={t('export.apkText')} pro={!fullAccess} />
        <Option value="source" icon="code-slash" title={t('export.source')} text={t('export.sourceText')} />

        <GradientButton
          title={mode === 'apk' && !fullAccess ? t('common.upgrade') : t('export.start')}
          icon={mode === 'apk' && !fullAccess ? 'diamond' : 'rocket'}
          colorsOverride={mode === 'apk' && !fullAccess ? gradients.premium : undefined}
          loading={busy} onPress={start} size="lg" style={{ marginTop: 6 }}
        />

        {exportsList.length > 0 && <Text style={[font.h3, { marginTop: 28, marginBottom: 12 }]}>{t('export.history')}</Text>}
        {exportsList.map((e) => {
          const active = ACTIVE.includes(e.status);
          const step = STEPS[e.status] || 0;
          return (
            <Card key={e.id} style={{ marginBottom: 12 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Ionicons name={e.mode === 'apk' ? 'logo-android' : 'code-slash'} size={22} color={e.status === 'failed' ? colors.danger : e.status === 'done' ? colors.success : colors.cyan} />
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <Text style={{ color: colors.text, fontWeight: '700' }}>{e.mode === 'apk' ? 'APK' : 'Projet Expo'} · {STATUS_LABEL[e.status] || e.status}</Text>
                  <Text style={[font.small, { fontSize: 12 }]}>{new Date(e.createdAt).toLocaleString('fr-FR')}</Text>
                </View>
                {active && <ActivityIndicator color={colors.cyan} />}
              </View>
              {active && (
                <View style={{ flexDirection: 'row', gap: 4, marginTop: 12 }}>
                  {[1, 2, 3, 4].map((s) => (
                    <View key={s} style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: s <= step ? colors.cyan : colors.cardStrong }} />
                  ))}
                </View>
              )}
              {!!e.message && <Text style={[font.small, { marginTop: 10, lineHeight: 19 }]}>{e.message}</Text>}
              {e.status === 'done' && (
                <GhostButton
                  title={e.buildUrl ? 'Télécharger l’APK' : `${t('export.download')} (.zip)`}
                  icon="download-outline" color={colors.cyan} style={{ marginTop: 12 }}
                  onPress={() => download(e)}
                />
              )}
            </Card>
          );
        })}

        <Card style={{ marginTop: 16 }}>
          <Text style={[font.h3, { marginBottom: 10 }]}>📲 Installer l’APK sur Android</Text>
          {[
            'Télécharge le fichier .apk sur ton téléphone.',
            'Ouvre-le depuis tes Téléchargements.',
            'Autorise « Installer des applis inconnues » si Android le demande.',
            'Appuie sur Installer : ton application apparaît sur l’écran d’accueil !',
          ].map((s, i) => (
            <View key={i} style={{ flexDirection: 'row', marginBottom: 8 }}>
              <Text style={{ color: colors.cyan, fontWeight: '800', width: 22 }}>{i + 1}.</Text>
              <Text style={[font.small, { flex: 1, lineHeight: 19 }]}>{s}</Text>
            </View>
          ))}
        </Card>
      </ScrollView>
    </Screen>
  );
}
