import React from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Redirect } from 'expo-router';
import { useAuth } from '../src/auth';
import { Logo } from '../src/components/ui';
import { colors } from '../src/theme';

export default function Index() {
  const { ready, user } = useAuth();
  if (!ready) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', gap: 24 }}>
        <Logo size={84} />
        <ActivityIndicator color={colors.cyan} />
      </View>
    );
  }
  return <Redirect href={user ? '/home' : '/welcome'} />;
}
