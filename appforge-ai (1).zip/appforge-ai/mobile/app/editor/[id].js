import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, BackHandler, KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, View, useWindowDimensions,
} from 'react-native';
import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import AppRuntime from '../../src/runtime/AppRuntime';
import { Screen, TopBar, IconButton, GradientButton, GhostButton } from '../../src/components/ui';
import { PropEditor, ComponentPalette, Label, TextBox, ColorBox, IconPicker } from '../../src/components/editor';
import { COMPONENTS, PALETTES, uid } from '../../src/catalog';
import { useI18n } from '../../src/i18n';
import { api, API_URL } from '../../src/api';
import { showApiError } from '../../src/actions';
import { colors, font, gradients } from '../../src/theme';

const clone = (x) => JSON.parse(JSON.stringify(x));

export default function Editor() {
  const { id } = useLocalSearchParams();
  const { t } = useI18n();
  const { height } = useWindowDimensions();
  const [spec, setSpecState] = useState(null);
  const specRef = useRef(null);
  const setSpec = (next) => { specRef.current = next; setSpecState(next); };
  const [savedJson, setSavedJson] = useState('');
  const [history, setHistory] = useState([]);
  const [screenId, setScreenId] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [tab, setTab] = useState('components');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const lastKey = useRef(null);

  const load = useCallback(() => {
    api.project(String(id)).then((r) => {
      setSpec(r.project.spec);
      setSavedJson(JSON.stringify(r.project.spec));
      setScreenId((cur) => (r.project.spec.screens.some((s) => s.id === cur) ? cur : r.project.spec.screens[0].id));
      setHistory([]);
    }).catch((e) => setError(e.message));
  }, [id]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { load(); }, [load]);

  const dirty = spec && JSON.stringify(spec) !== savedJson;
  const screen = useMemo(() => spec && (spec.screens.find((s) => s.id === screenId) || spec.screens[0]), [spec, screenId]);
  const selected = useMemo(() => screen && screen.components.find((c) => c.id === selectedId), [screen, selectedId]);

  /** Applique une modification ; `key` regroupe les frappes successives dans une seule étape d'annulation */
  const update = (mutator, key = null) => {
    const prev = specRef.current;
    const next = clone(prev);
    mutator(next);
    if (!key || key !== lastKey.current) setHistory((h) => [...h.slice(-39), prev]);
    lastKey.current = key;
    setSpec(next);
  };
  const undo = () => {
    if (!history.length) return;
    const prev = history[history.length - 1];
    setHistory((h) => h.slice(0, -1));
    lastKey.current = null;
    setSpec(prev);
    if (!prev.screens.some((s) => s.id === screenId)) setScreenId(prev.screens[0].id);
  };
  const curScreen = (s) => s.screens.find((x) => x.id === screen.id);

  // ---------- Composants
  const addComponent = (type) => {
    const c = { id: uid(), type, props: clone(COMPONENTS[type].defaults) };
    if (type === 'button' && c.props.action === 'navigate') c.props.target = screen.id;
    update((s) => { curScreen(s).components.push(c); });
    setSelectedId(c.id);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
  };
  const setProp = (key, value) => update((s) => {
    const c = curScreen(s).components.find((x) => x.id === selectedId);
    if (c) c.props[key] = value;
  }, `${selectedId}.${key}`);
  const moveSelected = (d) => update((s) => {
    const list = curScreen(s).components;
    const i = list.findIndex((x) => x.id === selectedId);
    const j = i + d;
    if (i < 0 || j < 0 || j >= list.length) return;
    [list[i], list[j]] = [list[j], list[i]];
  });
  const duplicateSelected = () => {
    const nid = uid();
    update((s) => {
      const list = curScreen(s).components;
      const i = list.findIndex((x) => x.id === selectedId);
      if (i >= 0) list.splice(i + 1, 0, { ...clone(list[i]), id: nid });
    });
    setSelectedId(nid);
  };
  const removeSelected = () => {
    update((s) => { const sc = curScreen(s); sc.components = sc.components.filter((x) => x.id !== selectedId); });
    setSelectedId(null);
  };

  // ---------- Écrans
  const addScreen = () => {
    if (spec.screens.length >= 8) { Alert.alert('Maximum atteint', '8 écrans maximum par application.'); return; }
    const sid = uid();
    update((s) => { s.screens.push({ id: sid, title: 'Nouvel écran', icon: 'document-text', components: [{ id: uid(), type: 'header', props: { title: 'Nouvel écran', subtitle: '' } }] }); });
    setScreenId(sid);
    setSelectedId(null);
  };
  const setScreenField = (sid, key, value) => update((s) => { s.screens.find((x) => x.id === sid)[key] = value; }, `screen.${sid}.${key}`);
  const moveScreen = (sid, d) => update((s) => {
    const i = s.screens.findIndex((x) => x.id === sid);
    const j = i + d;
    if (j < 0 || j >= s.screens.length) return;
    [s.screens[i], s.screens[j]] = [s.screens[j], s.screens[i]];
  });
  const deleteScreen = (sid) => {
    if (spec.screens.length <= 1) return;
    Alert.alert(t('common.delete'), 'Supprimer cet écran et son contenu ?', [
      { text: t('common.cancel'), style: 'cancel' },
      {
        text: t('common.delete'), style: 'destructive', onPress: () => {
          update((s) => { s.screens = s.screens.filter((x) => x.id !== sid); });
          if (screenId === sid) setScreenId(spec.screens.find((x) => x.id !== sid).id);
        },
      },
    ]);
  };

  // ---------- Sauvegarde
  const save = async () => {
    setSaving(true);
    try {
      const r = await api.saveProject(String(id), spec);
      setSpec(r.project.spec);
      setSavedJson(JSON.stringify(r.project.spec));
      lastKey.current = null;
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      return true;
    } catch (e) {
      showApiError(e, t);
      return false;
    } finally { setSaving(false); }
  };

  const confirmLeave = useCallback((go) => {
    if (!dirty) { go(); return true; }
    Alert.alert(t('editor.unsaved'), t('editor.leave'), [
      { text: t('common.cancel'), style: 'cancel' },
      { text: 'Quitter', style: 'destructive', onPress: go },
      { text: t('common.save'), onPress: async () => { if (await save()) go(); } },
    ]);
    return true;
  }, [dirty, spec]); // eslint-disable-line react-hooks/exhaustive-deps

  useFocusEffect(useCallback(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => confirmLeave(() => router.back()));
    return () => sub.remove();
  }, [confirmLeave]));

  const goWithSave = async (href) => {
    if (dirty && !(await save())) return;
    router.push(href);
  };

  if (error) {
    return (
      <Screen>
        <TopBar title="Éditeur" />
        <View style={{ padding: 24 }}>
          <Text style={{ color: colors.danger, marginBottom: 14 }}>{error}</Text>
          <GhostButton title={t('common.retry')} onPress={() => { setError(''); load(); }} />
        </View>
      </Screen>
    );
  }
  if (!spec || !screen) {
    return <Screen><ActivityIndicator color={colors.cyan} style={{ marginTop: 80 }} /></Screen>;
  }

  const previewHeight = Math.round(height * 0.42);

  return (
    <Screen edges={['top', 'bottom']}>
      <TopBar
        title={spec.name}
        subtitle={dirty ? `● ${t('editor.unsaved')}` : `✓ ${t('common.saved')}`}
        onBack={() => confirmLeave(() => router.back())}
        right={(
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <IconButton icon="arrow-undo" onPress={undo} color={history.length ? colors.text : colors.faint} />
            <IconButton icon="play" onPress={() => goWithSave(`/preview/${id}`)} color={colors.cyan} />
            <Pressable onPress={save} disabled={!dirty || saving}>
              <LinearGradient colors={dirty ? gradients.brand : ['#26262B', '#26262B']} style={{ height: 40, paddingHorizontal: 14, borderRadius: 12, alignItems: 'center', justifyContent: 'center', flexDirection: 'row' }}>
                {saving ? <ActivityIndicator color={colors.onAccent} size="small" /> : <Ionicons name="save" size={18} color={dirty ? colors.onAccent : colors.faint} />}
              </LinearGradient>
            </Pressable>
          </View>
        )}
      />

      {/* Aperçu modifiable dans un cadre de téléphone */}
      <View style={{ height: previewHeight, marginHorizontal: 16, borderRadius: 26, borderWidth: 2, borderColor: 'rgba(198,244,50,0.45)', overflow: 'hidden', backgroundColor: spec.theme.background }}>
        <AppRuntime spec={spec} apiUrl={API_URL} projectId={String(id)} screenId={screen.id} onScreenChange={(sid) => { setScreenId(sid); setSelectedId(null); }} selectedId={selectedId} onSelect={(cid) => { setSelectedId(cid); setTab('components'); }} />
      </View>

      {/* Onglets */}
      <View style={{ flexDirection: 'row', marginHorizontal: 16, marginTop: 12, backgroundColor: colors.card, borderRadius: 14, padding: 4, borderWidth: 1, borderColor: colors.border }}>
        {[['components', 'cube', t('editor.components')], ['screens', 'layers', t('editor.screens')], ['theme', 'color-palette', t('editor.theme')]].map(([k, icon, label]) => (
          <Pressable key={k} onPress={() => setTab(k)} style={{ flex: 1 }}>
            {tab === k ? (
              <LinearGradient colors={gradients.brand} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ paddingVertical: 9, borderRadius: 10, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                <Ionicons name={icon} size={15} color={colors.onAccent} />
                <Text style={{ color: colors.onAccent, fontWeight: '800', marginLeft: 6, fontSize: 13 }}>{label}</Text>
              </LinearGradient>
            ) : (
              <View style={{ paddingVertical: 9, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                <Ionicons name={icon} size={15} color={colors.muted} />
                <Text style={{ color: colors.muted, fontWeight: '700', marginLeft: 6, fontSize: 13 }}>{label}</Text>
              </View>
            )}
          </Pressable>
        ))}
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
          {tab === 'components' && (selected ? (
            <View>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 14 }}>
                <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: 'rgba(198,244,50,0.15)', alignItems: 'center', justifyContent: 'center' }}>
                  <Ionicons name={COMPONENTS[selected.type].icon} size={18} color={colors.cyan} />
                </View>
                <Text style={[font.h3, { flex: 1, marginLeft: 10 }]}>{COMPONENTS[selected.type].label}</Text>
                <IconButton icon="arrow-up" size={16} onPress={() => moveSelected(-1)} style={{ width: 34, height: 34, marginLeft: 4 }} />
                <IconButton icon="arrow-down" size={16} onPress={() => moveSelected(1)} style={{ width: 34, height: 34, marginLeft: 4 }} />
                <IconButton icon="copy-outline" size={16} onPress={duplicateSelected} style={{ width: 34, height: 34, marginLeft: 4 }} />
                <IconButton icon="trash-outline" size={16} color={colors.danger} onPress={removeSelected} style={{ width: 34, height: 34, marginLeft: 4 }} />
              </View>
              <PropEditor component={selected} screens={spec.screens} onChange={setProp} />
              <GhostButton title="Terminé" icon="checkmark" onPress={() => setSelectedId(null)} style={{ marginTop: 6 }} />
            </View>
          ) : (
            <View>
              <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(198,244,50,0.08)', borderRadius: 12, padding: 12, marginBottom: 16 }}>
                <Ionicons name="hand-left-outline" size={18} color={colors.cyan} />
                <Text style={{ color: colors.muted, marginLeft: 10, flex: 1, fontSize: 13 }}>{t('editor.tapHint')}</Text>
              </View>
              <Text style={[font.h3, { marginBottom: 12 }]}>{t('editor.add')}</Text>
              <ComponentPalette onAdd={addComponent} />
              <GradientButton title={t('editor.askAi')} icon="sparkles" onPress={() => goWithSave(`/chat?projectId=${id}`)} style={{ marginTop: 8 }} />
            </View>
          ))}

          {tab === 'screens' && (
            <View>
              {spec.screens.map((sc, i) => (
                <View key={sc.id} style={{ backgroundColor: sc.id === screen.id ? 'rgba(198,244,50,0.12)' : colors.card, borderRadius: 16, borderWidth: 1, borderColor: sc.id === screen.id ? colors.purple : colors.border, padding: 12, marginBottom: 10 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
                    <Pressable onPress={() => { setScreenId(sc.id); setSelectedId(null); }} style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                      <Ionicons name={sc.icon} size={18} color={colors.cyan} />
                      <Text style={{ color: colors.text, fontWeight: '700', marginLeft: 8 }}>Écran {i + 1} · {sc.components.length} éléments</Text>
                    </Pressable>
                    <IconButton icon="arrow-up" size={15} onPress={() => moveScreen(sc.id, -1)} style={{ width: 32, height: 32, marginLeft: 4 }} />
                    <IconButton icon="arrow-down" size={15} onPress={() => moveScreen(sc.id, 1)} style={{ width: 32, height: 32, marginLeft: 4 }} />
                    {spec.screens.length > 1 && <IconButton icon="trash-outline" size={15} color={colors.danger} onPress={() => deleteScreen(sc.id)} style={{ width: 32, height: 32, marginLeft: 4 }} />}
                  </View>
                  <TextBox value={sc.title} onChange={(v) => setScreenField(sc.id, 'title', v)} />
                  <View style={{ marginTop: 8 }}><IconPicker value={sc.icon} onChange={(v) => setScreenField(sc.id, 'icon', v)} /></View>
                </View>
              ))}
              <GhostButton title={t('editor.addScreen')} icon="add" onPress={addScreen} />
            </View>
          )}

          {tab === 'theme' && (
            <View>
              <Label>{t('editor.appName')}</Label>
              <TextBox value={spec.name} onChange={(v) => update((s) => { s.name = v; }, 'name')} />
              <View style={{ height: 12 }} />
              <Label>{t('editor.description')}</Label>
              <TextBox value={spec.description} multiline onChange={(v) => update((s) => { s.description = v; }, 'description')} />
              <View style={{ height: 12 }} />
              <Label>Icône de l'application</Label>
              <IconPicker value={spec.icon} onChange={(v) => update((s) => { s.icon = v; })} />

              <Text style={[font.h3, { marginTop: 22, marginBottom: 12 }]}>{t('editor.palette')}</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
                {PALETTES.map((pal) => (
                  <Pressable key={pal.name} onPress={() => update((s) => { const { name, ...rest } = pal; s.theme = rest; })} style={{ alignItems: 'center' }}>
                    <View style={{ width: 64, height: 64, borderRadius: 18, overflow: 'hidden', borderWidth: 2, borderColor: spec.theme.primary === pal.primary && spec.theme.background === pal.background ? colors.cyan : colors.border, backgroundColor: pal.background, padding: 8, justifyContent: 'flex-end' }}>
                      <LinearGradient colors={[pal.primary, pal.secondary]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ height: 16, borderRadius: 6 }} />
                    </View>
                    <Text style={{ color: colors.muted, fontSize: 11, marginTop: 6 }}>{pal.name}</Text>
                  </Pressable>
                ))}
              </ScrollView>

              <Text style={[font.h3, { marginTop: 22, marginBottom: 12 }]}>Couleurs personnalisées</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
                {[['primary', 'Principale'], ['secondary', 'Secondaire'], ['background', 'Fond'], ['surface', 'Cartes'], ['text', 'Texte']].map(([k, l]) => (
                  <ColorBox key={k} label={l} value={spec.theme[k]} onChange={(v) => update((s) => { s.theme[k] = v; }, `theme.${k}`)} />
                ))}
              </View>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}
