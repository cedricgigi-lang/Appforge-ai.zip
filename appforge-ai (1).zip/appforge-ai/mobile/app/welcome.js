import React, { useEffect, useRef } from 'react';
import { Animated, ScrollView, Text, View } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Logo, GradientButton, GhostButton } from '../src/components/ui';
import { useI18n } from '../src/i18n';
import { colors, font } from '../src/theme';

function FloatingLogo() {
  const float = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.loop(Animated.sequence([
      Animated.timing(float, { toValue: 1, duration: 2200, useNativeDriver: true }),
      Animated.timing(float, { toValue: 0, duration: 2200, useNativeDriver: true }),
    ])).start();
  }, [float]);
  const translateY = float.interpolate({ inputRange: [0, 1], outputRange: [0, -12] });
  const rotate = float.interpolate({ inputRange: [0, 1], outputRange: ['-4deg', '4deg'] });
  return (
    <View style={{ alignItems: 'center', marginTop: 30, marginBottom: 34 }}>
      <View style={{ position: 'absolute', top: 40, width: 220, height: 220, borderRadius: 110, backgroundColor: 'rgba(198,244,50,0.12)' }} />
      <Animated.View style={{ transform: [{ translateY }, { rotate }] }}>
        <Logo size={150} />
      </Animated.View>
    </View>
  );
}

export default function Welcome() {
  const { t } = useI18n();
  const features = [['flash', t('welcome.f1')], ['cube', t('welcome.f2')], ['logo-android', t('welcome.f3')]];
  return (
    <Screen edges={['top', 'bottom']}>
      <ScrollView contentContainerStyle={{ padding: 24, flexGrow: 1 }}>
        <Text style={{ color: colors.text, fontSize: 26, fontWeight: '900', letterSpacing: -1 }}>
          kubo<Text style={{ color: colors.accent }}>.</Text>
        </Text>
        <FloatingLogo />
        <Text style={[font.h1, { fontSize: 40, lineHeight: 44 }]}>
          Ton idée.{'\n'}Ton app.{'\n'}<Text style={{ color: colors.accent }}>En quelques secondes.</Text>
        </Text>
        <Text style={[font.body, { color: colors.muted, marginTop: 14 }]}>{t('welcome.subtitle')}</Text>
        <View style={{ marginVertical: 26, gap: 10 }}>
          {features.map(([icon, label]) => (
            <View key={icon} style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: colors.accentSoft, alignItems: 'center', justifyContent: 'center', marginRight: 12 }}>
                <Ionicons name={icon} size={17} color={colors.accent} />
              </View>
              <Text style={[font.body, { fontWeight: '600' }]}>{label}</Text>
            </View>
          ))}
        </View>
        <View style={{ flex: 1 }} />
        <GradientButton title={t('welcome.start')} icon="arrow-forward" size="lg" onPress={() => router.push('/register')} />
        <GhostButton title={t('welcome.login')} onPress={() => router.push('/login')} style={{ marginTop: 12 }} />
      </ScrollView>
    </Screen>
  );
}
