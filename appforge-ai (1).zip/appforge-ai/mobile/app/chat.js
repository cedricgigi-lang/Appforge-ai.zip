import React, { useEffect, useRef, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Screen, TopBar, Logo, AppIcon, TypingDots } from '../src/components/ui';
import { useI18n } from '../src/i18n';
import { useAuth } from '../src/auth';
import { api } from '../src/api';
import { colors, font, gradients } from '../src/theme';

function Bubble({ msg, t }) {
  const mine = msg.role === 'user';
  if (mine) {
    return (
      <View style={{ alignSelf: 'flex-end', maxWidth: '85%', marginBottom: 12 }}>
        <LinearGradient colors={gradients.brand} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ borderRadius: 20, borderBottomRightRadius: 6, padding: 14 }}>
          <Text style={{ color: colors.onAccent, fontSize: 15, lineHeight: 21, fontWeight: '500' }}>{msg.text}</Text>
        </LinearGradient>
      </View>
    );
  }
  const p = msg.project;
  return (
    <View style={{ flexDirection: 'row', marginBottom: 14, maxWidth: '92%' }}>
      <Logo size={30} />
      <View style={{ marginLeft: 10, flex: 1 }}>
        <View style={{ backgroundColor: msg.error ? 'rgba(244,63,94,0.12)' : colors.cardStrong, borderRadius: 20, borderTopLeftRadius: 6, padding: 14, borderWidth: 1, borderColor: msg.error ? 'rgba(244,63,94,0.35)' : colors.border }}>
          <Text style={{ color: msg.error ? '#FDA4AF' : colors.text, fontSize: 15, lineHeight: 22 }}>{msg.text}</Text>
          {msg.action && (
            <Pressable onPress={msg.action.onPress} style={{ marginTop: 10 }}>
              <Text style={{ color: colors.gold, fontWeight: '800' }}>{msg.action.label} →</Text>
            </Pressable>
          )}
        </View>
        {p && (
          <View style={{ marginTop: 10, backgroundColor: colors.card, borderRadius: 20, borderWidth: 1, borderColor: 'rgba(198,244,50,0.4)', overflow: 'hidden' }}>
            <LinearGradient colors={[p.theme.primary + '40', 'transparent']} style={{ padding: 14, flexDirection: 'row', alignItems: 'center' }}>
              <AppIcon icon={p.icon} colorsPair={[p.theme.primary, p.theme.secondary]} size={46} />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={{ color: colors.cyan, fontSize: 11, fontWeight: '800', letterSpacing: 0.8 }}>{(msg.created ? t('chat.created') : t('chat.updated')).toUpperCase()}</Text>
                <Text style={font.h3} numberOfLines={1}>{p.name}</Text>
                <Text style={font.small}>{p.screenCount} {t('common.screens')}</Text>
              </View>
            </LinearGradient>
            <View style={{ flexDirection: 'row', borderTopWidth: 1, borderTopColor: colors.border }}>
              {[
                ['play', t('common.preview'), `/preview/${p.id}`],
                ['color-wand', t('common.edit'), `/editor/${p.id}`],
                ['logo-android', 'APK', `/export/${p.id}`],
              ].map(([icon, label, href], i) => (
                <Pressable key={label} onPress={() => router.push(href)} style={({ pressed }) => ({ flex: 1, paddingVertical: 12, alignItems: 'center', flexDirection: 'row', justifyContent: 'center', borderLeftWidth: i ? 1 : 0, borderLeftColor: colors.border, backgroundColor: pressed ? colors.cardStrong : 'transparent' })}>
                  <Ionicons name={icon} size={16} color={colors.cyan} />
                  <Text style={{ color: colors.text, fontWeight: '700', marginLeft: 6, fontSize: 13 }}>{label}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        )}
      </View>
    </View>
  );
}

export default function Chat() {
  const { t } = useI18n();
  const { refresh } = useAuth();
  const params = useLocalSearchParams();
  const [projectId, setProjectId] = useState(params.projectId ? String(params.projectId) : null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  // Idée choisie depuis l'accueil : envoyée automatiquement
  useEffect(() => {
    if (params.prompt && !params.projectId) {
      const timer = setTimeout(() => send(String(params.prompt)), 400);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (params.projectId) {
      api.project(String(params.projectId))
        .then((r) => setMessages([{ id: 'w', role: 'assistant', text: t('chat.welcomeEdit', { name: r.project.name }) }]))
        .catch(() => setMessages([{ id: 'w', role: 'assistant', text: t('chat.welcome') }]));
    } else {
      setMessages([{ id: 'w', role: 'assistant', text: t('chat.welcome') }]);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const send = async (text) => {
    const prompt = (text || input).trim();
    if (!prompt || loading) return;
    setInput('');
    setMessages((m) => [...m, { id: `u${Date.now()}`, role: 'user', text: prompt }]);
    setLoading(true);
    try {
      const r = await api.generate(prompt, projectId);
      setProjectId(r.project.id);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      setMessages((m) => [...m, { id: `a${Date.now()}`, role: 'assistant', text: r.reply, project: r.project, created: r.created }]);
      refresh().catch(() => {});
    } catch (e) {
      setMessages((m) => [...m, {
        id: `e${Date.now()}`, role: 'assistant', error: true, text: e.message,
        action: e.status === 402 ? { label: t('common.upgrade'), onPress: () => router.push('/premium') } : null,
      }]);
    } finally {
      setLoading(false);
    }
  };

  const suggestions = ['chat.s6', 'chat.s1', 'chat.s2', 'chat.s3', 'chat.s4', 'chat.s5'].map((k) => t(k));
  const showSuggestions = !projectId && messages.length <= 1;

  return (
    <Screen edges={['top', 'bottom']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <TopBar
          title={t('chat.title')}
          subtitle={projectId ? 'Mode modification' : 'Nouvelle application'}
          right={projectId ? (
            <Pressable onPress={() => { setProjectId(null); setMessages([{ id: `w${Date.now()}`, role: 'assistant', text: t('chat.welcome') }]); }} style={{ padding: 8 }}>
              <Ionicons name="add-circle-outline" size={26} color={colors.cyan} />
            </Pressable>
          ) : null}
        />
        <ScrollView ref={scrollRef} contentContainerStyle={{ padding: 16, paddingBottom: 24 }}
          onContentSizeChange={() => scrollRef.current && scrollRef.current.scrollToEnd({ animated: true })}
          keyboardShouldPersistTaps="handled">
          {messages.map((m) => <Bubble key={m.id} msg={m} t={t} />)}
          {loading && (
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
              <Logo size={30} />
              <View style={{ marginLeft: 10, backgroundColor: colors.cardStrong, borderRadius: 20, borderTopLeftRadius: 6, paddingHorizontal: 16, paddingVertical: 14, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Text style={{ color: colors.muted }}>{t('chat.thinking')}</Text>
                <TypingDots />
              </View>
            </View>
          )}
          {showSuggestions && (
            <View style={{ marginTop: 8 }}>
              <Text style={[font.small, { marginBottom: 10, fontWeight: '700' }]}>💡 Idées pour commencer</Text>
              {suggestions.map((s) => (
                <Pressable key={s} onPress={() => send(s)} style={({ pressed }) => ({ backgroundColor: pressed ? colors.cardStrong : colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: 16, padding: 14, marginBottom: 8, flexDirection: 'row', alignItems: 'center' })}>
                  <Ionicons name="sparkles-outline" size={16} color={colors.purple} />
                  <Text style={{ color: colors.text, marginLeft: 10, flex: 1 }}>{s}</Text>
                </Pressable>
              ))}
            </View>
          )}
        </ScrollView>

        <View style={{ flexDirection: 'row', alignItems: 'flex-end', padding: 12, borderTopWidth: 1, borderTopColor: colors.border, backgroundColor: colors.bgAlt }}>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder={projectId ? 'Ex : ajoute un écran Contact…' : t('chat.placeholder')}
            placeholderTextColor={colors.faint}
            multiline
            maxLength={2000}
            style={{ flex: 1, color: colors.text, fontSize: 15, maxHeight: 120, backgroundColor: colors.card, borderRadius: 20, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 16, paddingTop: 12, paddingBottom: 12 }}
          />
          <Pressable onPress={() => send()} disabled={!input.trim() || loading} style={{ marginLeft: 10, opacity: !input.trim() || loading ? 0.5 : 1 }}>
            <LinearGradient colors={gradients.brand} style={{ width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="arrow-up" size={24} color={colors.onAccent} />
            </LinearGradient>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Screen>
  );
}
