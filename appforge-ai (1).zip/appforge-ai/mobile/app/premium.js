import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import * as WebBrowser from 'expo-web-browser';
import { Ionicons } from '@expo/vector-icons';
import { Screen, GradientButton, Card } from '../src/components/ui';
import { useAuth } from '../src/auth';
import { useI18n } from '../src/i18n';
import { api } from '../src/api';
import { colors, font, gradients } from '../src/theme';

const PERKS = [
  ['infinite', 'Projets illimités'],
  ['flash', 'Générations IA illimitées'],
  ['logo-android', 'Export APK Android en un clic'],
  ['color-palette', 'Modèles et thèmes exclusifs'],
  ['headset', 'Support prioritaire'],
];

export default function Premium() {
  const { isPremium, setUser, refresh, user } = useAuth();
  const { t } = useI18n();
  const [plans, setPlans] = useState(null);
  const [selected, setSelected] = useState('yearly');
  const [busy, setBusy] = useState(false);

  useEffect(() => { api.plans().then(setPlans).catch((e) => Alert.alert(t('common.error'), e.message)); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const subscribe = async () => {
    setBusy(true);
    try {
      const r = await api.checkout(selected);
      if (r.url) {
        await WebBrowser.openBrowserAsync(r.url);
        const me = await refresh();
        if (me.user.plan === 'premium') router.back();
      } else if (r.devMode) {
        Alert.alert(t('premium.devTitle'), t('premium.devText'), [
          { text: t('common.cancel'), style: 'cancel' },
          {
            text: t('premium.activate'),
            onPress: async () => {
              const x = await api.devActivate(selected);
              setUser(x.user);
              refresh().catch(() => {});
              router.back();
            },
          },
        ]);
      }
    } catch (e) {
      Alert.alert(t('common.error'), e.message);
    } finally { setBusy(false); }
  };

  const paid = plans ? plans.plans.filter((p) => p.id !== 'free') : [];

  return (
    <Screen edges={['top', 'bottom']}>
      <View style={{ flexDirection: 'row', justifyContent: 'flex-end', padding: 12 }}>
        <Pressable onPress={() => router.back()} hitSlop={10} style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: colors.card, alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="close" size={22} color={colors.text} />
        </Pressable>
      </View>
      <ScrollView contentContainerStyle={{ padding: 22, paddingTop: 0, paddingBottom: 40 }}>
        <View style={{ alignItems: 'center' }}>
          <LinearGradient colors={gradients.premium} style={{ width: 84, height: 84, borderRadius: 26, alignItems: 'center', justifyContent: 'center', shadowColor: '#EC4899', shadowOpacity: 0.6, shadowRadius: 24, elevation: 12 }}>
            <Ionicons name="flash" size={42} color={colors.onAccent} />
          </LinearGradient>
          <Text style={[font.h1, { marginTop: 18, textAlign: 'center' }]}>{t('premium.title')}</Text>
          <Text style={[font.body, { color: colors.muted, textAlign: 'center', marginTop: 6 }]}>{t('premium.subtitle')}</Text>
        </View>

        <Card style={{ marginTop: 24 }}>
          {PERKS.map(([icon, label]) => (
            <View key={label} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 8 }}>
              <View style={{ width: 32, height: 32, borderRadius: 10, backgroundColor: 'rgba(198,244,50,0.14)', alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name={icon} size={17} color={colors.gold} />
              </View>
              <Text style={[font.body, { marginLeft: 12, fontWeight: '600' }]}>{label}</Text>
            </View>
          ))}
        </Card>

        {isPremium ? (
          <Card style={{ marginTop: 20, alignItems: 'center', borderColor: 'rgba(34,197,94,0.4)' }}>
            <Ionicons name="checkmark-circle" size={40} color={colors.success} />
            <Text style={[font.h2, { marginTop: 8 }]}>{t('premium.active')}</Text>
            {user && user.premiumUntil && <Text style={font.small}>Jusqu’au {new Date(user.premiumUntil).toLocaleDateString('fr-FR')}</Text>}
          </Card>
        ) : !plans ? <ActivityIndicator color={colors.cyan} style={{ marginTop: 30 }} /> : (
          <>
            <View style={{ gap: 12, marginTop: 20 }}>
              {paid.map((p) => {
                const active = selected === p.id;
                return (
                  <Pressable key={p.id} onPress={() => setSelected(p.id)}>
                    <View style={{ borderRadius: 20, borderWidth: 2, borderColor: active ? colors.gold : colors.border, backgroundColor: active ? 'rgba(198,244,50,0.08)' : colors.card, padding: 18, flexDirection: 'row', alignItems: 'center' }}>
                      <Ionicons name={active ? 'radio-button-on' : 'radio-button-off'} size={22} color={active ? colors.gold : colors.faint} />
                      <View style={{ flex: 1, marginLeft: 12 }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                          <Text style={font.h3}>{p.interval === 'year' ? t('premium.yearly') : t('premium.monthly')}</Text>
                          {p.badge && <View style={{ backgroundColor: colors.success, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 }}><Text style={{ color: '#fff', fontSize: 11, fontWeight: '800' }}>{p.badge}</Text></View>}
                        </View>
                        {p.interval === 'year' && <Text style={font.small}>soit {(p.price / 12).toFixed(2).replace('.', ',')} $ / mois</Text>}
                      </View>
                      <Text style={{ color: colors.text, fontSize: 20, fontWeight: '900' }}>{String(p.price).replace('.', ',')} $<Text style={{ fontSize: 13, color: colors.muted }}>/{p.interval === 'year' ? 'an' : 'mois'}</Text></Text>
                    </View>
                  </Pressable>
                );
              })}
            </View>
            <GradientButton title={t('premium.subscribe')} icon="diamond" size="lg" colorsOverride={gradients.premium} loading={busy} onPress={subscribe} style={{ marginTop: 20 }} />
            <Text style={[font.small, { textAlign: 'center', marginTop: 12, fontSize: 12 }]}>
              {plans.paymentsEnabled ? 'Paiement sécurisé par Stripe. Résiliable à tout moment.' : 'Mode test : paiements non configurés sur ce serveur.'}
            </Text>
          </>
        )}
      </ScrollView>
    </Screen>
  );
}
