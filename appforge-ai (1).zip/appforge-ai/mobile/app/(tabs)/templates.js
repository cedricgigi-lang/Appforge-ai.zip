import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, ScrollView, Text, View } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Chip, Card, AppIcon, GradientButton, GhostButton } from '../../src/components/ui';
import { useI18n } from '../../src/i18n';
import { useAuth } from '../../src/auth';
import { api } from '../../src/api';
import { createFromTemplate } from '../../src/actions';
import { colors, font, CATEGORY_META } from '../../src/theme';

const CATS = ['all', 'custom', 'education', 'business', 'games', 'social', 'productivity'];

export default function Templates() {
  const { t } = useI18n();
  const { refresh } = useAuth();
  const [templates, setTemplates] = useState(null);
  const [cat, setCat] = useState('all');
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState('');

  const load = () => api.templates().then((r) => { setTemplates(r.templates); setError(''); }).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  const list = useMemo(() => (templates || []).filter((x) => cat === 'all' || x.category === cat), [templates, cat]);

  return (
    <Screen>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        <Text style={font.h1}>{t('templates.title')}</Text>
        <Text style={[font.body, { color: colors.muted, marginTop: 4 }]}>{t('templates.subtitle')}</Text>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -20, marginVertical: 18 }} contentContainerStyle={{ paddingHorizontal: 20, gap: 8 }}>
          {CATS.map((c) => (
            <Chip key={c} label={t(`cat.${c}`)} icon={c === 'all' ? 'apps' : CATEGORY_META[c].icon} active={cat === c} onPress={() => setCat(c)} />
          ))}
        </ScrollView>

        {!templates && !error && <ActivityIndicator color={colors.cyan} style={{ marginTop: 30 }} />}
        {!!error && (
          <Card><Text style={{ color: colors.danger, marginBottom: 12 }}>{error}</Text><GhostButton title={t('common.retry')} onPress={load} /></Card>
        )}

        {list.map((tp) => (
          <Card key={tp.id} style={{ marginBottom: 14, padding: 0, overflow: 'hidden' }}>
            <LinearGradient colors={[tp.spec.theme.primary + '66', tp.spec.theme.background]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ padding: 18, flexDirection: 'row', alignItems: 'center' }}>
              <AppIcon icon={tp.spec.icon} colorsPair={[tp.spec.theme.primary, tp.spec.theme.secondary]} size={58} />
              <View style={{ flex: 1, marginLeft: 14 }}>
                <Text style={font.h3}>{tp.title}</Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 4 }}>
                  <Ionicons name={CATEGORY_META[tp.category].icon} size={13} color={colors.cyan} />
                  <Text style={[font.small, { marginLeft: 5 }]}>{t(`cat.${tp.category}`)} · {tp.screenCount} {t('common.screens')}</Text>
                </View>
              </View>
            </LinearGradient>
            <View style={{ padding: 16 }}>
              <Text style={[font.body, { color: colors.muted }]}>{tp.summary}</Text>
              <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
                <GhostButton title={t('common.preview')} icon="eye-outline" style={{ flex: 1 }} onPress={() => router.push(`/preview/tpl:${tp.id}`)} />
                <GradientButton title={t('templates.use')} style={{ flex: 1.4 }} loading={busy === tp.id}
                  onPress={async () => { setBusy(tp.id); await createFromTemplate(tp.id, t, refresh); setBusy(null); }} />
              </View>
            </View>
          </Card>
        ))}
      </ScrollView>
    </Screen>
  );
}
