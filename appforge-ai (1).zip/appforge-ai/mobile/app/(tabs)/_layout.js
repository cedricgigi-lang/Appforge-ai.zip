import React from 'react';
import { View } from 'react-native';
import { Redirect, Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../src/auth';
import { useI18n } from '../../src/i18n';
import { colors } from '../../src/theme';

export default function TabsLayout() {
  const { user, ready } = useAuth();
  const { t } = useI18n();
  const insets = useSafeAreaInsets();
  if (ready && !user) return <Redirect href="/welcome" />;

  const icon = (name) => ({ color, focused }) => (
    <View style={{ alignItems: 'center' }}>
      <Ionicons name={focused ? name : `${name}-outline`} size={23} color={color} />
      {focused && <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: colors.accent, marginTop: 3 }} />}
    </View>
  );

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.faint,
        tabBarShowLabel: true,
        tabBarLabelStyle: { fontSize: 11, fontWeight: '700' },
        tabBarStyle: {
          backgroundColor: colors.bgAlt,
          borderTopColor: colors.border,
          height: 62 + insets.bottom,
          paddingTop: 6,
          paddingBottom: Math.max(insets.bottom, 8),
        },
        sceneStyle: { backgroundColor: colors.bg },
      }}
    >
      <Tabs.Screen name="home" options={{ title: t('tabs.home'), tabBarIcon: icon('home') }} />
      <Tabs.Screen name="projects" options={{ title: t('tabs.projects'), tabBarIcon: icon('folder') }} />
      <Tabs.Screen name="templates" options={{ title: t('tabs.templates'), tabBarIcon: icon('grid') }} />
      <Tabs.Screen name="profile" options={{ title: t('tabs.profile'), tabBarIcon: icon('person') }} />
    </Tabs>
  );
}
