import React, { useCallback, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Modal, Pressable, RefreshControl, Text, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Card, Field, AppIcon, EmptyState, IconButton } from '../../src/components/ui';
import { useI18n } from '../../src/i18n';
import { useAuth } from '../../src/auth';
import { api } from '../../src/api';
import { showApiError } from '../../src/actions';
import { colors, font } from '../../src/theme';

function timeAgo(ts) {
  const m = Math.round((Date.now() - ts) / 60000);
  if (m < 1) return "à l'instant";
  if (m < 60) return `il y a ${m} min`;
  const h = Math.round(m / 60);
  if (h < 24) return `il y a ${h} h`;
  return `il y a ${Math.round(h / 24)} j`;
}

export default function Projects() {
  const { t } = useI18n();
  const { refresh } = useAuth();
  const [projects, setProjects] = useState(null);
  const [query, setQuery] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    try {
      setError('');
      const r = await api.projects();
      setProjects(r.projects);
    } catch (e) { setError(e.message); setProjects((p) => p || []); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const filtered = useMemo(() => (projects || []).filter((p) => p.name.toLowerCase().includes(query.toLowerCase())), [projects, query]);

  // Feuille d'actions (Android n'affiche que 3 boutons dans une Alert)
  const [menu, setMenu] = useState(null);
  const actions = (p) => setMenu(p);
  const runAction = async (kind) => {
    const p = menu;
    setMenu(null);
    if (!p) return;
    if (kind === 'preview') router.push(`/preview/${p.id}`);
    if (kind === 'export') router.push(`/export/${p.id}`);
    if (kind === 'chat') router.push(`/chat?projectId=${p.id}`);
    if (kind === 'duplicate') {
      try { await api.duplicateProject(p.id); load(); refresh(); } catch (e) { showApiError(e, t); }
    }
    if (kind === 'delete') {
      Alert.alert(t('common.delete'), t('projects.deleteConfirm'), [
        { text: t('common.cancel'), style: 'cancel' },
        { text: t('common.delete'), style: 'destructive', onPress: async () => { await api.deleteProject(p.id).catch(() => {}); load(); refresh(); } },
      ]);
    }
  };

  return (
    <Screen>
      <View style={{ paddingHorizontal: 20, paddingTop: 12 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <Text style={font.h1}>{t('projects.title')}</Text>
          <IconButton icon="add" bg={colors.violet} color="#fff" onPress={() => router.push('/chat')} />
        </View>
        <Field icon="search" placeholder={t('projects.search')} value={query} onChangeText={setQuery} />
        {!!error && <Text style={{ color: colors.danger, marginBottom: 10 }}>{error}</Text>}
      </View>
      {projects === null ? (
        <ActivityIndicator color={colors.cyan} style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(p) => p.id}
          contentContainerStyle={{ padding: 20, paddingTop: 0, paddingBottom: 40 }}
          refreshControl={<RefreshControl refreshing={refreshing} tintColor={colors.cyan} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }} />}
          ListEmptyComponent={<EmptyState icon="folder-open" text={t('projects.empty')} action={t('home.cta')} onAction={() => router.push('/chat')} />}
          renderItem={({ item: p }) => (
            <Card onPress={() => router.push(`/editor/${p.id}`)} style={{ marginBottom: 12 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <AppIcon icon={p.icon} colorsPair={[p.theme.primary, p.theme.secondary]} size={54} />
                <View style={{ flex: 1, marginLeft: 14 }}>
                  <Text style={font.h3} numberOfLines={1}>{p.name}</Text>
                  <Text style={font.small} numberOfLines={1}>{p.description || t(`cat.${p.category}`)}</Text>
                  <Text style={[font.small, { fontSize: 11, color: colors.faint, marginTop: 4 }]}>
                    {p.screenCount} {t('common.screens')} · {timeAgo(p.updatedAt)}
                  </Text>
                </View>
                <Pressable onPress={() => actions(p)} hitSlop={10} style={{ padding: 6 }}>
                  <Ionicons name="ellipsis-vertical" size={20} color={colors.muted} />
                </Pressable>
              </View>
              <View style={{ flexDirection: 'row', gap: 8, marginTop: 14 }}>
                {[
                  ['create-outline', t('common.edit'), `/editor/${p.id}`],
                  ['play-outline', t('common.preview'), `/preview/${p.id}`],
                  ['logo-android', t('common.export'), `/export/${p.id}`],
                ].map(([icon, label, href]) => (
                  <Pressable key={label} onPress={() => router.push(href)}
                    style={({ pressed }) => ({ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 9, borderRadius: 10, backgroundColor: pressed ? colors.cardStrong : 'rgba(255,255,255,0.04)' })}>
                    <Ionicons name={icon} size={16} color={colors.cyan} />
                    <Text style={{ color: colors.text, fontWeight: '600', marginLeft: 6, fontSize: 13 }}>{label}</Text>
                  </Pressable>
                ))}
              </View>
            </Card>
          )}
        />
      )}

      <Modal visible={!!menu} transparent animationType="slide" onRequestClose={() => setMenu(null)}>
        <Pressable style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' }} onPress={() => setMenu(null)}>
          <Pressable style={{ backgroundColor: colors.bgAlt, borderTopLeftRadius: 26, borderTopRightRadius: 26, padding: 20, paddingBottom: 34, borderWidth: 1, borderColor: colors.border }}>
            <View style={{ width: 40, height: 5, borderRadius: 3, backgroundColor: colors.border, alignSelf: 'center', marginBottom: 16 }} />
            {menu && <Text style={[font.h3, { marginBottom: 10 }]} numberOfLines={1}>{menu.name}</Text>}
            {[
              ['preview', 'play-outline', t('common.preview')],
              ['chat', 'sparkles-outline', t('editor.askAi')],
              ['export', 'logo-android', t('common.export')],
              ['duplicate', 'copy-outline', t('common.duplicate')],
              ['delete', 'trash-outline', t('common.delete')],
            ].map(([kind, icon, label]) => (
              <Pressable key={kind} onPress={() => runAction(kind)} style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', paddingVertical: 14, opacity: pressed ? 0.6 : 1 })}>
                <Ionicons name={icon} size={20} color={kind === 'delete' ? colors.danger : colors.cyan} />
                <Text style={{ marginLeft: 14, fontSize: 16, fontWeight: '600', color: kind === 'delete' ? colors.danger : colors.text }}>{label}</Text>
              </Pressable>
            ))}
          </Pressable>
        </Pressable>
      </Modal>
    </Screen>
  );
}
