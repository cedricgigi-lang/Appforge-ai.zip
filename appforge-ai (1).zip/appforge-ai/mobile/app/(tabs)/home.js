import React, { useCallback, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, Text, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Brand, Card, SectionTitle, AppIcon, EmptyState, ProBadge } from '../../src/components/ui';
import { useAuth } from '../../src/auth';
import { useI18n } from '../../src/i18n';
import { api } from '../../src/api';
import { colors, font, radius } from '../../src/theme';

const IDEAS = [
  ['color-palette', 'Studio d’images IA', 'Une app d’outils IA avec un générateur d’images, un chatbot et un moteur de recherche'],
  ['people', 'Réseau de quartier', 'Un réseau communautaire pour mon quartier avec un fil d’actualité, une galerie photos et une FAQ'],
  ['school', 'Quiz pour l’école', 'Une app de quiz pour les élèves avec des cours et un chatbot pour répondre aux questions'],
  ['storefront', 'Ma boutique', 'Une app pour ma boutique avec le catalogue, un formulaire de commande et un chatbot'],
];

export default function Home() {
  const { user, usage, refresh, isPremium, premiumEnabled } = useAuth();
  const { t } = useI18n();
  const [projects, setProjects] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const [p, tp] = await Promise.all([api.projects(), api.templates(), refresh()]);
      setProjects(p.projects);
      setTemplates(tp.templates);
    } catch { /* l'erreur réseau est gérée à l'écran suivant */ }
  }, [refresh]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const firstName = user ? user.name.split(' ')[0] : '';
  const aiLeft = usage && usage.generationLimit !== null ? Math.max(0, usage.generationLimit - usage.generationsToday) : null;

  return (
    <Screen>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 48 }}
        refreshControl={<RefreshControl refreshing={refreshing} tintColor={colors.accent} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }} />}>

        {/* En-tête */}
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Brand size={34} />
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            {premiumEnabled && (isPremium ? <ProBadge /> : (
              <Pressable onPress={() => router.push('/premium')} style={{ backgroundColor: colors.accentSoft, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 99 }}>
                <Text style={{ color: colors.accent, fontWeight: '800', fontSize: 12 }}>PRO</Text>
              </Pressable>
            ))}
            <Pressable onPress={() => router.push('/profile')} style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: colors.cardStrong, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.border }}>
              <Text style={{ color: colors.text, fontWeight: '800', fontSize: 16 }}>{firstName.slice(0, 1).toUpperCase()}</Text>
            </Pressable>
          </View>
        </View>

        {/* Titre */}
        <Text style={[font.small, { marginTop: 28, fontSize: 15 }]}>{t('home.hello')} {firstName} 👋</Text>
        <Text style={[font.h1, { fontSize: 38, lineHeight: 42, marginTop: 6 }]}>
          Construis ton app.{'\n'}<Text style={{ color: colors.accent }}>Sans code.</Text>
        </Text>

        {/* Grand bouton IA */}
        <Pressable onPress={() => router.push('/chat')} style={({ pressed }) => ({ marginTop: 24, transform: [{ scale: pressed ? 0.98 : 1 }] })}>
          <View style={{ backgroundColor: colors.accent, borderRadius: radius.xl, padding: 22, overflow: 'hidden' }}>
            <View style={{ position: 'absolute', right: -50, top: -50, width: 190, height: 190, borderRadius: 95, borderWidth: 28, borderColor: 'rgba(10,10,11,0.07)' }} />
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={{ backgroundColor: colors.onAccent, borderRadius: 99, paddingHorizontal: 10, paddingVertical: 5, flexDirection: 'row', alignItems: 'center' }}>
                <Ionicons name="sparkles" size={12} color={colors.accent} />
                <Text style={{ color: colors.accent, fontWeight: '800', fontSize: 11, marginLeft: 5, letterSpacing: 1 }}>IA GÉNÉRATIVE</Text>
              </View>
            </View>
            <Text style={{ color: colors.onAccent, fontSize: 27, fontWeight: '900', letterSpacing: -0.8, marginTop: 16, lineHeight: 31 }}>
              {t('home.cta')}
            </Text>
            <View style={{ flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 14 }}>
              <Text style={{ color: 'rgba(10,10,11,0.7)', fontSize: 14, flex: 1, marginRight: 12 }}>{t('home.heroText')}</Text>
              <View style={{ width: 54, height: 54, borderRadius: 27, backgroundColor: colors.onAccent, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name="arrow-forward" size={26} color={colors.accent} />
              </View>
            </View>
          </View>
        </Pressable>

        {/* Idées en un toucher */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -20, marginTop: 14 }} contentContainerStyle={{ paddingHorizontal: 20, gap: 8 }}>
          {IDEAS.map(([icon, label, prompt]) => (
            <Pressable key={label} onPress={() => router.push({ pathname: '/chat', params: { prompt } })}
              style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 10, borderRadius: 99, backgroundColor: pressed ? colors.cardStrong : colors.card, borderWidth: 1, borderColor: colors.border })}>
              <Ionicons name={icon} size={15} color={colors.accent} />
              <Text style={{ color: colors.text, fontWeight: '600', marginLeft: 7, fontSize: 13 }}>{label}</Text>
            </Pressable>
          ))}
        </ScrollView>

        {/* Chiffres */}
        <View style={{ flexDirection: 'row', gap: 10, marginTop: 22 }}>
          {[
            [usage ? String(usage.projects) : '–', t('home.statProjects')],
            [aiLeft === null ? '∞' : String(aiLeft), 'IA restantes'],
            ['22', 'Composants'],
          ].map(([value, label]) => (
            <View key={label} style={{ flex: 1, backgroundColor: colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, paddingVertical: 16, paddingHorizontal: 14 }}>
              <Text style={{ color: colors.text, fontSize: 26, fontWeight: '900', letterSpacing: -1 }}>{value}</Text>
              <Text style={[font.small, { fontSize: 12, marginTop: 2 }]} numberOfLines={1}>{label}</Text>
            </View>
          ))}
        </View>

        {/* Modèles */}
        <SectionTitle title={t('home.templates')} action={t('home.seeAll')} onAction={() => router.push('/templates')} />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -20 }} contentContainerStyle={{ paddingHorizontal: 20, gap: 12 }}>
          {templates.map((tp) => (
            <Pressable key={tp.id} onPress={() => router.push(`/preview/tpl:${tp.id}`)}
              style={({ pressed }) => ({ width: 170, height: 180, borderRadius: radius.lg, padding: 16, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, justifyContent: 'space-between', opacity: pressed ? 0.85 : 1 })}>
              <AppIcon icon={tp.spec.icon} colorsPair={[tp.spec.theme.primary, tp.spec.theme.secondary]} size={46} />
              <View>
                <Text style={[font.h3, { fontSize: 15 }]} numberOfLines={1}>{tp.title}</Text>
                <Text style={[font.small, { fontSize: 12, marginTop: 2 }]}>{t(`cat.${tp.category}`)} · {tp.screenCount} {t('common.screens')}</Text>
              </View>
            </Pressable>
          ))}
        </ScrollView>

        {/* Projets récents */}
        <SectionTitle title={t('home.recent')} action={projects.length ? t('home.seeAll') : null} onAction={() => router.push('/projects')} />
        {projects.length === 0 ? (
          <Card><EmptyState text={t('home.empty')} /></Card>
        ) : projects.slice(0, 4).map((p) => (
          <Card key={p.id} onPress={() => router.push(`/editor/${p.id}`)} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10, padding: 14 }}>
            <AppIcon icon={p.icon} colorsPair={[p.theme.primary, p.theme.secondary]} size={50} />
            <View style={{ flex: 1, marginLeft: 14 }}>
              <Text style={font.h3} numberOfLines={1}>{p.name}</Text>
              <Text style={font.small}>{t(`cat.${p.category}`)} · {p.screenCount} {t('common.screens')}</Text>
            </View>
            <Pressable onPress={() => router.push(`/preview/${p.id}`)} hitSlop={8}
              style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: colors.accent, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="play" size={20} color={colors.onAccent} style={{ marginLeft: 2 }} />
            </Pressable>
          </Card>
        ))}

        {premiumEnabled && !isPremium && (
          <Pressable onPress={() => router.push('/premium')} style={{ marginTop: 18 }}>
            <View style={{ borderRadius: radius.lg, padding: 18, flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderColor: colors.accent }}>
              <Ionicons name="flash" size={26} color={colors.accent} />
              <View style={{ flex: 1, marginLeft: 14 }}>
                <Text style={{ color: colors.text, fontWeight: '900', fontSize: 16 }}>{t('common.upgrade')}</Text>
                <Text style={[font.small, { marginTop: 2 }]}>Projets illimités · Export APK · IA illimitée</Text>
              </View>
              <Ionicons name="chevron-forward" size={22} color={colors.accent} />
            </View>
          </Pressable>
        )}
      </ScrollView>
    </Screen>
  );
}
