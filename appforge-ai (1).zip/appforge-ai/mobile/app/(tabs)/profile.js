import React, { useState } from 'react';
import { Alert, Modal, Pressable, ScrollView, Text, View } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import * as WebBrowser from 'expo-web-browser';
import { Ionicons } from '@expo/vector-icons';
import { Screen, Card, Chip, GhostButton, GradientButton, ProBadge, ProgressBar, Field } from '../../src/components/ui';
import { useAuth } from '../../src/auth';
import { useI18n } from '../../src/i18n';
import { api, API_URL } from '../../src/api';
import { colors, font, gradients } from '../../src/theme';

function Row({ icon, label, onPress, danger, right }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', paddingVertical: 14, opacity: pressed ? 0.6 : 1 })}>
      <Ionicons name={icon} size={20} color={danger ? colors.danger : colors.muted} />
      <Text style={{ flex: 1, marginLeft: 14, color: danger ? colors.danger : colors.text, fontSize: 15, fontWeight: '600' }}>{label}</Text>
      {right || <Ionicons name="chevron-forward" size={18} color={colors.faint} />}
    </Pressable>
  );
}

export default function Profile() {
  const { user, usage, logout, isPremium, premiumEnabled, setUser, refresh } = useAuth();
  const { t, lang, setLang } = useI18n();
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);

  if (!user) return null;

  const changeLang = async (l) => {
    setLang(l);
    try { const r = await api.updateMe({ language: l }); setUser(r.user); } catch { /* préférence locale conservée */ }
  };

  const manage = async () => {
    try {
      const r = await api.portal();
      await WebBrowser.openBrowserAsync(r.url);
      refresh();
    } catch (e) {
      // Serveur en mode test : permettre de revenir à la formule gratuite
      Alert.alert(t('profile.manage'), e.message, [
        { text: 'OK' },
        { text: 'Revenir au gratuit (test)', style: 'destructive', onPress: () => api.devCancel().then((x) => setUser(x.user)).catch(() => {}) },
      ]);
    }
  };

  const deleteAccount = async () => {
    setBusy(true);
    try {
      await api.deleteAccount(password);
      setDeleteOpen(false);
      await logout();
      router.replace('/welcome');
    } catch (e) {
      Alert.alert(t('common.error'), e.message);
    } finally { setBusy(false); }
  };

  return (
    <Screen>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        <Text style={font.h1}>{t('profile.title')}</Text>

        <View style={{ alignItems: 'center', marginVertical: 22 }}>
          <LinearGradient colors={gradients.brand} style={{ width: 86, height: 86, borderRadius: 43, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: colors.onAccent, fontSize: 34, fontWeight: '900' }}>{user.name.slice(0, 1).toUpperCase()}</Text>
          </LinearGradient>
          <Text style={[font.h2, { marginTop: 12 }]}>{user.name}</Text>
          <Text style={font.small}>{user.email}</Text>
          <View style={{ marginTop: 10 }}>{!premiumEnabled ? <Chip label="✨ Accès complet gratuit" /> : isPremium ? <ProBadge /> : <Chip label={t('common.free')} />}</View>
        </View>

        <Card style={{ marginBottom: 14 }}>
          <Text style={[font.h3, { marginBottom: 14 }]}>{t('profile.usage')}</Text>
          {usage && (
            <>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
                <Text style={font.small}>{t('home.statProjects')}</Text>
                <Text style={{ color: colors.text, fontWeight: '700' }}>{usage.projects}{usage.projectLimit ? ` / ${usage.projectLimit}` : ` · ${t('home.unlimited')}`}</Text>
              </View>
              <ProgressBar value={usage.projects} max={usage.projectLimit} />
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6, marginTop: 14 }}>
                <Text style={font.small}>{t('home.statAi')} (24 h)</Text>
                <Text style={{ color: colors.text, fontWeight: '700' }}>{usage.generationsToday}{usage.generationLimit ? ` / ${usage.generationLimit}` : ` · ${t('home.unlimited')}`}</Text>
              </View>
              <ProgressBar value={usage.generationsToday} max={usage.generationLimit} />
            </>
          )}
          {premiumEnabled && !isPremium && <GradientButton title={t('common.upgrade')} icon="diamond" colorsOverride={gradients.premium} style={{ marginTop: 18 }} onPress={() => router.push('/premium')} />}
        </Card>

        <Card style={{ marginBottom: 14 }}>
          <Text style={[font.h3, { marginBottom: 12 }]}>{t('profile.language')}</Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Chip label="🇫🇷  Français" active={lang === 'fr'} onPress={() => changeLang('fr')} />
            <Chip label="🇬🇧  English" active={lang === 'en'} onPress={() => changeLang('en')} />
          </View>
        </Card>

        <Card style={{ paddingVertical: 4 }}>
          {premiumEnabled && isPremium && <Row icon="card-outline" label={t('profile.manage')} onPress={manage} />}
          <Row icon="phone-portrait-outline" label={t('profile.logoutAll')} onPress={() => Alert.alert(t('profile.logoutAll'), '?', [
            { text: t('common.cancel'), style: 'cancel' },
            { text: 'OK', onPress: async () => { await api.logoutAll().catch(() => {}); await logout(); router.replace('/welcome'); } },
          ])} />
          <Row icon="log-out-outline" label={t('profile.logout')} onPress={async () => { await logout(); router.replace('/welcome'); }} />
          <Row icon="trash-outline" label={t('profile.deleteAccount')} danger onPress={() => setDeleteOpen(true)} />
        </Card>

        <Text style={[font.small, { textAlign: 'center', marginTop: 24, fontSize: 11, color: colors.faint }]}>Kubo v1.1.0 · {API_URL}</Text>
      </ScrollView>

      <Modal visible={deleteOpen} transparent animationType="fade" onRequestClose={() => setDeleteOpen(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', padding: 24 }}>
          <Card strong style={{ backgroundColor: colors.bgAlt }}>
            <Text style={font.h2}>{t('profile.deleteAccount')}</Text>
            <Text style={[font.body, { color: colors.muted, marginVertical: 12 }]}>{t('profile.deleteText')}</Text>
            <Field secure icon="lock-closed-outline" placeholder={t('auth.password')} value={password} onChangeText={setPassword} />
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <GhostButton title={t('common.cancel')} style={{ flex: 1 }} onPress={() => { setDeleteOpen(false); setPassword(''); }} />
              <GradientButton title={t('common.delete')} style={{ flex: 1 }} loading={busy} disabled={!password}
                colorsOverride={['#E11D48', '#F43F5E']} onPress={deleteAccount} />
            </View>
          </Card>
        </View>
      </Modal>
    </Screen>
  );
}
