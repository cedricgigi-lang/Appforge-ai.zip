# ⚡ APPFORGE AI

**Crée ton application mobile avec l'IA, sans coder.**
Application Android (React Native + Expo) et API sécurisée (Node.js + SQLite).

```
appforge-ai/
├── mobile/     → application Android (Expo SDK 54, expo-router)
└── backend/    → API REST sécurisée + base de données + génération IA + export APK
```

---

## ✨ Fonctionnalités

| Fonction | Où | Détails |
|---|---|---|
| Inscription / connexion | `mobile/app/login.js`, `backend/src/routes/auth.js` | Mots de passe hachés (scrypt), jetons JWT, stockage chiffré sur le téléphone (SecureStore) |
| Assistant IA | `mobile/app/chat.js`, `backend/src/ai/generator.js` | Décris ton app → elle est générée. Puis « ajoute un écran Contact », « mets le thème en bleu »… |
| Modèles | onglet **Modèles** | Éducation, Business (vitrine + boutique), Jeux, Réseau social, Productivité |
| Éditeur visuel | `mobile/app/editor/[id].js` | Touche un élément pour le modifier, ajoute des composants, gère les écrans, couleurs et palettes, annulation |
| Aperçu en direct | `mobile/app/preview/[id].js` | L'application générée tourne vraiment : quiz, tâches, mini-jeu, fil d'actualité, minuteur… |
| Tableau de bord | onglet **Projets** | Rechercher, modifier, dupliquer, supprimer, exporter |
| Sauvegarde | API `PUT /api/projects/:id` | Chaque projet est enregistré côté serveur |
| Export Android | `mobile/app/export/[id].js`, `backend/src/export/` | Projet Expo complet (.zip) pour tous ; **APK compilé dans le cloud** pour les membres Premium |
| Premium | `mobile/app/premium.js`, `backend/src/routes/billing.js` | **Désactivé par défaut** (`PREMIUM_ENABLED=0`) : tout est gratuit, limite de 50 générations IA / jour. Réactivable : Stripe Checkout + webhooks signés |
| Outils IA dans les apps | `backend/runtime/AppRuntime.js` | Générateur d'images IA (Pollinations, gratuit), chatbot (réponses prêtes + vraie IA si une clé est configurée), moteur de recherche (dans l'app ou Wikipédia) |
| Réseau communautaire réel | `backend/src/routes/public.js` | Les publications et « j'aime » du fil d'actualité sont **partagés entre tous les utilisateurs** de l'app ; le créateur peut supprimer des publications |
| Langue | profil | **Français par défaut**, anglais disponible |

### Composants disponibles dans les apps générées
Titre · Texte · Image · Bouton (navigation / message / lien) · Carte · Liste · Statistiques · Champ de saisie · Séparateur ·
Bannière · Galerie · Vidéo · FAQ ·
**Liste de tâches** · **Quiz** · **Compteur** · **Minuteur** · **Mini-jeu de réflexes** · **Fil d'actualité partagé** ·
**Générateur d'images IA** · **Chatbot** · **Moteur de recherche**

---

## 🚀 Démarrage rapide (15 minutes)

### Prérequis
- **Node.js 22.13 ou plus récent** (le backend utilise la base SQLite intégrée à Node — aucune dépendance à installer ; base Turso en option)
- Un téléphone Android avec l'application **Expo Go**, ou un émulateur Android

### 1. Lancer le backend
```bash
cd backend
cp .env.example .env        # puis ouvre .env et remplis JWT_SECRET (voir ci-dessous)
npm start                   # → http://localhost:4000
npm test                    # (optionnel) lance les tests de bout en bout
```
Génère un secret avec : `openssl rand -hex 48`

### 2. Lancer l'application mobile
```bash
cd mobile
npm install
npx expo install --fix      # aligne les versions des paquets sur ton SDK Expo
cp .env.example .env
```
Dans `mobile/.env`, indique l'adresse de l'API :
- émulateur Android : `EXPO_PUBLIC_API_URL=http://10.0.2.2:4000`
- téléphone réel (même Wi-Fi) : `EXPO_PUBLIC_API_URL=http://192.168.x.x:4000` (l'IP de ton ordinateur)

```bash
npx expo start              # scanne le QR code avec Expo Go
```

---

## 🤖 Brancher une vraie IA (recommandé)

**Option gratuite : Pollinations.** Crée une clé sur https://enter.pollinations.ai puis ajoute
`POLLINATIONS_API_KEY=…` (et `AI_PROVIDER=pollinations`). Elle sert à la fois à l'assistant APPFORGE
(génération d'apps sur mesure) et aux chatbots des applications créées.
La génération d'images, elle, fonctionne sans clé (environ une image toutes les 15 secondes).


Sans clé, APPFORGE utilise un **générateur intégré** (règles + modèles) : il fonctionne hors ligne mais comprend des demandes simples.
Pour des applications réellement sur mesure, ajoute une clé dans `backend/.env` :

```env
AI_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-...
# ou
AI_PROVIDER=openai
OPENAI_API_KEY=sk-...
```
Le modèle renvoie une description JSON de l'application, qui est **toujours validée et nettoyée** par le serveur
(`backend/src/spec.js`) avant d'être enregistrée. En cas d'erreur, le générateur intégré prend le relais.

---

## 📦 Export APK

1. **Projet Expo (.zip)** — disponible pour tous : le serveur assemble un projet Expo autonome
   (`App.js`, moteur d'exécution, `spec.json`, `eas.json`). Pour obtenir l'APK soi-même :
   ```bash
   npm install && npx expo install --fix
   npm install -g eas-cli && eas login
   eas build -p android --profile preview
   ```
2. **APK en un clic (Premium)** — si `EXPO_TOKEN` est défini sur le serveur, celui-ci lance la compilation
   sur **Expo EAS Build** et l'application affiche le lien de téléchargement de l'APK une fois prêt (≈ 10–20 min).
   - Crée un jeton sur expo.dev → *Account settings → Access tokens*
   - Le serveur a besoin de `npm`/`npx` et d'un accès Internet
   - L'offre gratuite d'EAS a un quota mensuel de compilations

> Sans `EXPO_TOKEN`, l'export APK fournit le projet .zip et explique la commande à lancer.

---

## 💳 Abonnements (Stripe)

1. Crée deux prix récurrents dans Stripe (mensuel 9,99 $ / annuel 79,99 $).
2. Remplis `STRIPE_SECRET_KEY`, `STRIPE_PRICE_MONTHLY`, `STRIPE_PRICE_YEARLY`.
3. Ajoute un webhook vers `https://ton-api/api/billing/webhook` avec les événements
   `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`, puis renseigne `STRIPE_WEBHOOK_SECRET`.

**Mode test :** tant que Stripe n'est pas configuré et que `NODE_ENV` ≠ `production`, l'écran Premium propose
d'activer Premium gratuitement pour tester. Ce raccourci est **désactivé automatiquement en production**.

> ⚠️ Pour une publication sur le **Google Play Store**, Google exige sa propre facturation (Google Play Billing)
> pour les abonnements numériques. Stripe convient pour un APK distribué hors Play Store ou pour le web ;
> pour le Play Store, prévois d'intégrer RevenueCat ou `react-native-iap` à la place de l'écran de paiement.

---

## 🔐 Sécurité

- Mots de passe : **scrypt** (N = 32768) avec sel aléatoire, comparaison en temps constant, temps de réponse identique que l'email existe ou non
- Sessions : **JWT HS256** signés (7 jours), révocables (« déconnecter tous mes appareils », changement de mot de passe)
- Jeton stocké dans le **trousseau chiffré** Android (expo-secure-store)
- Requêtes SQL **paramétrées** uniquement ; chaque requête vérifie que le projet appartient à l'utilisateur
- **Limitation de débit** : connexion/inscription (20 / 15 min / IP), IA (8 / min), global (300 / min / IP)
- Validation stricte des entrées ; les specs d'application sont **assainies** (types autorisés, longueurs, couleurs, URL `https` uniquement)
- En-têtes de sécurité (CSP, nosniff, X-Frame-Options, HSTS en production), corps limité à 1 Mo
- Liens de téléchargement **signés et valables 10 minutes**
- Webhooks Stripe vérifiés par **signature HMAC** + fenêtre de 5 minutes
- Suppression de compte avec confirmation par mot de passe (exigence du Play Store)

**En production :** `NODE_ENV=production`, un `JWT_SECRET` long, **HTTPS obligatoire** (Android bloque le HTTP en clair
dans les builds de production), `TRUST_PROXY=1` derrière un proxy, et une sauvegarde régulière du dossier `data/`.

---

## ☁️ Déploiement

### Option gratuite : Render + Turso (sans carte bancaire)
L'hébergement gratuit de Render efface le disque à chaque mise en veille : la base de données
est donc placée chez **Turso** (SQLite en ligne, offre gratuite). Le serveur bascule automatiquement
sur Turso dès que `TURSO_DATABASE_URL` et `TURSO_AUTH_TOKEN` sont définis.

1. **Turso** (app.turso.tech) : crée une base, copie son URL (`libsql://…`) et génère un jeton.
2. **Render** (render.com) → *New Web Service* → ton dépôt GitHub →
   *Root Directory* `appforge-ai/backend`, *Language* Docker, *Instance type* **Free**.
3. Variables d'environnement :
   `NODE_ENV=production`, `JWT_SECRET` (`openssl rand -hex 48`), `TRUST_PROXY=1`,
   `TURSO_DATABASE_URL`, `TURSO_AUTH_TOKEN`, `PUBLIC_URL=https://ton-service.onrender.com`,
   et pendant la phase de test `PREMIUM_TEST_MODE=1`.
4. Vérifie `https://ton-service.onrender.com/api/health` → `"database":"turso"`.

> Le service gratuit se met en veille après 15 minutes sans visite : la première ouverture de
> l'application peut alors prendre environ une minute. Les données, elles, restent dans Turso.

### Option payante (Docker + volume)

**Backend (Docker)**
```bash
cd backend
docker build -t appforge-api .
docker run -d -p 4000:4000 --env-file .env -v appforge-data:/app/data appforge-api
```
Fonctionne sur Render, Railway, Fly.io, un VPS… (prévois un volume persistant pour `data/`).

**Application Android**
```bash
cd mobile
# indique l'URL HTTPS de ton API dans eas.json (EXPO_PUBLIC_API_URL)
eas build -p android --profile preview      # APK à installer directement
eas build -p android --profile production   # AAB pour le Play Store
```

---

## 🧩 Architecture

```
Utilisateur ──► Assistant IA ──► POST /api/ai/generate ──► LLM (ou générateur intégré)
                                          │
                                          ▼
                               AppSpec JSON (validé par spec.js) ──► SQLite (projets)
                                          │
        ┌─────────────────────────────────┼──────────────────────────────────┐
        ▼                                 ▼                                  ▼
  Éditeur visuel                  Aperçu en direct                     Export Expo / APK
 (modifie le JSON)       (AppRuntime exécute le JSON)       (même AppRuntime embarqué dans l'APK)
```

Le fichier `backend/runtime/AppRuntime.js` est le **moteur d'exécution** : il sert à l'aperçu dans APPFORGE *et*
il est copié tel quel dans chaque application exportée — ce que tu vois dans l'aperçu est exactement ce que
contiendra l'APK. Si tu le modifies, lance `npm run sync-runtime` dans `mobile/` pour garder les deux copies identiques.

### API (extrait)
| Méthode | Route | Rôle |
|---|---|---|
| POST | `/api/auth/register` · `/api/auth/login` | Compte & session |
| GET/PATCH/DELETE | `/api/auth/me` | Profil, langue, suppression |
| GET | `/api/templates` | Modèles |
| GET/POST | `/api/projects` | Lister / créer |
| GET/PUT/DELETE | `/api/projects/:id` | Lire / enregistrer / supprimer |
| POST | `/api/ai/generate` | Générer ou modifier une app |
| POST | `/api/projects/:id/export` | Export `source` ou `apk` |
| GET | `/api/exports/:id` | Suivi de compilation |
| POST | `/api/billing/checkout` · `/api/billing/webhook` | Abonnement |

---

## 🛣️ Pistes d'évolution
- Google Play Billing / RevenueCat pour la publication sur le Play Store
- Images personnalisées (upload vers un stockage S3) et icône d'application générée
- Données partagées entre utilisateurs des apps générées (aujourd'hui, tâches et publications sont locales au téléphone)
- Passage à PostgreSQL pour un très grand nombre d'utilisateurs (les requêtes sont déjà en SQL standard)
